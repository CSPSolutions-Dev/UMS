import { useIntl } from "react-intl";
import { KTIcon } from "../../../../helpers";
import { SidebarMenuItem } from "./SidebarMenuItem";
import { useAuth } from "../../../../../app/modules/auth";
import { useState } from "react";
import { Dialog, DialogActionsBar } from "@progress/kendo-react-dialogs";
import { Button } from "@progress/kendo-react-buttons";
import { ConfirmDialog } from "../../../../../app/components/ConfirmDialog";
import { useNavigate } from "react-router-dom";
import { DEFAULT_ROUTES } from "../../../../../app/constant";

const SidebarMenuMain = () => {
  const [isActive, setIsActive] = useState(false);

  const handleLogoutClick = () => {
    setIsActive(!isActive);
  };

  const [showModal, setShowModal] = useState(false);

  const toggleDialog = () => {
    setShowModal(!showModal);
  };
  const navigate = useNavigate();
  const handleConfirm = () => {
    navigate("/logout");
  };

  const handleClose = () => {
    setShowModal(false);
  };
  const intl = useIntl();
  const { currentUser, logout } = useAuth();
  const preDefinedRoutes: any = currentUser?.routes
    ? currentUser?.routes
    : DEFAULT_ROUTES;
  const getNameAndRoutes = (findRoute: string) => {
    return preDefinedRoutes.find((e: any) => e.route == findRoute);
  };
  return (
    <>
      {getNameAndRoutes("/dashboard") && (
        <SidebarMenuItem
          to={"/dashboard"}
          icon="home"
          title={getNameAndRoutes("/dashboard").name}
          fontIcon="bi bi-house-door"
        />
      )}
      {getNameAndRoutes("/classification-training") && (
        <SidebarMenuItem
          to="/classification-training"
          icon="document"
          title={getNameAndRoutes("/classification-training").name}
          fontIcon="bi-layers"
        />
      )}
      {getNameAndRoutes("/classification-log") && (
        <SidebarMenuItem
          to="/classification-log"
          icon="questionnaire-tablet"
          title={getNameAndRoutes("/classification-log").name}
          fontIcon="bi-layers"
        />
      )}
      {getNameAndRoutes("/training") && (
        <SidebarMenuItem
          to="/training"
          icon="notepad-edit"
          title={getNameAndRoutes("/training").name}
          fontIcon="bi-layers"
        />
      )}
      {getNameAndRoutes("/hs-code-search") && (
        <SidebarMenuItem
          to="/hs-code-search"
          icon="magnifier"
          title={getNameAndRoutes("/hs-code-search").name}
          fontIcon="bi-layers"
        />
      )}
      {getNameAndRoutes("/reports") && (
        <SidebarMenuItem
          to="/reports"
          icon="chart-pie-3"
          title={getNameAndRoutes("/reports").name}
          fontIcon="bi-layers"
        />
      )}

      <div className="menu-item">
        <div className="menu-content pt-8 pb-2">
          <span className="menu-section text-muted text-uppercase fs-8 ls-1">
            UTILITIES
          </span>
        </div>
      </div>

      {getNameAndRoutes("/settings") && (
        <SidebarMenuItem
          to="/settings"
          icon="gear"
          title={getNameAndRoutes("/settings").name}
          fontIcon="bi-layers"
        />
      )}
      {getNameAndRoutes("/hs-code-settings") && (
        <SidebarMenuItem
          to="/hs-code-settings"
          icon="gear"
          title={getNameAndRoutes("/hs-code-settings").name}
          fontIcon="bi-layers"
        />
      )}
      {getNameAndRoutes("/workflow-classification") && (
        <SidebarMenuItem
          to="/workflow-classification"
          icon="gear"
          title={getNameAndRoutes("/workflow-classification").name}
          fontIcon="bi-layers"
        />
      )}
      {getNameAndRoutes("/error-log") && (
        <SidebarMenuItem
          to="/error-log"
          icon="gear"
          title={getNameAndRoutes("/error-log").name}
          fontIcon="bi-layers"
        />
      )}

      <SidebarMenuItem
        to="/help"
        icon="question-2"
        title="Help"
        fontIcon="bi-layers"
      />

      <div className={`menu-item ${isActive ? "active" : ""}`} title="Logout">
        <span className="menu-link without-sub" onClick={toggleDialog}>
          <span className="menu-icon">
            <KTIcon iconName="exit-left" iconType="outline" className="fs-2" />
          </span>
          <span className="menu-title">Logout</span>
        </span>
      </div>

      <ConfirmDialog
        showModal={showModal}
        onConfirm={handleConfirm}
        onClose={handleClose}
        title="Confirm Logout"
        message="Are you sure you want to log out?"
        ButtonText="Logout"
      />
    </>
  );
};

export { SidebarMenuMain };
