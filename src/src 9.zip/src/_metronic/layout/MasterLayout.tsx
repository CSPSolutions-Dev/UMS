import { useEffect, useState } from "react";
import { Outlet, useLocation } from "react-router-dom";
import { HeaderWrapper } from "./components/header";
import { RightToolbar } from "../partials/layout/RightToolbar";
import { ScrollTop } from "./components/scroll-top";
import { FooterWrapper } from "./components/footer";
import { Sidebar } from "./components/sidebar";
import {
  ActivityDrawer,
  DrawerMessenger,
  InviteUsers,
  UpgradePlan,
} from "../partials";
import { PageDataProvider } from "./core";
import { reInitMenu } from "../helpers";
import { useAuth } from "../../app/modules/auth";

const MasterLayout = () => {
  const location = useLocation();
  useEffect(() => {
    reInitMenu();
  }, [location.key]);
  const { currentUser } = useAuth();

  return (
    <>
      {currentUser ? (
        <PageDataProvider>
          <div
            className="d-flex flex-column flex-root app-root"
            id="kt_app_root"
          >
            <div
              className="app-page flex-column flex-column-fluid"
              id="kt_app_page"
            >
              {!currentUser?.UMSEnable && <HeaderWrapper />}
              <div
                className="app-wrapper flex-column flex-row-fluid"
                id="kt_app_wrapper"
              >
                {!currentUser?.UMSEnable && <Sidebar />}
                <div
                  className="app-main flex-column flex-row-fluid"
                  id="kt_app_main"
                >
                  <div className="d-flex flex-column flex-column-fluid">
                    <Outlet />
                  </div>
                  <FooterWrapper />
                </div>
              </div>
            </div>
          </div>

          {/* begin:: Drawers */}
          <ActivityDrawer />
          {/* <RightToolbar /> */}
          <DrawerMessenger />
          {/* end:: Drawers */}

          {/* begin:: Modals */}
          {/* <InviteUsers />
      <UpgradePlan /> */}
          {/* end:: Modals */}
          <ScrollTop />
        </PageDataProvider>
      ) : (
        <div className="master-loading">
          <img
            width="200"
            src="./media/logos/default.svg"
            className="light-logo"
            alt="Dubai Customs logo"
          />
          <span>Loading ...</span>
        </div>
      )}
    </>
  );
};

export { MasterLayout };
