export class CookieComponent {
  /**
   * Returns the cookie with the given name, or undefined if not found
   *
   * @param  {string} name - cookie name
   * @returns string | undefined
   */
  public static get(name: string): string | undefined {
    // Validate that the name is a non-empty string
    if (typeof name !== "string" || !name.trim()) {
      return undefined;
    }

    // Sanitize the cookie name by escaping special characters
    const sanitizedCookieName = name.replace(/([.*+?^${}()|[\]\\])/g, "\\$1");

    // Split the cookie string only once and iterate through parts
    const cookies = document.cookie.split("; ");

    // Handle the special case of the first cookie which won't have leading '; '
    const firstCookie = cookies[0];
    if (firstCookie.startsWith(`${sanitizedCookieName}=`)) {
      const value = firstCookie.slice(sanitizedCookieName.length + 1);
      return decodeURIComponent(value);
    }

    // Check remaining cookies
    for (let i = 1; i < cookies.length; i++) {
      if (cookies[i].startsWith(`${sanitizedCookieName}=`)) {
        const value = cookies[i].slice(sanitizedCookieName.length + 1);
        return decodeURIComponent(value);
      }
    }

    return undefined;
  }

  /**
   * Sets a cookie with the given name and value
   *
   * @param  {string} name - cookie name
   * @param  {string | number | boolean} value - cookie value
   * @param  {any} cookieOptions - cookie options
   * @returns void
   */
  public static set(
    name: string,
    value: string | number | boolean,
    cookieOptions: any
  ): void {
    const options = {
      path: "/",
      // add other defaults here if necessary
      ...cookieOptions,
    };

    if (options.expires instanceof Date) {
      options.expires = options.expires.toUTCString();
    }

    let updatedCookie =
      encodeURIComponent(name) + "=" + encodeURIComponent(value);

    for (const optionKey in options) {
      updatedCookie += "; " + optionKey;
      const optionValue = options[optionKey];
      if (optionValue !== true) {
        updatedCookie += "=" + optionValue;
      }
    }

    document.cookie = updatedCookie;
  }

  /**
   * Deletes a cookie by setting its expiration date to a past date
   *
   * @param  {string} name
   */
  public static delete(name: string): void {
    CookieComponent.set(name, "", {
      "max-age": -1,
    });
  }
}
