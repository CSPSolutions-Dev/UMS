import { FC } from 'react'

const CreateApp: FC = () => {
  return <></>
}

export {CreateApp}
