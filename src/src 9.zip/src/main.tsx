import { createRoot } from "react-dom/client";
// Axios
import axios from "axios";
import { Chart, registerables } from "chart.js";
import { QueryClient, QueryClientProvider } from "react-query";
import { ReactQueryDevtools } from "react-query/devtools";
import { MetronicI18nProvider } from "./_metronic/i18n/Metronici18n";
import "./_metronic/assets/sass/style.react.scss";
import "./_metronic/assets/fonticon/fonticon.css";
import "./_metronic/assets/keenicons/duotone/style.css";
import "./_metronic/assets/keenicons/outline/style.css";
import "./_metronic/assets/keenicons/solid/style.css";
import "./_metronic/assets/sass/style.scss";
import { AppRoutes } from "./app/routing/AppRoutes";
import { AuthProvider, setupAxios } from "./app/modules/auth";
/**
 * Creates `axios-mock-adapter` instance for provided `axios` instance, add
 * basic Metronic mocks and returns it.
 *
 * @see https://github.com/ctimmerm/axios-mock-adapter
 */
/**
 * Inject Metronic interceptors for axios.
 *
 * @see https://github.com/axios/axios#interceptors
 */
setupAxios(axios);

// Registering all the components of Chart.js to use in the application
Chart.register(...registerables);

// Creating a QueryClient instance for React Query
const queryClient = new QueryClient();

// Selecting the root element in the HTML where the React app will be mounted
const container = document.getElementById("root");

// Rendering the React application
if (container) {
  createRoot(container).render(
    <QueryClientProvider client={queryClient}>
      {/* Providing localization support for the application */}
      <MetronicI18nProvider>
        {/* Providing authentication context to the application */}
        <AuthProvider>
          {/* Main routing component for handling application routes */}
          <AppRoutes />
        </AuthProvider>
      </MetronicI18nProvider>
      {/* Adding React Query Devtools for debugging and inspecting queries */}
      <ReactQueryDevtools initialIsOpen={false} />
    </QueryClientProvider>
  );
}
