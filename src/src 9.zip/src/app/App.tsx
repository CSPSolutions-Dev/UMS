import { Suspense } from "react";
import { Outlet } from "react-router-dom";
import { I18nProvider } from "../_metronic/i18n/i18nProvider";
import { LayoutProvider, LayoutSplashScreen } from "../_metronic/layout/core";
import { MasterInit } from "../_metronic/layout/MasterInit";
import { AuthInit } from "./modules/auth";
import { ThemeModeProvider } from "../_metronic/partials";
import "@progress/kendo-theme-bootstrap/dist/all.css";
import "./assets/scss/custom.scss";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
const App = () => {
  return (
    // Suspense allows you to show a fallback (LayoutSplashScreen) while waiting for lazy-loaded components
    <Suspense fallback={<LayoutSplashScreen />}>
      {/* Internationalization provider to handle translations */}
      <I18nProvider>
        {/* LayoutProvider provides the layout context for managing layout structure (like sidebars, headers, etc.) */}
        <LayoutProvider>
          {/* ThemeModeProvider enables toggling between different themes (light, dark, etc.) */}
          <ThemeModeProvider>
            {/* AuthInit initializes the authentication state on application startup */}
            <AuthInit>
              {/* Outlet renders the matched child route's component (injected dynamically based on routes) */}
              <Outlet />
              {/* MasterInit runs initialization scripts (e.g., setting up tooltips, popovers, etc.) */}
              <MasterInit />
              {/* ToastContainer is where toast notifications will appear */}
              <ToastContainer />
            </AuthInit>
          </ThemeModeProvider>
        </LayoutProvider>
      </I18nProvider>
    </Suspense>
  );
};

export { App };
