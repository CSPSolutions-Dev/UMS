export const DEFAULT_ROUTES = [
  // {
  //   name: "Dashboard",
  //   route: "/dashboard",
  // },
  {
    name: "HS Code Classification Training",
    route: "/classification-training",
  },
  {
    name: "Classified HSCODE(s)",
    route: "/classification-log",
  },
  {
    name: "HS Code Training",
    route: "/training",
  },
  {
    name: "HS Code Search",
    route: "/hs-code-search",
  },
  {
    name: "Reports",
    route: "/reports",
  },
  {
    name: "Settings",
    route: "/settings",
  },
  {
    name: "HS Code Settings",
    route: "/hs-code-settings",
  },
  {
    name: "Workflow Settings",
    route: "/workflow-classification",
  },
  {
    name: "Error Log",
    route: "/error-log",
  },
];
