import { Content } from "../../../../_metronic/layout/components/content";

const Help = () => {
  return (
    <>
      <Content>
        {/* <div className="card mb-5 mb-xl-10">Help Page</div> */}
      </Content>
    </>
  );
};

export { Help };
