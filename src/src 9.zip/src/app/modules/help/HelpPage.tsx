import React from "react";
import { Content } from "../../../_metronic/layout/components/content";
import { Help } from "./components/help";

const HelpPage: React.FC = () => {
  return (
    <>
      <Content>
        <div className="col-xl-12">
          <Help />
        </div>
      </Content>
    </>
  );
};

export default HelpPage;
