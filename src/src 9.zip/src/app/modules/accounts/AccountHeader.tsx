import React from "react";
import { toAbsoluteUrl } from "../../../_metronic/helpers";
import { Link } from "react-router-dom";
import { useLocation } from "react-router";
import { Content } from "../../../_metronic/layout/components/content";
import { useAuth } from "../auth";

const AccountHeader: React.FC = () => {
  const location = useLocation();
  const { currentUser } = useAuth();
  return (
    <>
      <Content>
        <div className="card mb-5 mb-xl-10">
          {/* Card header with background color and cursor pointer */}
          <div className="card-header cursor-pointer bg-primary">
            <div className="card-title m-0"></div>
            <div className="d-flex align-items-center gap-3"></div>
          </div>
          {/* Card body that contains user information */}
          <div className="card-body pt-9 pb-0 px-0">
            <div className="d-flex flex-wrap flex-sm-nowrap mb-3 px-9 gap-16">
              {/* <div className="me-7 mb-4">
                <div className="symbol symbol-100px symbol-lg-160px symbol-fixed position-relative">
                  <img
                    src={toAbsoluteUrl("media/avatars/300-1.jpg")}
                    alt="Metronic"
                    style={{ height: "100px", width: "100px" }}
                  />
                </div>
              </div> */}

              {/* User details section */}
              <div className="flex-grow-1">
                <div className="d-flex justify-content-between align-items-center flex-wrap mb-2">
                  <div className="d-flex flex-column">
                    <div className="d-flex align-items-center mb-1">
                      <a
                        href="#"
                        className="text-gray-800 text-hover-primary fs-2 fw-bolder me-1"
                      >
                        {currentUser.username}
                      </a>
                    </div>

                    <div className="d-flex flex-wrap fw-bold fs-6 mb-4 pe-2">
                      <a
                        href="#"
                        className="d-flex align-items-center text-gray-500 text-hover-primary me-5 mb-2"
                      >
                        {currentUser.email}
                      </a>
                    </div>
                    <div className="d-flex flex-wrap flex-stack">
                      <div className="d-flex flex-column flex-grow-1 pe-8"></div>
                    </div>
                  </div>
                  <div className="d-flex align-items-center w-200px w-sm-300px flex-column mt-3"></div>
                </div>
              </div>
            </div>
            <div className="separator border-2 my-0"></div>
            {/* Navigation section */}
            <div className="d-flex overflow-auto h-55px px-9">
              <ul className="nav nav-stretch nav-line-tabs nav-line-tabs-2x border-transparent fs-5 fw-bolder flex-nowrap">
                {/* Overview tab link */}
                <li className="nav-item">
                  <Link
                    className={
                      `nav-link text-active-primary me-6 ` +
                      (location.pathname === "/crafted/account/overview" &&
                        "active") // Active class if current path is /crafted/account/overview
                    }
                    to="/crafted/account/overview"
                  >
                    Overview
                  </Link>
                </li>
                {/* Additional tabs can be added here */}
              </ul>
            </div>
          </div>
        </div>
      </Content>
    </>
  );
};

export { AccountHeader };
