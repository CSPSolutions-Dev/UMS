import { ProfileDetails } from "./cards/ProfileDetails";

import { Content } from "../../../../../_metronic/layout/components/content";

export function Settings() {
  return (
    <Content>
      <ProfileDetails />
    </Content>
  );
}
