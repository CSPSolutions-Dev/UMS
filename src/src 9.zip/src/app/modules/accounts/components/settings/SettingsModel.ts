export interface IProfileDetails {
  avatar: string;
  fName: string;
  lName: string;
  email: string;
  company: string;
  contactPhone: string;
  companySite: string;
  country: string;
  language: string;
  timeZone: string;
  currency: string;
  communications: {
    email: boolean;
    phone: boolean;
  };
  allowMarketing: boolean;
}

export interface IUpdateEmail {
  newEmail: string;
  confirmPassword: string;
}

export interface IUpdatePassword {
  currentPassword: string;
  newPassword: string;
  passwordConfirmation: string;
}

export const profileDetailsInitValues: IProfileDetails = {
  avatar: "media/avatars/300-1.jpg",
  fName: "test",
  lName: "test",
  email: "example.com",
  company: "test company name",
  contactPhone: "001 334 5454",
  companySite: "example.com",
  country: "",
  language: "",
  timeZone: "",
  currency: "",
  communications: {
    email: false,
    phone: false,
  },
  allowMarketing: false,
};

export const updateEmail: IUpdateEmail = {
  newEmail: "support@example.com",
  confirmPassword: "",
};

export const updatePassword: IUpdatePassword = {
  currentPassword: "",
  newPassword: "",
  passwordConfirmation: "",
};
