import { Content } from "../../../../_metronic/layout/components/content";
import { useAuth } from "../../auth";

export function Overview() {
  const { currentUser } = useAuth(); // Extract currentUser details from the auth context
  return (
    <Content>
      {/* Main card displaying the profile details */}
      <div className="card mb-5 mb-xl-10" id="kt_profile_details_view">
        <div className="card-header cursor-pointer border-0">
          <div className="card-title m-0">
            <h3 className="m-0">Profile Detail</h3>
          </div>
        </div>
        {/* Card body that displays user's profile details */}
        <div className="card-body p-9">
          <div className="row mb-7">
            <label className="col-lg-4 fw-bold text-muted">Full Name</label>
            {/* Displaying the username */}
            <div className="col-lg-8">
              <span className="fw-bolder fs-6 text-gray-900">
                {currentUser.username}
              </span>
            </div>
          </div>
          {/* Phone Number Row */}
          <div className="row mb-7">
            <label className="col-lg-4 fw-bold text-muted">
              Phone number
              <i
                className="fas fa-exclamation-circle ms-1 fs-7"
                data-bs-toggle="tooltip"
                title="Phone number must be active"
              ></i>
            </label>

            <div className="col-lg-8 d-flex align-items-center">
              <span className="fw-bolder fs-6 me-2">
                {currentUser.mobileNumber}
              </span>
            </div>
          </div>
          {/* Email Address Row */}
          <div className="row mb-7">
            <label className="col-lg-4 fw-bold text-muted">Email Address</label>

            <div className="col-lg-8 fv-row">
              <span className="fw-bold fs-6">{currentUser.email}</span>
            </div>
          </div>
        </div>
      </div>
    </Content>
  );
}
