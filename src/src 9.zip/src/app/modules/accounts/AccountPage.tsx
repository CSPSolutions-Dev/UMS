import React from "react";
import { Navigate, Route, Routes, Outlet } from "react-router-dom";
import { PageLink, PageTitle } from "../../../_metronic/layout/core";
import { Overview } from "./components/Overview";
import { Settings } from "./components/settings/Settings";
import { AccountHeader } from "./AccountHeader";

// Breadcrumb configuration for the account page
const accountBreadCrumbs: Array<PageLink> = [
  {
    title: "Account",
    path: "/crafted/account/overview",
    isSeparator: false,
    isActive: false,
  },
  {
    title: "",
    path: "",
    isSeparator: true,
    isActive: false,
  },
];

// Main AccountPage component that handles routing and layout for the account section
const AccountPage: React.FC = () => {
  return (
    <Routes>
      {/* Route for account section with nested routes */}
      <Route
        element={
          <>
            <AccountHeader />
            <Outlet />
          </>
        }
      >
        {/* Route for the Overview page */}
        <Route
          path="overview"
          element={
            <>
              <PageTitle breadcrumbs={accountBreadCrumbs}>Overview</PageTitle>
              <Overview />
            </>
          }
        />
        {/* Route for the Settings page */}
        <Route
          path="settings"
          element={
            <>
              <PageTitle breadcrumbs={accountBreadCrumbs}>Settings</PageTitle>
              <Settings />
            </>
          }
        />
        {/* Default route, redirects to the Overview page */}
        <Route index element={<Navigate to="/crafted/account/overview" />} />
      </Route>
    </Routes>
  );
};

export default AccountPage;
