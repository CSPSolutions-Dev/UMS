import { Route, Routes } from "react-router-dom";
import { Login } from "./components/Login";
import { AuthLayout } from "./AuthLayout";

// The AuthPage component defines the routes for the authentication-related pages
const AuthPage = () => (
  <Routes>
    {/* AuthLayout acts as a wrapper for the routes below */}
    <Route element={<AuthLayout />}>
      <Route path="login" element={<Login />} />
      {/* The following routes are commented out, but they could be used for registration and forgot-password flows */}
      {/* <Route path='registration' element={<Registration />} /> */}
      {/* <Route path='forgot-password' element={<ForgotPassword />} /> */}
      <Route path="/*" element={<Login />} />
    </Route>
  </Routes>
);

export { AuthPage };
