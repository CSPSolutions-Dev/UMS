import { useEffect } from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "./core/Auth";

export function Logout() {
  // Retrieve the logout function from the custom authentication hook
  const { logout } = useAuth();

  // useEffect runs the logout function when the component mounts
  useEffect(() => {
    // Calls the logout function to log the user out of the application
    logout();
    window.location.href = "/";
  }, [logout]); // The effect depends on the logout function

  // Ensures the user is navigated to the home page as a fallback
  return <Navigate to="/" />;
}
