import { useEffect } from "react";
import { Outlet } from "react-router-dom";
import { toAbsoluteUrl } from "../../../_metronic/helpers";

const AuthLayout = () => {
  // useEffect to set the root element's height to 100% when this component mounts
  // and reset it to 'auto' when the component unmounts
  useEffect(() => {
    const root = document.getElementById("root");
    if (root) {
      root.style.height = "100%";
    }
    return () => {
      if (root) {
        root.style.height = "auto";
      }
    };
  }, []);

  return (
    <div className="d-flex flex-column flex-lg-row flex-column-fluid h-100">
      {/* Left section containing the logo and outlet for child components */}
      <div className="d-flex flex-column flex-lg-row-fluid w-lg-50 p-10 order-2 order-lg-1">
        <div>
          <img
            alt="Logo"
            src={toAbsoluteUrl("media/logos/default.svg")}
            className="h-45px"
          />
        </div>

        <div className="d-flex flex-center flex-column flex-lg-row-fluid">
          <div className="w-lg-500px p-10">
            <Outlet />
          </div>
        </div>
      </div>

      <div
        className="d-flex flex-lg-row-fluid w-lg-50 bgi-size-cover bgi-position-center order-1 order-lg-2"
        style={{
          backgroundImage: `url(${toAbsoluteUrl("media/misc/auth-bg.png")})`,
        }}
      >
        {/* Centered content on the right side */}
        <div className="d-flex flex-column flex-center py-15 px-5 px-md-15 w-100">
          {/* Image below the background */}
          <img
            className="mx-auto w-275px w-md-50 w-xl-500px mb-10 mb-lg-20"
            src={toAbsoluteUrl("media/misc/auth-screens.svg")}
            alt=""
          />
          {/* Text content displayed in white */}
          <h1 className="text-white fs-2qx fw-bolder text-center ">
            Al Munasiq Backend App
          </h1>
          {/* Sub-text displayed in white */}
          <div className="text-white fs-base text-center">
            <h3 className="text-white">
              Your Gateway to Effortless HS Code Retrieval
            </h3>
          </div>
        </div>
      </div>
    </div>
  );
};

export { AuthLayout };
