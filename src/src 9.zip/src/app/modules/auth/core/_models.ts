export interface AuthModel {
  token: string;
  refreshToken?: string;
}
