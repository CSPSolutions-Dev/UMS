import React, { useState } from "react";
import { Content } from "../../../_metronic/layout/components/content";
import { DashboardHeader } from "./components/DashboardHeader";
import Dashboard from "./components/Dashboard";
import { Filter } from "./components/interfaces";

// Define the DashboardPage component
const DashboardPage: React.FC = () => {
  // State to manage filter criteria for the Dashboard component
  const [filter, setFilter] = useState<Filter | null>(null);
  return (
    <>
      <Content>
        {/* Wrapper for content with styling from _metronic layout */}{" "}
        {/* Container for the entire dashboard section */}
        <div className="col-xl-12">
          {/* Header component for the dashboard */}
          <DashboardHeader filter={filter} setFilter={setFilter} />
          {/* Main dashboard component, passing down filter criteria */}
          <Dashboard filter={filter} />
        </div>
      </Content>
    </>
  );
};

export default DashboardPage;
