import { Grid, GridColumn } from "@progress/kendo-react-grid";
import {
  Chart,
  ChartCategoryAxis,
  ChartCategoryAxisItem,
  ChartSeries,
  ChartSeriesItem,
  ChartTitle,
  ChartLegend,
  ChartTooltip,
  Sankey,
  SankeyData,
  SankeyLinkDefaults,
  SankeyTitle,
} from "@progress/kendo-react-charts";
import { useEffect, useState } from "react";
import { TagCloud } from "react-tagcloud";
import {
  getAccuracy,
  getTopClassifiedHSCode,
  getTopClassifiedHSSections,
  getClassificationsSummary,
  getClassificationsSummaryPerUser,
  generateUniqueColors,
  getWordCloud,
} from "../services";
import { Button } from "@progress/kendo-react-buttons";
import { Dialog } from "@progress/kendo-react-dialogs";
import {
  Filter,
  HSCardProps,
  SectionCardProps,
  AccuracyRecord,
  SummaryProps,
  WordCloudProps,
} from "./interfaces";

interface DashboardProps {
  filter: Filter | null;
}

// Card component to display HS Code details
const HSCard = (dataItem: HSCardProps) => {
  return (
    <div className="card custom-card">
      <div className="card-body border-top p-6 d-flex justify-content-between">
        <div className="">
          <p className="m-0 text-decoration-underline text-primary">
            {dataItem.hsCode}
          </p>
          <p className="m-0">
            {dataItem.sectionName} <br />
          </p>
          <p className="m-0">
            <span className="k-font-medium">Confidence:</span>{" "}
            {(dataItem.confidenceScore * 100).toFixed(2) + "%"}
          </p>
        </div>
        <div>
          <p className="m-0 text-primary fw-semibold text-nowrap">
            Occurrence: {dataItem.totalCounts}
          </p>
        </div>
      </div>
    </div>
  );
};

// Card component to display Section details
const SectionCard = (dataItem: SectionCardProps) => {
  return (
    <div className="card custom-card">
      <div className="card-body border-top p-6 d-flex justify-content-between">
        <div className="">
          <p className="m-0 text-decoration-underline text-primary">Sections</p>
          <p className="m-0">
            {dataItem.sectionName} <br />
          </p>
        </div>
        <div>
          <p className="m-0 text-primary fw-semibold text-nowrap">
            Occurrence: {dataItem.totalCounts}
          </p>
        </div>
      </div>
    </div>
  );
};

// Main Dashboard component
const Dashboard = ({ filter }: DashboardProps) => {
  // State variables for storing data and loaders
  const [accuracy, setAccuracy] = useState<AccuracyRecord[] | null>(null);
  const [topHSCode, setTopHSCode] = useState<HSCardProps[] | null>(null);
  const [topSections, setTopSections] = useState<SectionCardProps[] | null>(
    null
  );
  const [summary, setSummary] = useState<SummaryProps[]>([]);
  const [summaryLoader, setSummaryLoader] = useState<boolean>(false);
  const [summaryPerUser, setSummaryPerUser] = useState<any>({
    links: [],
    nodes: [],
  });

  const [wordCloud, setWordCloud] = useState<WordCloudProps[]>([]);
  const [wordCloudLoader, setWordCloudLoader] = useState<boolean>();
  const [summaryPerUserLoader, setSummaryPerUserLoader] =
    useState<boolean>(false);
  const [hsCodeLoader, setHSCodeLoader] = useState<boolean>(false);
  const [sectionLoader, setSectionLoader] = useState<boolean>(false);
  const [chartLoader, setChartLoader] = useState<boolean>(false);
  const [wordCloudModel, setWordCloudModel] = useState<boolean>(false);

  // Function to transform data for Sankey chart
  const transformDataForSankeyChart = (data: any[]): SankeyData => {
    const categories: { [key: number]: { text: string; color: string } } = {
      2: { text: "Pending Verification", color: "#bb9753" },
      3: { text: "Classification Complete", color: "#4485b7" },
      4: { text: "Classification Finalized", color: "#bcbec0" },
    };

    const nodes: { id: string; label: { text: string }; color?: string }[] = [];
    const links: { sourceId: string; targetId: string; value: number }[] = [];

    Object.values(categories).forEach((category) => {
      nodes.push({
        id: category.text,
        label: { text: category.text },
        color: category.color,
      });
    });

    const userMap: { [key: string]: number } = {};
    data.forEach((item) => {
      const category = categories[item.classificationWorkflowType];
      if (category) {
        if (!userMap[item.umsuserName]) {
          userMap[item.umsuserName] = 0;
        }
        userMap[item.umsuserName] += parseInt(item.totalCounts, 10);
      }
    });

    Object.keys(userMap).forEach((name) => {
      nodes.push({ id: name, label: { text: `${name} (${userMap[name]})` } });
    });

    data.forEach((item) => {
      const category = categories[item.classificationWorkflowType];
      if (category) {
        links.push({
          sourceId: category.text,
          targetId: item.umsuserName,
          value: parseInt(item.totalCounts, 10),
        });
      }
    });
    return { nodes, links };
  };

  // Function to fetch data and set state
  const getAndSetData = () => {
    setHSCodeLoader(true);
    setSectionLoader(true);
    setChartLoader(true);
    setWordCloudLoader(true);
    // Fetch accuracy data
    getAccuracy(filter).then((res) => {
      setAccuracy(res.sort((a: any, b: any) => a.createdDate - b.createdDate));
      setChartLoader(false);
    });
    getTopClassifiedHSCode(filter).then((res) => {
      setTopHSCode(res);
      setHSCodeLoader(false);
    });
    getWordCloud(filter).then((res) => {
      setWordCloud(res);
      setWordCloudLoader(false);
    });
    getTopClassifiedHSSections(filter).then((res) => {
      setTopSections(res);
      setSectionLoader(false);
    });
    getClassificationsSummary(filter).then((res) => {
      const transformedData = res.map((item: any) => ({
        category: item.classificationWorkflowType.toString(),
        value: parseInt(item.totalCounts),
      }));
      setSummary(transformedData);
      setSummaryLoader(false);
    });
    getClassificationsSummaryPerUser(filter).then(async (res) => {
      const formatedData = await transformDataForSankeyChart(res);
      setSummaryPerUser(formatedData);
      setSummaryPerUserLoader(false);
    });
  };
  // Effect to fetch data when filter changes
  useEffect(() => {
    if (filter) {
      getAndSetData();
    }
  }, [filter]);
  // PieChart component to render a pie chart
  const PieChart = ({
    data,
    title,
    chart_no,
  }: {
    data: SummaryProps[];
    title: string;
    chart_no: number;
  }) => {
    const uniqueColors = generateUniqueColors(data.length);
    const coloredData = data.map((item, index) => {
      if (chart_no == 1) {
        if (item.category === "1") {
          return {
            ...item,
            category: "Pending Classification",
            color: "grey",
          };
        } else if (item.category === "2") {
          return {
            ...item,
            category: "Pending Verification",
            color: "#bb9753",
          };
        } else if (item.category === "3") {
          return {
            ...item,
            category: "Classification Complete",
            color: "#4485b7",
          };
        } else if (item.category === "4") {
          return {
            ...item,
            category: "Classification Finalized",
            color: "#bcbec0",
          };
        }
      } else {
        return {
          ...item,
          color: uniqueColors[index],
        };
      }
    });
    return (
      <Chart>
        <ChartTitle
          text={title}
          margin={{
            bottom: 50,
          }}
          font="bold 12pt sans-serif"
        />
        {coloredData.length && (
          <>
            <ChartLegend position="bottom" />
            <ChartTooltip format="{0}" />
            <ChartSeries>
              <ChartSeriesItem
                type="pie"
                data={coloredData}
                field="value"
                categoryField="category"
                labels={{
                  visible: true,
                  content: (e: any) => `${e.category}: ${e.value}`,
                }}
              />
            </ChartSeries>
          </>
        )}
      </Chart>
    );
  };

  // SankeyChart component to render a Sankey chart
  const SankeyChart = ({ snake }: any) => {
    const links: SankeyLinkDefaults = {
      colorType: "source",
    };

    const title: SankeyTitle = {
      position: "top",
      text: "Classifications Summary Per User",
      font: "bold 12pt sans-serif",
    };
    return (
      <>
        {snake.nodes.length && snake.links.length ? (
          <Sankey
            style={{
              maxWidth: 700,
              height: 400,
              margin: "auto",
            }}
            data={snake}
            links={links}
            title={title}
            legend={{ visible: true }}
            tooltip={{
              visible: true,
              offset: 12,
              followPointer: true,
              delay: 0,
            }}
          />
        ) : (
          <PieChart
            data={[]}
            title="Classifications Summary Per User"
            chart_no={1}
          />
        )}
      </>
    );
  };
  const formatNumbersForCloud = (value: number) => {
    if (value >= 1000000000000) {
      // 1 trillion
      return `${(value / 1000000000000).toFixed(1)}T`;
    } else if (value >= 1000000000) {
      // 1 billion
      return `${(value / 1000000000).toFixed(1)}B`;
    } else if (value >= 1000000) {
      // 1 million
      return `${(value / 1000000).toFixed(1)}M`;
    } else if (value >= 1000) {
      // 1 thousand
      return `${(value / 1000).toFixed(1)}K`;
    }
    return value.toString();
  };

  return (
    <>
      <div className="">
        <div className="row g-5 mb-9">
          <div
            className="col-lg-6"
            style={{
              height: !topHSCode || topHSCode.length === 0 ? "auto" : "400px",
              boxShadow: "0px 4px 4px 0px rgba(62, 73, 84, 0.04)",
            }}
          >
            {hsCodeLoader ? (
              <div className="text-center mt-10">
                <div
                  className="spinner-border"
                  style={{ width: "3rem", height: "3rem" }}
                  role="status"
                >
                  <span className="sr-only">Loading...</span>
                </div>
              </div>
            ) : (
              <Grid
                data={topHSCode}
                resizable={false}
                style={{
                  height:
                    !topHSCode || topHSCode.length === 0 ? "auto" : "400px",
                }}
              >
                <GridColumn
                  field="selected_hS_code"
                  title="Top 100 Classified HS Codes"
                  headerClassName="p-6 border-transparent fw-bold"
                  cell={(props) => HSCard(props.dataItem)}
                />
              </Grid>
            )}
          </div>
          <div
            className="col-lg-6"
            style={{
              height: !topHSCode || topHSCode.length === 0 ? "auto" : "400px",
              boxShadow: "0px 4px 4px 0px rgba(62, 73, 84, 0.04)",
            }}
          >
            {sectionLoader ? (
              <div className="text-center mt-10">
                <div
                  className="spinner-border"
                  style={{ width: "3rem", height: "3rem" }}
                  role="status"
                >
                  <span className="sr-only">Loading...</span>
                </div>
              </div>
            ) : (
              <Grid
                data={topSections}
                resizable={false}
                style={{
                  height:
                    !topSections || topSections.length === 0 ? "auto" : "400px",
                }}
              >
                <GridColumn
                  field="selected_hS_code"
                  title="Top Searched Sections"
                  headerClassName="p-6 border-transparent fw-bold"
                  cell={(props) => SectionCard(props.dataItem)}
                />
              </Grid>
            )}
          </div>
        </div>
      </div>
      <div className="card card-custom">
        <div className="card-body p-5 ">
          {wordCloudLoader ? (
            <div className="text-center mt-10">
              <div
                className="spinner-border"
                style={{
                  width: "3rem",
                  height: "3rem",
                  boxShadow: "0px 4px 4px 0px rgba(62, 73, 84, 0.04)",
                }}
                role="status"
              >
                <span className="sr-only">Loading...</span>
              </div>
            </div>
          ) : (
            <div>
              <div className="d-flex justify-content-between">
                <h5 className="pt-3">HS Code Word Cloud</h5>
                {wordCloud.length !== 0 && (
                  <Button
                    onClick={() => {
                      setWordCloudModel(true);
                    }}
                  >
                    View All
                  </Button>
                )}
              </div>
              {wordCloud.length !== 0 ? (
                <>
                  <TagCloud
                    minSize={12}
                    maxSize={35}
                    tags={wordCloud.map((item: any, index: number) => ({
                      value: `${item.word.replace(
                        /,/g,
                        ""
                      )}(${formatNumbersForCloud(item.totalCounts)})`,
                      count: item.totalCounts,
                    }))}
                    colorOptions={{ luminosity: "dark" }}
                    className="simple-cloud"
                  />
                  {/* Modal for word cloud */}
                  {wordCloudModel && (
                    <Dialog
                      title={<h5>Top searched words</h5>}
                      onClose={() => setWordCloudModel(false)}
                    >
                      <Grid
                        data={wordCloud.map((item: any, index: number) => ({
                          value: `${item.word.replace(/,/g, "")}`,
                          count: item.totalCounts,
                        }))}
                        resizable={true}
                        style={{
                          height:
                            !wordCloud || wordCloud.length === 0
                              ? "auto"
                              : "500px",
                        }}
                      >
                        <GridColumn
                          field="value"
                          title="Word"
                          width={300}
                          headerClassName="border-transparent fw-bold"
                        />
                        <GridColumn
                          field="count"
                          title="Count"
                          headerClassName="border-transparent fw-bold"
                          width={200}
                        />
                      </Grid>
                    </Dialog>
                  )}
                </>
              ) : (
                <div className="text-center mt-10">
                  <p>No Data Available</p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
      <div className="row g-5 mt-5">
        <div className="col-lg-6">
          <div className="card card-custom">
            <div className="card-body p-5 pt-0">
              {summaryLoader ? (
                <div className="text-center mt-10">
                  <div
                    className="spinner-border"
                    style={{
                      width: "3rem",
                      height: "3rem",
                      boxShadow: "0px 4px 4px 0px rgba(62, 73, 84, 0.04)",
                    }}
                    role="status"
                  >
                    <span className="sr-only">Loading...</span>
                  </div>
                </div>
              ) : (
                <PieChart
                  data={summary}
                  title="Classifications Summary"
                  chart_no={1}
                />
              )}
            </div>
          </div>
        </div>
        <div className="col-lg-6">
          <div className="card card-custom" style={{ position: "unset" }}>
            <div className="card-body p-5 pt-0">
              {summaryPerUserLoader ? (
                <div className="text-center mt-10">
                  <div
                    className="spinner-border"
                    style={{
                      width: "3rem",
                      height: "3rem",
                      boxShadow: "0px 4px 4px 0px rgba(62, 73, 84, 0.04)",
                    }}
                    role="status"
                  >
                    <span className="sr-only">Loading...</span>
                  </div>
                </div>
              ) : (
                <SankeyChart snake={summaryPerUser} />
              )}
            </div>
          </div>
        </div>
      </div>
      <div className="card card-custom mt-5">
        <div className="card-body p-5 pt-0">
          {chartLoader ? (
            <div className="text-center mt-10">
              <div
                className="spinner-border"
                style={{
                  width: "3rem",
                  height: "3rem",
                  boxShadow: "0px 4px 4px 0px rgba(62, 73, 84, 0.04)",
                }}
                role="status"
              >
                <span className="sr-only">Loading...</span>
              </div>
            </div>
          ) : (
            <Chart>
              <ChartTitle
                align="left"
                padding={15}
                margin={{
                  bottom: 10,
                }}
                text="HS Code - AI Model Accuracy"
                font="bold 15pt sans-serif"
              ></ChartTitle>
              <ChartCategoryAxis>
                <ChartCategoryAxisItem
                  categories={accuracy?.map(
                    (item: any) =>
                      new Date(item.createdDate).toISOString().split("T")[0]
                  )}
                  startAngle={45}
                />
              </ChartCategoryAxis>
              <ChartSeries>
                <ChartSeriesItem
                  type="area"
                  data={accuracy?.map((item: AccuracyRecord) => ({
                    key: new Date(item.createdDate).toISOString().split("T")[0],
                    value: (Number(item.confidenceScore) * 100).toFixed(2),
                  }))}
                  markers={{
                    visible: false,
                    border: { color: "#555CF3" },
                    size: 12,
                    background: "white",
                  }}
                  color={"rgba(116, 139, 220, 0.1)"}
                  line={{ style: "smooth", width: 4, color: "#748BDC" }}
                  tooltip={{
                    visible: true,
                    background: "grey",
                    format: "{0}%",
                    padding: 12,
                  }}
                />
              </ChartSeries>
            </Chart>
          )}
        </div>
      </div>
    </>
  );
};

export default Dashboard;
