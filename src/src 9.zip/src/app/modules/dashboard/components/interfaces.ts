export interface Filter {
  chapterId: string;
  endDate: string;
  headingId: string;
  hscodeFilter: string;
  startDate: string;
}

export interface DashboardHeaderProps {
  setFilter: (filter: Filter | null) => void;
  filter: Filter | null;
}

export interface HSCardProps {
  confidenceScore: number;
  hsCode: number;
  sectionName: string;
  totalCounts: string;
}

export interface SectionCardProps {
  sectionName: string;
  sectionNumber: string;
  totalCounts: string;
}

export interface AccuracyRecord {
  confidenceScore: number;
  createdDate: number;
}

export interface SummaryProps {
  category: string;
  value: number;
}

export interface WordCloudProps {
  totalCounts: string | number;
  word: number;
}

export interface chapterListProps {
  commodityCode: string;
  commodityDesc: string | null;
  commodityId: number;
  commodityNameEn: string;
}
