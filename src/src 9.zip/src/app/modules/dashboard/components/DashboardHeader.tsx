import { useEffect, useState } from "react";
import { formatDateAPI, getChapters, getChaptersHeading } from "../services";
import DateRangeSelector from "../../../components/dateRangePicker/DateRangeSelector";
import { Filter, chapterListProps } from "./interfaces";

type SetFilterFunction = (filter: Filter) => void;

// Define the props interface
interface DashboardHeaderProps {
  setFilter: SetFilterFunction;
}

const DashboardHeader = ({ setFilter }: any) => {
  // State for HS Code, Chapter, and Chapter Heading
  const [hsCode, setHsCode] = useState<string>("");
  const [chapter, setChapter] = useState<string>("");
  const [chapterId, setChapterId] = useState<string>("");
  const [chapterList, setChapterList] = useState<chapterListProps[]>([]);
  const [chapterHeading, setChapterHeading] = useState<string>("");
  const [chapterHeadingList, setChapterHeadingList] = useState<any>([]);

  // Get the start date of the month
  const getStartOfMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth(), 1);
  };
  // Get the end date of the month
  const getEndOfMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0);
  };
  // State for date range
  const [dateState, setDateState] = useState<{
    startDate: Date;
    endDate: Date;
  }>({
    startDate: getStartOfMonth(new Date()),
    endDate: getEndOfMonth(new Date()),
  });
  // Fetch chapters on component mount
  useEffect(() => {
    getChapters().then((res) => {
      setChapterList(sortTitle(res));
    });
  }, []);
  // Fetch chapter headings when chapterId changes
  useEffect(() => {
    if (chapterId) {
      getChaptersHeading(chapterId).then((res) => {
        setChapterHeadingList(sortTitle(res));
      });
    } else {
      setChapterHeading("");
    }
  }, [chapterId]);
  // Handle filter change and set filter in parent component
  const handleFilterChange = async () => {
    setFilter({
      endDate: formatDateAPI(dateState.endDate),
      startDate: formatDateAPI(dateState.startDate),
      chapterId: chapter,
      headingId: chapterHeading,
      hscodeFilter: hsCode,
    });
  };
  // Handle reset of all filter criteria
  const handleReset = async () => {
    setDateState({
      startDate: getStartOfMonth(new Date()),
      endDate: getEndOfMonth(new Date()),
    });
    setChapter("");
    setHsCode("");
    setChapterId("");
    setChapterHeading("");
    setChapterHeadingList([]);
    setFilter({
      startDate: formatDateAPI(getStartOfMonth(new Date())),
      endDate: formatDateAPI(getEndOfMonth(new Date())),
      chapterId: "",
      headingId: "",
      hscodeFilter: "",
    });
  };
  // Handle filter change on component mount
  useEffect(() => {
    handleFilterChange();
  }, []);

  // Sort chapter/heading titles alphabetically
  const sortTitle = (commodities: any) => {
    commodities.sort((a: any, b: any) => {
      const nameA = a.commodityNameEn.toUpperCase();
      const nameB = b.commodityNameEn.toUpperCase();
      if (nameA < nameB) {
        return -1;
      }
      if (nameA > nameB) {
        return 1;
      }
      return 0;
    });
    return commodities;
  };
  return (
    <>
      <div className="Container">
        <div className="row align-items-center mb-6">
          <div className="col-12 col-md-3">
            <h2>Dashboard</h2>
          </div>

          <div className="col-12 col-md-9 d-md-flex d-block align-items-center justify-content-md-end gap-3">
            {/* Chapter Dropdown */}
            <div className="col-md-2 col-12 mb-md-0 mb-3">
              <select
                className="form-select form-select-white fs-6 fw-normal"
                aria-label="Select example"
                onChange={(e) => {
                  setChapter(e.target.value);
                  setChapterId(e.target.selectedOptions[0].dataset.id || "");
                }}
                value={chapter}
              >
                <option value="" data-id="">
                  By Chapter
                </option>
                {chapterList?.map((item: chapterListProps) => (
                  <option
                    title={item.commodityNameEn}
                    value={item.commodityCode}
                    data-id={item.commodityId}
                  >
                    {item.commodityNameEn.length > 20
                      ? item.commodityNameEn.slice(0, 20) + "..."
                      : item.commodityNameEn}
                  </option>
                ))}
              </select>
            </div>
            <div className="col-md-2 col-12  mb-md-0 mb-3">
              <select
                disabled={chapter ? false : true}
                className="form-select form-select-white fs-6 fw-normal"
                aria-label="Select example"
                onChange={(e) => setChapterHeading(e.target.value)}
                value={chapterHeading}
              >
                <option value="">By Heading</option>
                {chapterHeadingList?.map((item: any) => (
                  <option
                    title={item.commodityNameEn}
                    value={item.commodityCode}
                    data-id={item.commodityId}
                  >
                    {item.commodityNameEn.length > 20
                      ? item.commodityNameEn.slice(0, 20) + "..."
                      : item.commodityNameEn}
                  </option>
                ))}
              </select>
            </div>
            {/* HS Code Input */}
            <div className="col-md-2 col-12  mb-md-0 mb-3">
              <input
                value={hsCode}
                onChange={(e) => {
                  if (
                    (e.target.value.length <= 10 && Number(e.target.value)) ||
                    e.target.value == ""
                  ) {
                    setHsCode(e.target.value);
                  }
                }}
                type="text"
                className="form-control fs-6 fw-normal"
                placeholder="Filter by HS Code"
              />
            </div>
            {/* Date Range Selector */}
            <div className=" mb-md-0 mb-3">
              <DateRangeSelector
                onSubmit={({ startDate, endDate }) => {
                  setDateState({
                    startDate,
                    endDate,
                  });
                }}
                ranges={dateState}
              />
            </div>
            {/* Filter and Reset Buttons */}
            <div className=" mb-md-0 mb-3">
              <button
                type="button"
                onClick={handleFilterChange}
                className="btn btn-primary fs-6 w-100px fw-normal"
              >
                Filter
              </button>
            </div>
            <div className="d-grid gap-2">
              <button
                onClick={handleReset}
                type="button"
                className="btn btn-outline btn-outline-solid btn-outline-primary btn-active-light-primary"
              >
                Reset
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export { DashboardHeader };
