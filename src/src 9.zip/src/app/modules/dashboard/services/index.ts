import {
  HscodeSearchControllerApi,
  ReportsControllerApi,
} from "../../../../api";
import { generateSecureRandomNumberInRange } from "../../../components/CommonFunction";
// Instantiate API controllers
const ReportsAPI = new ReportsControllerApi();
const SearchAPI = new HscodeSearchControllerApi();
// Format date as YYYY/MM/DD HH:MM:SS
export const formatDate = (date: Date) => {
  const year = date.getFullYear();
  const month = (date.getMonth() + 1).toString().padStart(2, "0");
  const day = date.getDate().toString().padStart(2, "0");
  const hours = date.getHours().toString().padStart(2, "0");
  const minutes = date.getMinutes().toString().padStart(2, "0");
  const seconds = date.getSeconds().toString().padStart(2, "0");

  return `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`;
};
// Default color palette
const mainColors = ["#bb9753", "#4485b7", "#bcbec0"];
// Convert HEX color to RGB array
function hexToRgb(hex: string) {
  const bigint = parseInt(hex.slice(1), 16);
  const r = (bigint >> 16) & 255;
  const g = (bigint >> 8) & 255;
  const b = bigint & 255;

  return [r, g, b];
}
// Convert RGB values to HEX color
function rgbToHex(r: number, g: number, b: number) {
  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}
// Generate a color close to the base color with slight variations
function getRandomColorCloseTo(baseColor: any) {
  const [r, g, b] = hexToRgb(baseColor);
  const variation = 20;

  const newR = Math.min(
    255,
    Math.max(0, r + generateSecureRandomNumberInRange(-variation, variation))
  );
  const newG = Math.min(
    255,
    Math.max(0, g + generateSecureRandomNumberInRange(-variation, variation))
  );
  const newB = Math.min(
    255,
    Math.max(0, b + generateSecureRandomNumberInRange(-variation, variation))
  );

  return rgbToHex(newR, newG, newB);
}
// Generate a list of unique colors
export const generateUniqueColors = (count: number) => {
  const uniqueColors = new Set();
  while (uniqueColors.size < count) {
    const baseColor =
      mainColors[generateSecureRandomNumberInRange(0, mainColors.length - 1)];
    uniqueColors.add(getRandomColorCloseTo(baseColor));
  }
  return Array.from(uniqueColors);
};
// Format date for API as YYYY/MM/DD
export const formatDateAPI = (date: Date) => {
  const year = date.getFullYear();
  const month = (date.getMonth() + 1).toString().padStart(2, "0");
  const day = date.getDate().toString().padStart(2, "0");
  return `${year}/${month}/${day}`;
};
// Fetch HS Code accuracy report based on filter criteria
export const getAccuracy = async (filter: any) => {
  try {
    const response: any = await ReportsAPI.getHSCodeAccuracy(
      filter.chapterId || undefined,
      filter.endDate,
      filter.headingId || undefined,
      filter.hscodeFilter || undefined,
      undefined,
      filter.startDate
    );

    return response.data.responseObject?.[0] || [];
  } catch (e) {
    return [];
  }
};
// Fetch top classified HS Codes based on filter criteria
export const getTopClassifiedHSCode = async (filter: any) => {
  try {
    const response: any = await ReportsAPI.getTopClassifiedHSCode(
      filter.chapterId || undefined,
      filter.endDate,
      filter.headingId || undefined,
      filter.hscodeFilter || undefined,
      undefined,
      filter.startDate
    );

    return response.data.responseObject?.[0] || [];
  } catch (e) {
    return [];
  }
};
// Fetch top classified HS Sections based on filter criteria
export const getTopClassifiedHSSections = async (filter: any) => {
  try {
    const response: any = await ReportsAPI.getTopClassifiedHSSections(
      filter.chapterId || undefined,
      filter.endDate,
      filter.headingId || undefined,
      filter.hscodeFilter || undefined,
      undefined,
      filter.startDate
    );

    return response.data.responseObject?.[0] || [];
  } catch (e) {
    return [];
  }
};
// Fetch classifications summary based on filter criteria
export const getClassificationsSummary = async (filter: any) => {
  try {
    const response: any = await ReportsAPI.getClassificationsSummary(
      filter.chapterId || undefined,
      filter.endDate,
      filter.headingId || undefined,
      filter.hscodeFilter || undefined,
      undefined,
      filter.startDate
    );

    return response.data.responseObject?.[0] || [];
  } catch (e) {
    return [];
  }
};
// Fetch classifications summary per user based on filter criteria
export const getClassificationsSummaryPerUser = async (filter: any) => {
  try {
    const response: any = await ReportsAPI.getClassificationsSummaryPerUser(
      filter.chapterId || undefined,
      filter.endDate,
      filter.headingId || undefined,
      filter.hscodeFilter || undefined,
      undefined,
      filter.startDate
    );

    return response.data.responseObject?.[0] || [];
  } catch (e) {
    return [];
  }
};

export const getWordCloud = async (filter: any) => {
  try {
    const response: any = await ReportsAPI.getHSCodeTopSearchWords(
      filter.chapterId || undefined,
      filter.endDate,
      filter.headingId || undefined,
      filter.hscodeFilter || undefined,
      undefined,
      filter.startDate
    );

    return response.data.responseObject?.[0] || [];
  } catch (e) {
    return [];
  }
};
// Fetch word cloud data based on filter criteria
export const getChapters = async () => {
  try {
    const response: any = await SearchAPI.getSectionChapters1();

    return response.data.responseObject?.[0] || [];
  } catch (e) {
    return [];
  }
};
// Fetch chapter headings based on chapter ID
export const getChaptersHeading = async (chapterId: any) => {
  try {
    const response: any = await SearchAPI.getCommodityChapterHeading(chapterId);

    return response.data.responseObject?.[0] || [];
  } catch (e) {
    return [];
  }
};
