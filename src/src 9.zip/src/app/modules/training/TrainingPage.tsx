import { TrainingGrid } from "./components/TrainingGrid";
import { Content } from "../../../_metronic/layout/components/content";
import React, { useState } from "react";
import { ClassificationHeader } from "./components/Header";
import { FilterType } from "./interfaces";
import PagerComponent from "../../components/pagination/pagination";

const TrainingPage = () => {
  const [trainingStatus, setTrainingStatus] = useState<Number>(1);
  const [filter, setFilter] = useState<FilterType | null>(null);
  const [itemsPerPage, setItemsPerPage] = useState(5);
  const [currentPage, setCurrentPage] = React.useState<number>(1);
  const [totalElement, setTotalElement] = React.useState<number>(0);

  // Handle changes in the number of items per page
  const handleItemsPerPageChange = (itemsPerPage: number) => {
    setItemsPerPage(itemsPerPage);
    setCurrentPage(1);
  };

  // Function to reset pagination when filter or other conditions change
  const resetPagination = () => {
    setCurrentPage(1);
    setTotalElement(0);
  };

  return (
    <Content>
      <ClassificationHeader
        filter={filter}
        setFilter={setFilter}
        resetPagination={resetPagination}
        trainingStatus={trainingStatus}
        setTrainingStatus={setTrainingStatus}
      />
      <TrainingGrid
        filter={filter}
        itemsPerPage={itemsPerPage}
        setTotalElement={setTotalElement}
        currentPage={currentPage}
        trainingStatus={trainingStatus}
      />
      <PagerComponent
        totalPage={totalElement}
        currentPage={currentPage}
        onPageChange={setCurrentPage}
        itemsPerPage={itemsPerPage}
        setItemsPerPage={handleItemsPerPageChange}
      />
    </Content>
  );
};

export default TrainingPage;
