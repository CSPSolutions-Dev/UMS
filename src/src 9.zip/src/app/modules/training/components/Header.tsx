import { useEffect, useState } from "react";
import {
  formatDateAPI,
  getClassified,
  getSections,
} from "../services/TrainingService";
import {
  ClassificationHeaderProps,
  Section,
  ClassifiedItem,
} from "../interfaces";
import DateRangeSelector from "../../../components/dateRangePicker/DateRangeSelector";
import { Link } from "react-router-dom";

// ClassificationHeader component

const ClassificationHeader: React.FC<ClassificationHeaderProps> = ({
  filter,
  setFilter,
  resetPagination,
  trainingStatus,
  setTrainingStatus,
}) => {
  // Function to get the start of the month for a given date
  const getStartOfMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth(), 1);
  };

  // Function to get the end of the month for a given date
  const getEndOfMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0);
  };
  // State to manage date range
  const [dateState, setDateState] = useState<{
    startDate: Date;
    endDate: Date;
  }>({
    startDate: getStartOfMonth(new Date()),
    endDate: getEndOfMonth(new Date()),
  });

  // State to manage sections and classified items lists
  const [sectionsList, setSectionsList] = useState<Section[]>([]);
  const [classifiedList, setClassifiedList] = useState<ClassifiedItem[]>([]);
  // State to manage filter values
  const [hsCode, setHsCode] = useState<string>("");
  const [section, setSection] = useState<string>("");
  const [classifiedBy, setClassifiedBy] = useState<string>("");

  // Function to handle filter change
  const handleFilterChange = () => {
    setFilter({
      endDate: formatDateAPI(dateState.endDate),
      startDate: formatDateAPI(dateState.startDate),
      hscodeFilter: hsCode,
      sectionId: section,
      classifiedBy: classifiedBy,
    });
    resetPagination();
  };

  // Function to reset filters to default values
  const handleReset = async () => {
    setHsCode("");
    setSection("");
    setClassifiedBy("");
    setDateState({
      startDate: getStartOfMonth(new Date()),
      endDate: getEndOfMonth(new Date()),
    });
    setFilter({
      endDate: formatDateAPI(getEndOfMonth(new Date())),
      startDate: formatDateAPI(getStartOfMonth(new Date())),
      hscodeFilter: "",
      sectionId: "",
      classifiedBy: "",
    });
    resetPagination();
  };
  // Function to sort a list of items by a given key
  const sortTitle = (commodities: any, key: any) => {
    commodities.sort((a: any, b: any) => {
      const nameA = a[key].toUpperCase();
      const nameB = b[key].toUpperCase();
      if (nameA < nameB) {
        return -1;
      }
      if (nameA > nameB) {
        return 1;
      }
      return 0;
    });
    return commodities;
  };

  // Fetch and set sections list on component mount
  useEffect(() => {
    getSections().then((res) => {
      setSectionsList(sortTitle(res, "name"));
    });
  }, []);

  // Fetch and set classified items list on component mount

  useEffect(() => {
    getClassified().then((res) => {
      setClassifiedList(sortTitle(res, "username"));
    });
  }, []);

  // Apply filters when component mounts

  useEffect(() => {
    handleFilterChange();
  }, []);

  return (
    <>
      <div className="row align-items-center mb-6">
        <div className="col-12 col-md-3">
          <h2>HS Code Training</h2>
        </div>

        <div className="col-12 col-md-9 d-md-flex d-block align-items-center justify-content-md-end gap-3">
          {/* Filter by classified user */}
          <div className="col-md-2 col-12 mb-md-0 mb-3">
            <select
              className="form-select form-select-white fs-6 fw-normal"
              aria-label="Select example"
              onChange={(e: React.ChangeEvent<HTMLSelectElement>) => {
                setClassifiedBy(e.target.value);
              }}
              value={classifiedBy}
            >
              <option value={""}>Classified By</option>
              {classifiedList.map((item: ClassifiedItem) => (
                <option
                  value={item.cusCustomerUserId}
                  key={`section-${item.userIdentityToken}`}
                >
                  {item.username}
                </option>
              ))}
            </select>
          </div>
          {/* Filter by section */}
          <div className="col-md-2 col-12  mb-md-0 mb-3">
            <select
              className="form-select form-select-white fs-6 fw-normal"
              aria-label="Select example"
              onChange={(e: React.ChangeEvent<HTMLSelectElement>) => {
                setSection(e.target.value);
              }}
              value={section}
            >
              <option value={""}>Filter by Section</option>
              {sectionsList.map((item: Section) => (
                <option
                  title={item.name}
                  value={item.commoditySectionId}
                  key={`section-${item.commoditySectionId}`}
                >
                  {item.name.length > 20
                    ? item.name.slice(0, 20) + "..."
                    : item.name}
                </option>
              ))}
            </select>
          </div>
          {/* Filter by HS Code */}
          <div className="col-md-2 col-12  mb-md-0 mb-3">
            <input
              value={hsCode}
              onChange={(e) => {
                if (
                  (e.target.value.length <= 10 && Number(e.target.value)) ||
                  e.target.value == ""
                ) {
                  setHsCode(e.target.value);
                }
              }}
              type="text"
              className="form-control fs-6 fw-normal"
              placeholder="Filter by HS Code"
            />
          </div>
          {/* Date Range Selector */}
          <div className="mb-md-0 mb-3">
            <DateRangeSelector
              onSubmit={({ startDate, endDate }) => {
                setDateState({
                  startDate,
                  endDate,
                });
              }}
              ranges={dateState}
            />
          </div>
          {/* Filter and Reset Buttons */}
          <div className="mb-md-0 mb-3">
            <button
              onClick={handleFilterChange}
              className="btn btn-primary fs-6 w-100px fw-normal"
            >
              Filter
            </button>
          </div>
          <div className="d-grid gap-2">
            <button
              onClick={handleReset}
              type="button"
              className="btn btn-outline btn-outline-solid btn-outline-primary btn-active-light-primary"
            >
              Reset
            </button>
          </div>
        </div>
      </div>
      <div className="card mb-5 mb-xl-10">
        <div className="card-body pt-0 pb-0">
          <div className="d-flex overflow-auto h-55px">
            {/* Navigation tabs for different settings sections */}
            <ul className="nav nav-stretch nav-line-tabs nav-line-tabs-2x border-transparent fs-5 fw-bolder flex-nowrap">
              {/* Tab for AI Models settings */}
              <li className="nav-item">
                <Link
                  className={
                    // Add 'active' class if the current pathname matches the AI Models path
                    `nav-link text-active-primary me-6 ` +
                    (trainingStatus === 1 && "active")
                  }
                  to=""
                  onClick={() => setTrainingStatus(1)}
                >
                  Pending for Training
                </Link>
              </li>
              <li className="nav-item">
                <Link
                  className={
                    // Add 'active' class if the current pathname matches the Global Settings path
                    `nav-link text-active-primary me-6 ` +
                    (trainingStatus === 2 && "active")
                  }
                  to=""
                  onClick={() => setTrainingStatus(2)}
                >
                  Training Data
                </Link>
              </li>
              <li className="nav-item">
                <Link
                  className={
                    // Add 'active' class if the current pathname matches the Global Settings path
                    `nav-link text-active-primary me-6 ` +
                    (trainingStatus === 3 && "active")
                  }
                  to=""
                  onClick={() => setTrainingStatus(3)}
                >
                  Discarded Data
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </>
  );
};

export { ClassificationHeader };
