import { Grid, GridColumn } from "@progress/kendo-react-grid";
import React, { useEffect, useState } from "react";
import { TextArea } from "@progress/kendo-react-inputs";
import {
  formatDate,
  getImageByKey,
  getItems,
  getSimilarTrainingData,
  updateClassification,
} from "../services/TrainingService";
import { AlertModel } from "../../classification-training/components/AlertModel";
import {
  DataItem,
  HSCodeClassificationLogProps,
  searchValueProps,
  HSCodeSearchResult,
  HSCodeDetailProps,
  DataItemProps,
  HSCodeSearchWorkFlowLogItem,
} from "../interfaces";
import { Dialog } from "@progress/kendo-react-dialogs";
import { searchHSCode } from "../../classification-training/services";
import { Model } from "../../classification-training/components/ConfirmModel";
interface OpenModal {
  message: string;
  submitHsCode: any;
  callBack: () => void;
}
const TrainingGrid: React.FC<HSCodeClassificationLogProps | any> = ({
  filter,
  itemsPerPage,
  currentPage,
  setTotalElement,
  trainingStatus,
}) => {
  const [data, setData] = React.useState<any[]>([]);
  const [loader, setLoader] = useState(false);
  const [openAlertModal, setOpenAlertModal] = useState<string | null>(null);
  const [openModal, setOpenModal] = React.useState<OpenModal | null>(null);

  // Function to fetch data from API based on filter and pagination
  const getAndSetData = async () => {
    if (filter && trainingStatus) {
      setLoader(true);
      await getItems(filter, trainingStatus, itemsPerPage, currentPage).then(
        (res) => {
          setTotalElement(res.totalPages);
          setData(res.content);
        }
      );
      setLoader(false);
    }
  };
  const updateItem = (id: string, newData: any) => {
    const updatedData = data.map((item: any) =>
      item.hscodeSearchId === id ? { ...item, ...newData } : item
    );
    setData(updatedData);
  };
  // useEffect hook to fetch data when the filter or currentPage changes
  useEffect(() => {
    if (filter && trainingStatus) {
      getAndSetData();
    }
  }, [filter, currentPage, trainingStatus]); // Re-run effect when `filter` or `currentPage` changes

  // CSS style for grid
  const gridClass: React.CSSProperties = {
    width: "100%",
    margin: "0 auto",
    overflowX: "auto",
  };

  const SearchByUser = (dataItem: DataItem) => {
    const [image, setImage] = useState<string | null>("");
    const [inputValue, setInputValue] = useState<string>(
      dataItem?.searchTextTraining || ""
    );
    const [isOpen, setIsOpen] = useState<boolean>(false);

    useEffect(() => {
      // Fetch the image when the component mounts or dataItem changes
      if (dataItem?.hscodeImageAnalysisId?.imageKey) {
        getImageByKey(dataItem?.hscodeImageAnalysisId?.imageKey).then((res) => {
          // Set the image source with base64 encoding
          setImage(`data:image/jpeg;base64,${res}`);
        });
      }
    }, [dataItem]);
    return (
      <td className="position-relative text-center border-top py-6 align-top">
        <div className="px-4">
          {/* Text area displaying the search text */}
          <TextArea
            value={inputValue}
            rows={5}
            placeholder="Type here ..."
            style={{
              color: "black",
              fontWeight: 500,
              borderRadius: 6,
              overflowY: "auto",
              borderColor: "1px solid #DEE2E6",
            }}
            onChange={(e: any) => setInputValue(e.target.value)}
            onBlur={(e: any) => {
              updateItem(dataItem.hscodeSearchId, {
                ...dataItem,
                searchTextTraining: inputValue,
              });
            }}
          />
          {/* Conditionally render image and dialog based on whether image data exists */}
          {image && (
            <>
              <img
                src={image}
                alt="photo"
                style={{
                  cursor: "pointer",
                  width: "100%",
                  marginTop: 10,
                  maxHeight: 150,
                  maxWidth: 150,
                }}
                onClick={() => setIsOpen(true)}
              />
              {/* Dialog for displaying the full-size image */}
              {isOpen && (
                <Dialog
                  title={dataItem?.searchTextTraining}
                  onClose={() => setIsOpen(false)}
                  width="80%"
                  height="80%"
                >
                  <img
                    src={image}
                    style={{ width: "100%", maxHeight: "200%" }}
                    alt={dataItem?.searchTextTraining}
                  />
                </Dialog>
              )}
            </>
          )}
          <hr className="border-gray-300 border" />
          {/* Display user information and creation date */}
          <div className="text-start text-black fs-7">
            {dataItem?.cusCustomerUserId?.username}
          </div>
          <div className="text-start fs-6 text-gray-500">
            {dataItem?.createdDate
              ? formatDate(new Date(dataItem?.createdDate))
              : ""}
          </div>
        </div>
      </td>
    );
  };

  const HsCodeDetails = (dataItem: any) => {
    // Initialize variable to hold HS Code details
    let item = null;

    // Check if the prediction classification type ID is 1
    // and find the correct HS Code from search results
    if (
      dataItem.hscodePredictionClassificationTypeId
        ?.hscodePredictionClassificationTypeId == 1
    ) {
      item = dataItem.hscodeSearchResults.find(
        (item: HSCodeSearchResult) => item.correctHSCode === true
      );
    }
    const [newCodeDetail, setNewCodeDetail] =
      useState<HSCodeDetailProps | null>(null);

    useEffect(() => {
      const fetchDefaultHSCode = async () => {
        if (dataItem?.providedNewHscode && !dataItem.providedNewHscodeDetails) {
          try {
            const defDetail = await searchHSCode(dataItem?.providedNewHscode);
            if (defDetail) {
              setNewCodeDetail(defDetail);
            }
          } catch (error) {
            console.error("Error fetching default HSCode:", error);
          }
        }
      };

      fetchDefaultHSCode();
    }, [dataItem?.providedNewHscode]);
    useEffect(() => {
      if (newCodeDetail) {
        updateItem(dataItem.hscodeSearchId, {
          ...dataItem,
          providedNewHscodeDetails: { ...newCodeDetail },
        });
      }
    }, [newCodeDetail]);

    return (
      <>
        <td className="border-top py-6 px-3 align-top">
          {/* Display details if an HS Code item is found */}
          {item && (
            <div className="d-flex mb-1 justify-content-between border-bottom border-none p-6 bg-light rounded min-h-80px ml-4">
              <div className="d-flex gap-5" key={`training`}>
                <div>
                  <div>
                    <span className="fw-bolder ">{item?.hsCode} : </span>
                    <span className="fw-normal text-gray-500">
                      {item?.hscodeDescription}
                    </span>{" "}
                  </div>
                  <div>
                    <span className="fw-bolder">Heading :</span>{" "}
                    {item?.headingName}
                  </div>
                  <div>
                    <span className="fw-bolder">Section : </span>
                    {item?.sectionName}
                  </div>
                  <div>
                    <span className="fw-bolder">Confidence : </span>
                    {item.confidenceScore
                      ? (item.confidenceScore * 100).toFixed(2)
                      : 0.0}
                    %
                  </div>
                </div>
              </div>
              <div
                className="d-inline-grid"
                style={{ alignContent: "space-between" }}
              >
                {/* Display favorite icon with conditional styling */}
                <div
                  style={{
                    display: "inline-flex",
                    justifyContent: "flex-end",
                  }}
                  title="Favorite"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    xlinkTitle="Favorite"
                    className={`bi bi-star-fill ${
                      dataItem.isFavourite ? "text-warning" : "text-secondary"
                    }`}
                    viewBox="0 0 16 16"
                  >
                    <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.282.95l-3.522 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z" />
                  </svg>
                  {/* Display rating icons based on search rating type */}
                </div>
                <div style={{ fontSize: "5px", display: "flex" }}>
                  {item.hscodeSearchRatingComment && (
                    <i
                      onClick={() => {
                        setOpenAlertModal(
                          item?.hscodeSearchRatingComment || ""
                        );
                      }}
                      style={{ fontSize: "1.1rem", cursor: "pointer" }}
                      className="fa-regular me-3 fa-message"
                      title={item.hscodeSearchRatingComment}
                    />
                  )}
                  {item.hscodeSearchRatingTypeId?.hscodeSearchRatingTypeId ==
                    1 && (
                    <i
                      style={{ fontSize: "1.2rem" }}
                      className="fa-solid fa-thumbs-up"
                      title="Correct"
                    />
                  )}
                  {item.hscodeSearchRatingTypeId?.hscodeSearchRatingTypeId ==
                    2 && (
                    <i
                      style={{ fontSize: "1.2rem" }}
                      className="fa-solid fa-thumbs-down"
                      title={"Incorrect"}
                    />
                  )}
                  {item.hscodeSearchRatingTypeId?.hscodeSearchRatingTypeId ==
                    3 && (
                    <i
                      style={{ fontSize: "1.2rem" }}
                      className="fa-solid fa-circle-question"
                      title={`I don't know`}
                    />
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Display additional information based on classification type ID */}
          {dataItem.hscodePredictionClassificationTypeId
            ?.hscodePredictionClassificationTypeId == 2 && (
            <div className="d-flex mb-1 justify-content-between border-bottom border-none p-6 bg-light rounded min-h-80px ml-4">
              <div className=" gap-5" key={`training`}>
                <span
                  className="text-nowrap fs-16 text-black fw-bolder"
                  style={{ fontWeight: 600 }}
                >
                  {`Provided new HS Code`}
                </span>
                <div>
                  <div>
                    <span className="fw-bolder ">
                      {dataItem?.providedNewHscodeDetails?.hsCode} :{" "}
                    </span>
                    <span className="fw-normal text-gray-500">
                      {dataItem?.providedNewHscodeDetails?.hscodeDescription}
                    </span>{" "}
                  </div>
                  <div>
                    <span className="fw-bolder">Heading :</span>{" "}
                    {dataItem?.providedNewHscodeDetails?.headingName}
                  </div>
                  <div>
                    <span className="fw-bolder">Section : </span>
                    {dataItem?.providedNewHscodeDetails?.sectionName}
                  </div>
                </div>
              </div>
            </div>
          )}
          {dataItem.hscodePredictionClassificationTypeId
            ?.hscodePredictionClassificationTypeId == 3 && (
            <div className="d-flex mb-1 border-bottom border-none p-3 bg-light fs-6 text-gray-900 rounded ">
              <span
                className="mx-3 fs-8 text-black"
                style={{ fontWeight: 600 }}
              >
                Marked as Provided description is not enough to correctly
                classify the goods (to be discarded).
              </span>
            </div>
          )}
          {dataItem.hscodePredictionClassificationTypeId
            ?.hscodePredictionClassificationTypeId == 4 && (
            <div className="d-flex mb-1 border-bottom border-none p-3 bg-light fs-6 text-gray-900 rounded ">
              <span
                className="mx-3 fs-8 text-black"
                style={{ fontWeight: 600 }}
              >
                Marked as Provided description of goods is invalid (to be
                discarded).
              </span>
            </div>
          )}
        </td>
      </>
    );
  };

  const hsCodeUserDetails = (dataItem: DataItemProps) => {
    return (
      <>
        <td className="border-top position-relative py-6 px-3 fs-6 align-top">
          <div className="border-none text-gray-900">
            {/* Map over the workflow log to display details based on classification type */}
            {dataItem?.hsCodeSearchWorkFlowLog.map(
              (item: HSCodeSearchWorkFlowLogItem, index: any) => {
                // Handle classification type ID 2 (Classified or Rejected)
                if (
                  item?.classificationWorkflowTypeId
                    ?.classificationWorkflowTypeId === 2
                ) {
                  return (
                    <div key={index}>
                      {" "}
                      <div className="mb-3 d-block">
                        {/* Display action type (Classified or Rejected) */}
                        <span className="fw-bolder">
                          {item?.classificationWorkflowActionsType
                            ?.classificationWorkflowActionsTypeId === 1 &&
                            "Classified By"}
                          {item?.classificationWorkflowActionsType
                            ?.classificationWorkflowActionsTypeId === 2 &&
                            "Rejected By"}
                        </span>
                        <br />
                        <span className="fw-normal text-gray-600">
                          {/* Display username of the classified/rejected user */}
                          {item?.classifiedByUserId?.username}
                        </span>
                      </div>
                      <div className="mb-5">
                        {/* Display date of classification/rejection */}
                        <span className="fw-bolder">
                          {item?.classificationWorkflowActionsType
                            ?.classificationWorkflowActionsTypeId === 1 &&
                            "Date Classified"}
                          {item?.classificationWorkflowActionsType
                            ?.classificationWorkflowActionsTypeId === 2 &&
                            "Date Rejected"}
                        </span>
                        <br />
                        <span className="fw-normal text-gray-600">
                          {/* Format and display the date */}
                          {item?.dateClassified
                            ? formatDate(new Date(item?.dateClassified))
                            : ""}
                        </span>
                      </div>
                    </div>
                  );
                  // Handle classification type ID 3 (Approved)
                } else if (
                  item?.classificationWorkflowTypeId
                    ?.classificationWorkflowTypeId === 3
                ) {
                  return (
                    <div key={index}>
                      <div className="mb-3 d-block">
                        {/* Display approval action */}
                        <span className="fw-bolder">Verified By</span>
                        <br />
                        <span className="fw-normal text-gray-600">
                          {/* Display username of the approver */}
                          {item?.classifiedByUserId?.username}
                        </span>
                      </div>
                      <div className="mb-5">
                        <span className="fw-bolder">Date Verified</span>
                        <br />
                        <span className="fw-normal text-gray-600">
                          {item?.dateClassified
                            ? formatDate(new Date(item?.dateClassified))
                            : ""}
                        </span>
                      </div>
                    </div>
                  );
                  // Handle classification type ID 4 (Signed)
                } else if (
                  item?.classificationWorkflowTypeId
                    ?.classificationWorkflowTypeId === 4
                ) {
                  return (
                    <div key={index}>
                      <div className="mb-3 d-block">
                        <span className="fw-bolder">Signed By</span>
                        <br />
                        <span className="fw-normal text-gray-600">
                          {item?.classifiedByUserId?.username}
                        </span>
                      </div>
                      <div className="mb-5">
                        <span className="fw-bolder">Date Signed</span>
                        <br />
                        <span className="fw-normal text-gray-600">
                          {item?.dateClassified
                            ? formatDate(new Date(item?.dateClassified))
                            : ""}
                        </span>
                      </div>
                    </div>
                  );
                } else {
                  return null;
                }
              }
            )}
          </div>
        </td>
      </>
    );
  };

  const trainingButton = (dataItem: any, setSelectedSearchString: any) => {
    const [buttonText, setButtonText] = useState("");
    useEffect(() => {
      switch (
        dataItem?.comCommodityTrainingStatus?.comCommodityTrainingStatus
      ) {
        case 1:
        case 3:
          setButtonText("Approve");
          break;
        case 2:
          setButtonText("Update");
          break;
      }
    }, dataItem);
    const handleUpdate = async (query: any) => {
      setLoader(true);
      await updateClassification(query);
      await getAndSetData().then(() => {
        setLoader(false);
        setOpenModal(null);
      });
    };
    const [submitHsCode, setSubmitHsCode] = useState<any>(null);

    useEffect(() => {
      if (dataItem?.providedNewHscodeDetails) {
        setSubmitHsCode(dataItem?.providedNewHscodeDetails);
      }
      if (
        !dataItem?.providedNewHscode &&
        !dataItem?.markedRequiredMoreInfo &&
        !dataItem?.markedInvalidSearch
      ) {
        setSubmitHsCode(
          dataItem.hscodeSearchResults.find(
            (item: HSCodeSearchResult) => item.correctHSCode === true
          )
        );
      }
    }, [dataItem]);
    console.log("submitHsCode", submitHsCode);
    return (
      <>
        {submitHsCode && (
          <td className="border-top position-relative py-6 px-3 fs-6 align-top">
            <button
              type="button"
              onClick={() => {
                setSelectedSearchString(dataItem.searchTextTraining);
                setOpenModal({
                  submitHsCode: submitHsCode,
                  message: `Are you sure you want to Mark this for training ?`,
                  callBack: () =>
                    handleUpdate({
                      searchTextTraining: dataItem.searchTextTraining,
                      hsCodeSearchId: dataItem.hscodeSearchId,
                      trainingStatus: 2,
                      hsCode: submitHsCode?.hsCode,
                      hsCodeDescription: submitHsCode?.hscodeDescription,
                    }),
                });
              }}
              disabled={loader || !dataItem?.searchTextTraining ? true : false}
              className="btn btn-primary mb-2 w-100"
            >
              {loader ? (
                <>
                  <span className="spinner-border spinner-border-sm align-middle ms-5 me-5"></span>
                </>
              ) : (
                buttonText
              )}
            </button>
            {trainingStatus != 3 && (
              <button
                type="button"
                onClick={() => {
                  setOpenModal({
                    submitHsCode: null,
                    message: `Are you sure you want to Discard this Training ?`,
                    callBack: () =>
                      handleUpdate({
                        searchTextTraining: dataItem.searchTextTraining,
                        hsCodeSearchId: dataItem.hscodeSearchId,
                        trainingStatus: 3,
                        hsCode: dataItem.hsCode,
                        hsCodeDetails: dataItem.hsCodeDetails,
                      }),
                  });
                }}
                disabled={
                  loader || !dataItem?.searchTextTraining ? true : false
                }
                className="btn btn-outline btn-outline btn-outline-primary btn-active-light-primary w-100"
              >
                {loader ? (
                  <>
                    <span className="spinner-border spinner-border-sm align-middle ms-5 me-5"></span>
                  </>
                ) : (
                  "Discard"
                )}
              </button>
            )}
          </td>
        )}
      </>
    );
  };

  const [minWidth, setMinWidth] = useState("1200px");
  const [columnWidth, setColumnWidth] = useState(500);

  useEffect(() => {
    // Function to update minimum width and column width based on window size
    const updateMinWidth = () => {
      const width = window.innerWidth;
      if (width <= 576) {
        setMinWidth("1000px");
        setColumnWidth(400);
      } else if (width <= 768) {
        setMinWidth("400px");
        setColumnWidth(300);
      } else if (width <= 1024) {
        setMinWidth("400px");
        setColumnWidth(300);
      } else if (width <= 1280) {
        setMinWidth("800px");
        setColumnWidth(400);
      } else if (width <= 1440) {
        setMinWidth("900px");
        setColumnWidth(500);
      } else {
        setMinWidth("100%");
        setColumnWidth(700);
      }
    };
    updateMinWidth();
    // Add event listener for window resize to update dimensions
    window.addEventListener("resize", updateMinWidth);
    // Clean up event listener on component unmount
    return () => window.removeEventListener("resize", updateMinWidth);
  }, []); // Empty dependency array ensures effect runs once on mount
  const [selectedSearchString, setSelectedSearchString] = useState<any>(null);
  const [searchStringData, setSearchStringData] = useState<any>([]);
  useEffect(() => {
    if (selectedSearchString) {
      getSimilarTrainingData(selectedSearchString).then((res) => {
        setSearchStringData(res);
      });
    }
  }, [selectedSearchString]);
  console.log("SELECTED SEARCH STRING", selectedSearchString);
  return (
    <>
      <div className="card" style={gridClass}>
        {loader ? ( // Display loading spinner when data is being fetched
          <div className="text-center mt-10">
            <div
              className="spinner-border"
              style={{ width: "3rem", height: "3rem" }}
              role="status"
            >
              <span className="sr-only">Loading...</span>
            </div>
          </div>
        ) : (
          <>
            {/* Kendo Grid to display fetched data */}
            <Grid
              data={data}
              resizable={false}
              style={{
                minWidth: minWidth,
                width: "100%",
              }}
            >
              {/* Column displaying user who searched HS Code */}
              <GridColumn
                field="searched_by_user"
                title="Searched By User"
                headerClassName="p-6 border-transparent fw-bold border-bottom title-custom"
                className="p-3 border-bottom"
                cell={(props) => SearchByUser(props.dataItem)} // Custom cell content
                // width={200}
              />
              {/* Column displaying selected HS Code */}
              <GridColumn
                field="selected_hS_code"
                title="Selected HS Code"
                headerClassName="p-6 border-transparent fw-bold border-bottom title-custom"
                cell={(props) => HsCodeDetails(props.dataItem)} // Custom cell content
                width={columnWidth}
              />
              {/* Empty column for additional user details */}
              <GridColumn
                field=""
                title=""
                headerClassName="bg-white "
                className=""
                cell={(props) => hsCodeUserDetails(props.dataItem)} // Custom cell content
              />
              {/* Empty column for additional user details */}
              <GridColumn
                field=""
                title=""
                headerClassName="bg-white"
                className=""
                cell={(props) =>
                  trainingButton(props.dataItem, setSelectedSearchString)
                } // Custom cell content
              />
            </Grid>
          </>
        )}
      </div>
      {/* Modal for confirmations */}
      {openModal && openModal.message && (
        <Model
          cancelButton={() => {
            setOpenModal(null);
          }}
          message={
            <>
              <p className="fs-4">{openModal.message}</p>
              <Grid data={[]}>
                <GridColumn field={"hsCode"} title={"HS Code"} />
                <GridColumn field={"hsCodeDescription"} title={"Description"} />
                <GridColumn field={"similarity"} title={"Similarity"} />
              </Grid>
            </>
          }
          makeAPICall={openModal.callBack}
        />
      )}
      {/* Conditionally rendering Alert modal when openAlertModal is set */}
      {openAlertModal && (
        <AlertModel
          cancelButton={() => {
            setOpenAlertModal(null); // Close modal on cancel
          }}
          message={openAlertModal}
          heading="Customer Message"
        />
      )}
    </>
  );
};

export { TrainingGrid };
