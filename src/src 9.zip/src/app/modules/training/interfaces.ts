import { GlobalSettings } from "../../../api";

export interface CustomGlobalSettings extends GlobalSettings {
  inEdit?: boolean | string;
  locked?: boolean;
  globalSettingsId?: any;
}

export interface DataItem {
  aiModeId?: number;
  dataRobotKey?: string;
  description?: string;
  maximumNumberOfResults?: number;
  modelApiUrl?: string;
  modelAuthorizationToken?: string;
  modelName?: string;
  tag?: string;
  isActive?: boolean;
}

export interface AIModelFormProps {
  dataItem: DataItem;
  cancelButton: () => void;
  saveButton: (values: DataItem) => void;
}

export interface FilterType {
  classifiedBy: string | undefined;
  endDate: string;
  hscodeFilter: string | undefined;
  sectionId: string | undefined;
  startDate: string;
}

export interface DataItem {
  hscodeSearchId: string;
  searchText?: string;
  searchTextTraining?: string;
  hscodeImageAnalysisId?: {
    imageKey: string;
  };
  cusCustomerUserId?: {
    username?: string;
  };
  createdDate?: string;
  hscodeSearchResults?: Array<{
    hsCode?: string;
    hscodeDescription?: string;
    headingName?: string;
    sectionName?: string;
    confidenceScore?: number;
    correctHSCode?: boolean;
    hscodeSearchRatingComment?: string;
    hscodeSearchRatingTypeId?: {
      hscodeSearchRatingTypeId?: number;
    };
  }>;
  isFavourite?: boolean;
  classificationWorkflowTypeId?: {
    createdBy?: string;
    createdDate?: string;
    modifiedBy?: string;
    modifiedDate?: string;
  };
}

export interface HSCodeClassificationLogProps {
  filter: FilterType | null;
  itemsPerPage: number;
  currentPage: number;
  trainingStatus: number;
  setTotalElement: (total: number) => void;
}

export interface ClassificationHeaderProps {
  filter: FilterType | null;
  setFilter: React.Dispatch<React.SetStateAction<FilterType | null>>;
  trainingStatus: Number;
  setTrainingStatus: React.Dispatch<React.SetStateAction<Number>>;
  resetPagination: () => void;
}
export interface Section {
  commoditySectionId: string;
  name: string;
}
export interface ClassifiedItem {
  cusCustomerUserId: string;
  userIdentityToken: string;
  username: string;
}

export interface searchValueProps {
  classificationWorkflowTypeId: number;
  hscodePredictionClassificationTypeId: number;
  hscodeSearchId: number;
  providedNewHscode: string;
  selectedHscodeSearchResultId: number;
}

export interface HSCodeSearchResult {
  chapterName: string | null;
  chapterNumber: number;
  commodityName: string | null;
  confidenceScore: number;
  correctHSCode?: boolean;
  createdBy: string;
  createdDate: number; // Timestamp
  headingName: string;
  headingNumber: number;
  hsCode: string;
  hsCodeResultKey: string;
  hscodeDescription: string;
  hscodeSearchRatingComment: string | null;
  hscodeSearchRatingTypeId: string | null;
  hscodeSearchResultId: number;
  isActive: number;
  isFavourite: number;
  modifiedBy: string;
  modifiedDate: number; // Timestamp
  rank: number;
  sectionName: string;
  sectionNumber: number;
  version: number;
}

export interface HSCodeDetailProps {
  hsName: string;
  hscodeDescription: string;
  hsCode: string;
  sectionNumber: string;
  headingNumber: string;
  chapterNumber: string;
  customsDuty: string;
  exciseDuty: string;
  restricted: string;
  countriesFreeTrade: string;
  applicableExemptions: string;
  measurementUnit: string;
  permitIssuingAuthorities: string;
  sectionName: string;
  headingName: string;
}

interface ClassificationWorkflowActionsType {
  classificationWorkflowActionsTypeId: number;
}
interface ClassificationWorkflowType {
  classificationWorkflowTypeId: number;
}
interface ClassifiedUser {
  username: string;
}
export interface HSCodeSearchWorkFlowLogItem {
  classificationWorkflowTypeId: ClassificationWorkflowType;
  classificationWorkflowActionsType: ClassificationWorkflowActionsType;
  classifiedByUserId: ClassifiedUser;
  dateClassified?: string; // Optional since it may not always be present
}
export interface DataItemProps {
  hsCodeSearchWorkFlowLog: HSCodeSearchWorkFlowLogItem[];
}
