import {
  CustomerUserControllerApi,
  HscodeSearchControllerApi,
} from "../../../../api";
import { AxiosResponse } from "axios";
import { FilterType } from "../interfaces";

export interface getSections {
  commoditySectionId?: number;
  description?: string;
  name?: string;
}
// Initializing API clients
const SearchAPI = new HscodeSearchControllerApi();
const UserAPI = new CustomerUserControllerApi();

export const formatDate = (date: Date) => {
  const year = date.getFullYear();
  const month = (date.getMonth() + 1).toString().padStart(2, "0"); // Ensures month is always two digits
  const day = date.getDate().toString().padStart(2, "0"); // Ensures day is always two digits
  const hours = date.getHours().toString().padStart(2, "0"); // Ensures hours are two digits
  const minutes = date.getMinutes().toString().padStart(2, "0"); // Ensures minutes are two digits
  const seconds = date.getSeconds().toString().padStart(2, "0"); // Ensures seconds are two digits

  return `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`;
};

export const formatDateAPI = (date: Date) => {
  const year = date.getFullYear();
  const month = (date.getMonth() + 1).toString().padStart(2, "0"); // Ensures month is two digits
  const day = date.getDate().toString().padStart(2, "0"); // Ensures day is two digits
  return `${year}/${month}/${day}`; // Returns the formatted date string
};

/**
 * Fetches commodity sections data from the API.
 * @returns The first commodity section from the API response, or an empty array in case of an error.
 */

export const getSections = async () => {
  try {
    const response: AxiosResponse = await SearchAPI.getCommoditySections();
    return response.data.responseObject?.[0];
  } catch (e) {
    return []; // Returns an empty array in case of an error
  }
};

/**
 * Fetches an image by its key from the API.
 * @param name - The key of the image to fetch.
 * @returns The image URL or a placeholder image URL in case of an error.
 */

export const getImageByKey = async (name: string) => {
  try {
    const response: AxiosResponse = await SearchAPI.getImage(name);
    return response.data.responseObject[0];
  } catch (e) {
    return "media/place-holder/ImagePlaceholder.svg"; // Returns a placeholder image URL in case of an error
  }
};

/**
 * Fetches internal classified users from the API.
 * @returns The first internal user data from the API response, or an empty array in case of an error.
 */

export const getClassified = async () => {
  try {
    const response: AxiosResponse = await UserAPI.getInternalUsers();
    return response.data.responseObject[0];
  } catch (e) {
    return [];
  }
};

/**
 * Fetches HS code search history log items from the API based on filters, pagination, and item count.
 * @param filters - Filter object containing various filter criteria.
 * @param itemPerPage - Number of items per page.
 * @param currentPage - The current page number for pagination.
 * @returns The first page of log items, or an empty array in case of an error.
 */

export const getItems = async (
  filters: FilterType,
  trainingStatus: number,
  itemPerPage: number,
  currentPage: number
) => {
  try {
    const response: AxiosResponse = await SearchAPI.getHsCodeSearchHistoryLog(
      itemPerPage,
      currentPage - 1,
      filters.startDate.toString(),
      filters.endDate.toString(),
      undefined,
      undefined,
      filters.hscodeFilter || undefined,
      filters.sectionId || undefined,
      trainingStatus.toString(),
      filters.classifiedBy || undefined,
      true
    );
    return response.data.responseObject[0];
  } catch (e) {
    return [];
  }
};

export const updateClassification = async ({
  hsCodeSearchId,
  searchTextTraining,
  trainingStatus,
  hsCode,
  hsCodeDescription,
}: any) => {
  try {
    const response: AxiosResponse = await SearchAPI.updateTrainingStatus(
      hsCodeSearchId,
      searchTextTraining,
      trainingStatus,
      hsCode,
      hsCodeDescription
    );
    return response.data.responseObject[0];
  } catch (e) {
    return [];
  }
};
export const getSimilarTrainingData = async (searchTrainingText: any) => {
  try {
    const response: AxiosResponse = await SearchAPI.getSimilarTrainingData(
      searchTrainingText
    );
    return response.data.responseObject[0];
  } catch (e) {
    return [];
  }
};
