import { HscodeSearchControllerApi } from "../../../../api";
import { FilterType, updateFilterType } from "../components/interfaces";
import { AxiosResponse, AxiosError } from "axios";
import { showToast } from "../../../components/toast/toastUtil";

// Initialize the API instance for making requests
const API = new HscodeSearchControllerApi();

// Utility function to format date and time into 'YYYY/MM/DD HH:MM:SS'
export const formatDate = (date: Date) => {
  const year = date.getFullYear();
  const month = (date.getMonth() + 1).toString().padStart(2, "0");
  const day = date.getDate().toString().padStart(2, "0");
  const hours = date.getHours().toString().padStart(2, "0");
  const minutes = date.getMinutes().toString().padStart(2, "0");
  const seconds = date.getSeconds().toString().padStart(2, "0");

  return `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`;
};

// Utility function to format a date for API requests as 'YYYY/MM/DD'
export const formatDateAPI = (date: Date) => {
  const year = date.getFullYear();
  const month = (date.getMonth() + 1).toString().padStart(2, "0");
  const day = date.getDate().toString().padStart(2, "0");
  return `${year}/${month}/${day}`;
};

// Function to fetch a list of HS Code search history items based on filters, pagination, etc.
export const getItems = async (
  filters: FilterType,
  itemPerPage: number,
  currentPage: number
) => {
  try {
    const response: AxiosResponse = await API.getHscodeSearchHistoryList(
      itemPerPage,
      currentPage - 1,
      filters.startDate.toString(),
      filters.endDate.toString(),
      undefined,
      undefined,
      filters.hscodeFilter || undefined,
      filters.sectionId || undefined,
      filters.workflowStatus || undefined
    );
    return response.data.responseObject[0];
  } catch (e) {
    return [];
  }
};

// Function to fetch all sections for commodities
export const getSections = async () => {
  try {
    const response: AxiosResponse = await API.getCommoditySections();
    return response.data.responseObject[0];
  } catch (e) {
    return [];
  }
};

// Function to fetch all classified sections (similar to getSections)
export const getClassified = async () => {
  try {
    const response: AxiosResponse = await API.getCommoditySections();
    return response.data.responseObject[0];
  } catch (e) {
    return [];
  }
};

// Function to search HS Code by its code
export const searchHSCodeByCode = async (name: string) => {
  try {
    const response: AxiosResponse = await API.searchCommodityByCode(
      name.toLowerCase()
    );
    return response.data.responseObject[0];
  } catch (e) {
    return [];
  }
};
// Function to fetch an image by its key
export const getImageByKey = async (name: string) => {
  try {
    const response: AxiosResponse = await API.getImage(name);
    return response.data.responseObject[0];
  } catch (e) {
    return "media/place-holder/ImagePlaceholder.svg";
  }
};
// Function to search HS Code (same as searchHSCodeByCode but might be used in different context)
export const searchHSCode = async (name: string) => {
  try {
    const response: AxiosResponse = await API.getCommodityByCode(name);
    return response.data.responseObject[0];
  } catch (e) {
    return [];
  }
};

// Function to search for similar words to the given name (for HS Code suggestions)
export const similarSearch = async (name: string) => {
  try {
    const response: AxiosResponse = await API.getSimilarWords(name);
    return response.data.responseObject[0];
  } catch (e) {
    return [];
  }
};

// Function to update the HS Code classification based on provided filters
export const updateHSCodeClassification = async (filter: updateFilterType) => {
  try {
    const response: AxiosResponse = await API.updateHSCodeClassification(
      filter.hscodeSearchId,
      filter.hscodePredictionClassificationTypeId,
      filter.classificationWorkflowTypeId,
      filter.selectedHscodeSearchResultId,
      filter.providedNewHscode
    );
    showToast("success", response.data.responseDescription || "Success"); // Show success toast on completion
    return response.data.responseObject[0]; // Return the first item in the response array
  } catch (error: unknown) {
    // Error handling for failed request
    if (error instanceof AxiosError && error.response) {
      showToast(
        "error",
        error.response.data?.responseDescription || "Something went wrong!"
      );
    } else {
      showToast("error", "Something went wrong!");
    }
    return [];
  }
};
