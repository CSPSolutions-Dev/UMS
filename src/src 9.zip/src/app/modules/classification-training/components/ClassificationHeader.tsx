import { useEffect, useState } from "react";
import { formatDateAPI, getSections } from "../services";
import DateRangeSelector from "../../../components/dateRangePicker/DateRangeSelector";
// import { Section } from "./interfaces";
import { useAuth } from "../../auth";

interface Filter {
  startDate: string;
  endDate: string;
  hscodeFilter: string;
  sectionId: string;
  workflowStatus: number | null;
}
interface ClassificationHeaderProps {
  setFilter: (filter: Filter) => void;
  resetPagination: () => void;
  count: number;
}

// Interface for date state
interface DateState {
  startDate: Date;
  endDate: Date;
}

// Interface for workflow status
interface WorkFlowData {
  canClassify: boolean;
  canRead: boolean;
  canReject: boolean;
  classificationWorkflowTypeId: number;
  appRoleId: number;
}

export interface Section {
  commoditySectionId: string;
  name: string;
}

// Define the ClassificationHeader component with props
const ClassificationHeader: React.FC<any> = ({
  setFilter,
  resetPagination,
  count,
}) => {
  // Function to get the start of the month for a given date
  const getStartOfMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth(), 1);
  };
  // Function to get the end of the month for a given date
  const getEndOfMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0);
  };
  // State to manage date range for filtering
  const [dateState, setDateState] = useState<DateState>({
    startDate: getStartOfMonth(new Date()),
    endDate: getEndOfMonth(new Date()),
  });
  // Authentication hook to get current user data
  const { currentUser } = useAuth();

  // State to manage workflow status and section filtering
  const [status, setStatus] = useState<number | null>(0);
  const [section, setSection] = useState<string>("");
  const [hsCode, setHsCode] = useState<string>("");

  // State to manage list of sections
  const [sectionsList, setSectionsList] = useState<Section[]>([]);

  // Effect to fetch and sort sections on component mount
  useEffect(() => {
    getSections().then((res) => {
      setSectionsList(sortTitle(res));
    });
  }, []);
  // State to manage user's workflows
  const [currentUserWorkFLow, setCurrentUserWorkflow] = useState<
    WorkFlowData[]
  >([]);
  // console.log("currentUserWorkFLow", currentUserWorkFLow);

  // Effect to update status based on current user workflows
  useEffect(() => {
    if (currentUserWorkFLow && currentUserWorkFLow.length) {
      const setData = currentUserWorkFLow.find(
        (item: WorkFlowData) => item.canRead == true
      );
      // If setData is not undefined, set the status
      if (setData) {
        setStatus(setData.classificationWorkflowTypeId);
      }
    }
  }, [currentUserWorkFLow]);

  // Effect to filter workflows based on user's app role
  useEffect(() => {
    if (currentUser?.workflows && currentUser?.workflows?.length) {
      setCurrentUserWorkflow(
        currentUser?.workflows.filter(
          (item: WorkFlowData) =>
            item?.appRoleId == Math.max(...currentUser?.appRoleId)
        )
      );
    }
  }, [currentUser?.workflows]);

  // Effect to apply filter changes when status changes
  useEffect(() => {
    if (status != 0) {
      handleFilterChange();
    }
  }, [status]);

  // Function to handle filter change and reset pagination
  const handleFilterChange = () => {
    setFilter({
      endDate: formatDateAPI(dateState.endDate),
      startDate: formatDateAPI(dateState.startDate),
      hscodeFilter: hsCode,
      sectionId: section,
      workflowStatus: status,
    });
    resetPagination();
  };

  // Function to handle reset action
  const handleReset = async () => {
    setHsCode("");
    setSection("");
    setStatus(1);
    setDateState({
      startDate: getStartOfMonth(new Date()),
      endDate: getEndOfMonth(new Date()),
    });
    setFilter({
      startDate: formatDateAPI(getStartOfMonth(new Date())),
      endDate: formatDateAPI(getEndOfMonth(new Date())),
      hscodeFilter: "",
      sectionId: "",
      workflowStatus: 1,
    });
    resetPagination(); // Reset pagination in the parent component
  };

  // Function to sort sections by title
  const sortTitle = (commodities: any) => {
    commodities.sort((a: any, b: any) => {
      const nameA = a.name.toUpperCase();
      const nameB = b.name.toUpperCase();
      if (nameA < nameB) {
        return -1;
      }
      if (nameA > nameB) {
        return 1;
      }
      return 0;
    });
    return commodities;
  };

  return (
    <>
      <div className="row align-items-center mb-6">
        <div className="col-12 col-md-3">
          <h2>HS Code Classification Training</h2>
        </div>

        <div className="col-12 col-md-9 d-md-flex d-block align-items-center justify-content-md-end gap-3">
          <div className="col-md-2 col-12  mb-md-0 mb-3">
            <select
              className="form-select form-select-white fs-6 fw-normal"
              aria-label="Select example"
              onChange={(e) => {
                setSection(e.target.value);
              }}
              value={section}
            >
              <option value={""}>Filter by Section</option>
              {sectionsList.map((item) => (
                <option
                  title={item.name}
                  value={item.commoditySectionId}
                  key={`section-${item.commoditySectionId}`}
                >
                  {item.name.length > 20
                    ? item.name.slice(0, 20) + "..."
                    : item.name}
                </option>
              ))}
            </select>
          </div>

          <div className="col-md-2 col-12  mb-md-0 mb-3">
            <input
              value={hsCode}
              onChange={(e) => {
                // Validate HS Code input length and value
                if (
                  (e.target.value.length <= 10 && Number(e.target.value)) ||
                  e.target.value == ""
                ) {
                  setHsCode(e.target.value);
                }
              }}
              type="text"
              className="form-control fs-6 fw-normal"
              placeholder="Filter by HS Code"
            />
          </div>

          <div className="mb-md-0 mb-3">
            <DateRangeSelector
              onSubmit={({ startDate, endDate }) => {
                setDateState({
                  startDate,
                  endDate,
                });
              }}
              ranges={dateState}
            />
          </div>

          <div className="mb-md-0 mb-3">
            <button
              className="btn btn-primary fs-6 w-100px  fw-normal"
              onClick={handleFilterChange}
            >
              Filter
            </button>
          </div>
          <div className="d-grid gap-2">
            <button
              onClick={handleReset}
              type="button"
              className="btn btn-outline btn-outline-solid btn-outline-primary btn-active-light-primary"
            >
              Reset
            </button>
          </div>
        </div>
        <div className="col-12 col-md-11 mt-5 d-md-flex d-block align-items-center justify-content-md-end gap-3">
          {currentUserWorkFLow?.length &&
            currentUserWorkFLow?.find(
              (item: WorkFlowData) => item.classificationWorkflowTypeId == 1
            )?.canRead && (
              <div className="form-check form-check-custom form-check-solid form-check-sm mb-2">
                <input
                  className="form-check-input"
                  type="radio"
                  value=""
                  name="status"
                  checked={status == 1 ? true : false}
                  onClick={() => {
                    setStatus(1);
                  }}
                  id="flexRadioSm"
                />
                <label
                  className="form-check-label text-dark"
                  htmlFor="flexRadioLg"
                >
                  Pending Classification {status == 1 ? `(${count})` : ""}
                </label>
              </div>
            )}
          {currentUserWorkFLow?.length &&
            currentUserWorkFLow?.find(
              (item: WorkFlowData) => item.classificationWorkflowTypeId == 2
            )?.canRead && (
              <div className="form-check form-check-custom form-check-solid form-check-sm mb-2">
                <input
                  className="form-check-input"
                  type="radio"
                  value=""
                  name="status"
                  checked={status == 2 ? true : false} // Check if current status matches
                  onClick={() => {
                    setStatus(2);
                  }}
                  id="flexRadioSm"
                />
                <label
                  className="form-check-label text-dark"
                  htmlFor="flexRadioLg"
                >
                  Pending Verification {status == 2 ? `(${count})` : ""}
                </label>
              </div>
            )}
          {currentUserWorkFLow?.length &&
            currentUserWorkFLow?.find(
              (item: WorkFlowData) => item.classificationWorkflowTypeId == 3
            )?.canRead && (
              <div className="form-check form-check-custom form-check-solid form-check-sm mb-2">
                <input
                  className="form-check-input"
                  type="radio"
                  value=""
                  name="status"
                  checked={status == 3 ? true : false}
                  onClick={() => {
                    setStatus(3);
                  }}
                  id="flexRadioSm"
                />
                <label
                  className="form-check-label text-dark"
                  htmlFor="flexRadioLg"
                >
                  Classification Complete {status == 3 ? `(${count})` : ""}
                </label>
              </div>
            )}
          <div className="form-check form-check-custom form-check-solid form-check-sm mb-2">
            <input
              className="form-check-input"
              type="radio"
              name="status"
              checked={!status ? true : false}
              onClick={() => {
                setStatus(null);
              }}
              value=""
              id="flexRadioSm"
            />
            <label className="form-check-label text-dark" htmlFor="flexRadioLg">
              All {!status ? `(${count})` : ""}
            </label>
          </div>
        </div>
      </div>
    </>
  );
};

export { ClassificationHeader };
