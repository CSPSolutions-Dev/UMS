import { useState } from "react";
import { ModalProps } from "./interfaces";
// Define the Model component with the specified props
const Model: React.FC<ModalProps> = ({
  cancelButton,
  message,
  makeAPICall,
}) => {
  const [loader, setLoader] = useState(false);
  return (
    <>
      {/* Modal container */}
      <div
        className="modal show"
        style={{
          display: "block",
          backgroundColor: "rgba(0, 0, 0, 0.5)",
        }}
      >
        <div className="modal-dialog modal-dialog-centered  modal-md">
          <div className="modal-content">
            {/* Modal header */}
            <div className="modal-header p-5">
              <h5 className="modal-title">Please Confirm</h5>
            </div>
            {/* Modal body */}
            <div className="modal-body">{message}</div>
            {/* Modal footer with action buttons */}
            <div className="modal-footer p-5">
              <button
                type="submit"
                disabled={loader ? true : false}
                onClick={() => {
                  setLoader(true);
                  makeAPICall();
                }}
                className="btn btn-primary"
              >
                {loader ? (
                  <>
                    <span className="spinner-border spinner-border-sm align-middle"></span>
                  </>
                ) : (
                  "Yes"
                )}
              </button>
              <button
                type="button"
                disabled={loader ? true : false}
                className="btn btn-light"
                onClick={cancelButton} // Call cancelButton callback when clicked
              >
                No
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export { Model };
