import { Grid, GridColumn } from "@progress/kendo-react-grid";
import React, { useEffect, useState } from "react";
import { TextArea } from "@progress/kendo-react-inputs";
import {
  getItems,
  formatDate,
  updateHSCodeClassification,
  similarSearch,
  searchHSCodeByCode,
  getImageByKey,
  searchHSCode,
} from "../services";
import AsyncSelect from "react-select/async";
import { components } from "react-select";
import { Model } from "./ConfirmModel";
import { AlertModel } from "./AlertModel";
import { useAuth } from "../../auth";
import { Dialog } from "@progress/kendo-react-dialogs";
// import { FilterType } from "./interfaces"

// Props interface for HSCodeClassificationTraining component
interface HSCodeClassificationTrainingProps {
  filter: any; // Filter criteria for fetching items
  itemsPerPage: number; // Number of items per page
  currentPage: number; // Current page number
  setTotalElement: (total: number) => void; // Function to set total number of elements
  setCount: (count: number) => void; // Function to set count of items
}

// Interface for classificationWorkflowTypeId
interface ClassificationWorkflowType {
  classificationWorkflowTypeId: number;
  status: string;
  createdBy: string;
  createdDate: string; // assuming it's a string date
  modifiedBy: string;
  modifiedDate: string;
  isActive: number;
}

// Interface for cusCustomerUserId
interface CustomerUser {
  cusCustomerUserId: number;
  customerFirstName: string;
  customerMiddleName?: string | null;
  customerLastName: string;
  nationalityCountryId?: number | null;
}

// Interface for hscodeSearchResults (individual result)
interface HSCodeClassification {
  classificationWorkflowTypeId: ClassificationWorkflowType;
  commentNote: string | null;
  createdBy: string;
  createdDate: number;
  cusCustomerUserId: CustomerUser;
  hsCodeSearchWorkFlowLog: any[];
  hsCodeSearchResults: HSCodeSearchResult[]; // Array of your defined HSCodeSearchResult
  hscodeImageAnalysisId?: number | null;
  hscodePredictionClassificationTypeId?: number | null;
  hscodeSearchId: number;
  isActive: number;
  markedInvalidSearch: boolean;
  markedRequiredMoreInfo: boolean;
  modifiedBy: string;
  modifiedDate: number;
  modify: boolean;
  providedNewHscode?: string | null;
  searchText?: string | null;
  searchedDate: number;
  tag?: string | null;
  version: number;
}

interface searchValue {
  classificationWorkflowTypeId: number;
  hscodePredictionClassificationTypeId: number;
  hscodeSearchId: number;
  providedNewHscode: number | null;
  selectedHscodeSearchResultId: number;
}

interface HSCodeSearchResult {
  sectionNumber: number;
  sectionName: string;
  chapterNumber: number;
  chapterName: string;
  headingNumber: number;
  headingName: string;
  hsCode: string;
  hsCodeResultKey: string;
  hscodeDescription: string;
  confidenceScore: number;
  createdBy?: string | null;
  createdDate: number;
  correctHSCode: boolean;
  isActive: number;
  isFavourite: number;
  modifiedBy?: string | null;
  modifiedDate: number;
  rank: number;
  version: number;
  commodityName?: string | null; // Adding the optional field
  hscodeSearchRatingComment?: string | null; // Adding the optional field
  hscodeSearchRatingTypeId?: number | null; // Adding the optional field
  hscodeSearchResultId: number; // Adding this field
}

interface HSCodeClassification {
  classificationWorkflowTypeId: ClassificationWorkflowType;
  commentNote: string | null;
  createdBy: string;
  createdDate: number;
  cusCustomerUserId: CustomerUser;
  hsCodeSearchWorkFlowLog: any[];
  hsCodeSearchResults: HSCodeSearchResult[];
  hscodeImageAnalysisId?: number | null;
  hscodePredictionClassificationTypeId?: number | null;
  hscodeSearchId: number;
  isActive: number;
  markedInvalidSearch: boolean;
  markedRequiredMoreInfo: boolean;
  modifiedBy: string;
  modifiedDate: number;
  modify: boolean;
  providedNewHscode?: string | null;
  searchText?: string | null;
  searchValue?: searchValue;
  searchedDate: number;
  tag?: string | null;
  version: number;
}

interface OpenModal {
  message: string;
  callBack: () => void;
}

interface WorkFlow {
  canClassify: boolean;
  canRead: boolean;
  canReject: boolean;
}

interface WorkFlowData {
  canClassify: boolean;
  canRead: boolean;
  canReject: boolean;
  classificationWorkflowTypeId: number;
  appRoleId: number;
}

const HSCodeClassificationTraining: React.FC<
  HSCodeClassificationTrainingProps
> = ({ filter, itemsPerPage, currentPage, setTotalElement, setCount }) => {
  const [data, setData] = React.useState<HSCodeClassification[]>([]);

  const [defaultData, setDefaultData] = React.useState<HSCodeClassification[]>(
    []
  );

  const [openModal, setOpenModal] = React.useState<OpenModal | null>(null);

  const [openAlertModal, setOpenAlertModal] = useState<string | null>(null);

  const [mainLoader, setMainLoader] = React.useState<boolean>(false);
  const [workFlow, setWorkFlow] = useState<WorkFlow | null>(null);

  const { currentUser } = useAuth();

  // Function to fetch and set items based on filters and pagination
  const getAndSetItems = async () => {
    setCount(0);
    setMainLoader(true);
    await getItems(filter, itemsPerPage, currentPage).then((res: any) => {
      // console.log("res============", res);

      setTotalElement(res?.totalPages);
      setData(res?.content);
      setDefaultData(res?.content);
      setCount(res?.totalElements);
    });
    setMainLoader(false);
  };
  // Fetch items when filter or current page changes
  useEffect(() => {
    if (filter) {
      getAndSetItems();
    }
  }, [filter, currentPage]);

  // Fetch workflow details based on the current user and filter
  useEffect(() => {
    if (currentUser?.workflows?.length && filter?.workflowStatus) {
      const workFLowData: WorkFlowData = currentUser.workflows.find(
        (item: WorkFlowData) =>
          item.classificationWorkflowTypeId == filter.workflowStatus
      );

      setWorkFlow((prev: WorkFlow | null) =>
        workFLowData?.classificationWorkflowTypeId
          ? {
              canClassify: workFLowData.canClassify,
              canRead: workFLowData.canRead,
              canReject: workFLowData.canReject,
            }
          : null
      );
    } else {
      setWorkFlow(null);
    }
  }, [currentUser.workflows, filter?.workflowStatus]);

  // Update data with new information or reset to default
  const updateItem = (
    id: string,
    newData: Partial<HSCodeClassification>,
    isCancel: boolean = false
  ) => {
    const updatedData = data.map((item: any) =>
      item.hscodeSearchId === id ? { ...item, ...newData } : item
    );
    // If cancel is true, reset to default data, otherwise set updated data
    isCancel ? setData(defaultData) : setData(updatedData);
  };
  // Styling for the grid
  const gridClass: React.CSSProperties = {
    width: "100%",
    margin: "0 auto",
    overflowX: "auto",
  };

  const SearchByUser = (dataItem: any) => {
    // console.log("dataItem", dataItem);

    // State to store the image data
    const [image, setImage] = useState<any>("");
    // State to manage the visibility of the image dialog
    const [isOpen, setIsOpen] = useState(false);

    // Fetch image data when dataItem changes
    useEffect(() => {
      if (dataItem?.hscodeImageAnalysisId?.imageKey) {
        // Get the image by its key and set it as a base64 encoded string
        getImageByKey(dataItem?.hscodeImageAnalysisId?.imageKey).then((res) => {
          setImage(`data:image/jpeg;base64,${res}`);
        });
      }
    }, [dataItem]);
    return (
      <td className="position-relative text-center border-top py-6 align-top">
        <div className="px-4">
          {/* Display search text in a readonly TextArea */}
          <TextArea
            value={dataItem?.searchText}
            rows={5}
            placeholder="Type here ..."
            readOnly
            style={{
              color: "black",
              fontWeight: 500,
              borderRadius: 6,
              overflowY: "auto",
              borderColor: "1px solid #DEE2E6",
            }}
          />
          {/* Conditionally render the image if available */}
          {image && (
            <>
              <img
                src={image}
                alt="photo"
                style={{
                  cursor: "pointer",
                  width: "100%",
                  marginTop: 10,
                  maxHeight: 150,
                  maxWidth: 150,
                }}
                onClick={() => setIsOpen(true)}
              />
              {/* Display the image in a dialog when isOpen is true */}
              {isOpen && (
                <Dialog
                  title={dataItem?.searchText}
                  onClose={() => setIsOpen(false)}
                  width="80%"
                  height="80%"
                >
                  <img
                    src={image}
                    style={{ width: "100%", maxHeight: "200%" }}
                    alt={dataItem?.searchText}
                  />
                </Dialog>
              )}
            </>
          )}
          <hr className="border-gray-300 border" />
          <div className="text-start text-black fs-7">
            {/* Display the username or 'Guest' if username is not available */}
            {dataItem?.cusCustomerUserId?.username
              ? dataItem?.cusCustomerUserId?.username
              : "Guest".toUpperCase()}
          </div>
          <div className="text-start fs-6 text-gray-500">
            {/* Format and display the creation date */}
            {formatDate(new Date(dataItem?.createdDate))}
          </div>
        </div>
      </td>
    );
  };
  // Custom styles for the react-select component
  const customStyles = {
    // Customize the menu style of the select component
    menu: (provided: any) => ({
      // Spread the default provided styles to retain the base styling
      ...provided,
      // Set the z-index to ensure the menu appears above other elements
      zIndex: 9999,
    }),
  };

  const CustomMenuList = (props: any) => {
    // Extract children and rest of the props
    const { children, ...rest } = props;
    // Determine max height of the menu list based on the number of items
    const maxHeight = children.length > 2 ? "150px" : "auto"; // Adjust based on number of items
    // Function to handle scroll events, prevents scroll event from propagating
    const handleScroll = (e: React.WheelEvent) => {
      e.stopPropagation(); // Stops the event from bubbling up the DOM tree
    };
    return (
      <components.MenuList
        {...props}
        // className="custom-scrollbar"
        onWheel={handleScroll}
        style={{ maxHeight }}
      >
        {props.children} {/* Render the children passed to this component */}
      </components.MenuList>
    );
  };

  const HsCodeDetails = (dataItem: any, index: any) => {
    // Function to fetch HS Code options based on input value
    const promiseOptions = async (inputValue: string) => {
      const value: any = await searchHSCodeByCode(inputValue);
      // console.log("value", value);

      // Map the response to format the options for the dropdown
      return value.map((item: any) => ({
        value: item.hsCode,
        label: `${item.hsCode} - ${item.hsCodeName}`,
      }));
    };
    // State to manage the current search value and selected HS Code
    const [searchValue, setSearchValue] = useState<any>(() => {
      if (dataItem.searchValue) {
        return { ...dataItem.searchValue };
      } else {
        // Find the correct result if available
        const correctResult = dataItem?.hscodeSearchResults?.find(
          (result: any) => result.correctHSCode
        );
        // Set the initial search value based on dataItem
        return {
          classificationWorkflowTypeId:
            dataItem?.classificationWorkflowTypeId
              ?.classificationWorkflowTypeId,
          hscodePredictionClassificationTypeId:
            dataItem?.hscodePredictionClassificationTypeId
              ?.hscodePredictionClassificationTypeId,
          hscodeSearchId: dataItem?.hscodeSearchId,
          providedNewHscode: dataItem?.providedNewHscode,
          selectedHscodeSearchResultId: correctResult
            ? correctResult.hscodeSearchResultId
            : dataItem?.hscodeSearchResults[0]?.hscodeSearchResultId,
        };
      }
    });
    // State to manage the default HS Code value
    const [defaultValue, setDefaultValue] = useState<any>(null);
    const [newCodeDetail, setNewCodeDetail] = useState<any>(null);
    // Effect to fetch and set the default HS Code details
    useEffect(() => {
      const fetchDefaultHSCode = async () => {
        if (dataItem?.providedNewHscode || searchValue.providedNewHscode) {
          try {
            const defDetail = await searchHSCode(
              dataItem?.providedNewHscode || searchValue.providedNewHscode
            );
            if (defDetail) {
              setNewCodeDetail(defDetail);
              setDefaultValue({
                value: defDetail.hsCode,
                label: `${defDetail.hsCode} - ${defDetail.hsName}`,
              });
            }
          } catch (error) {
            console.error("Error fetching default HSCode:", error);
          }
        }
      };

      fetchDefaultHSCode();
    }, [dataItem?.providedNewHscode, searchValue]);
    // Effect to update the item when search value changes
    useEffect(() => {
      if (
        !dataItem.searchValue ||
        JSON.stringify(dataItem.searchValue) != JSON.stringify(searchValue)
      ) {
        // Update the data item with the new search value
        updateItem(dataItem.hscodeSearchId, {
          ...dataItem,
          providedNewHscode: searchValue.providedNewHscode,
          searchValue: searchValue,
          modify:
            dataItem?.modify != undefined
              ? dataItem.modify
              : dataItem?.classificationWorkflowTypeId
                  ?.classificationWorkflowTypeId == 1
              ? false
              : true,
        });
      }
    }, [searchValue]);
    return (
      <>
        <td className="border-top pt-6 pb-18 px-3 min-w-80 align-top">
          {/* Render a list of HS Code search results */}
          {dataItem?.hscodeSearchResults?.map((item: any, index: number) => {
            // console.log("hscodeSearchResults", item);

            return (
              <div
                key={"HsCodeDetails" + index}
                className="d-flex mb-1 justify-content-between border-bottom border-none p-3 bg-light rounded min-h-80px ml-4"
              >
                <div
                  style={
                    dataItem?.modify || !filter?.workflowStatus
                      ? {
                          pointerEvents: "none",
                          opacity: 0.7,
                        }
                      : {}
                  }
                  className="d-flex gap-5"
                  key={`training-${index}`}
                >
                  {/* Radio button to select HS Code */}
                  <div className="form-check justify-content-center form-check-custom form-check-solid form-check-sm">
                    <input
                      onChange={(e: any) => {
                        if (e.target.checked) {
                          setSearchValue((prev: any) => ({
                            ...prev,
                            hscodePredictionClassificationTypeId: 1,
                            selectedHscodeSearchResultId:
                              item.hscodeSearchResultId,
                            providedNewHscode: null,
                          }));
                        }
                      }}
                      className="form-check-input"
                      type="radio"
                      id={"flexRadioChecked" + index}
                      checked={
                        searchValue.selectedHscodeSearchResultId ===
                          item.hscodeSearchResultId &&
                        searchValue.hscodePredictionClassificationTypeId == 1
                          ? true
                          : false
                      }
                    />
                  </div>
                  <div className="d-flex align-items-center justify-content-center">
                    <h4 className="text-gray-500">0{++index}</h4>
                  </div>
                  <div className="">
                    <div className="">
                      <span className="fw-bolder ">{item?.hsCode} : </span>
                      <span className="fw-normal text-gray-500">
                        {item?.hscodeDescription}
                      </span>{" "}
                    </div>
                    <div className="">
                      <span className="fw-bolder">Heading :</span>{" "}
                      {item?.headingName}
                    </div>
                    <div className="">
                      <span className="fw-bolder">Section : </span>
                      {item?.sectionName}
                    </div>
                    <div className="">
                      <span className="fw-bolder">Confidence : </span>
                      {item.confidenceScore
                        ? (item.confidenceScore * 100).toFixed(2)
                        : 0.0}
                      %
                    </div>
                  </div>
                </div>
                <div
                  className="d-inline-grid"
                  style={{ alignContent: "space-between" }}
                >
                  <div
                    style={{
                      display: "inline-flex",
                      justifyContent: "flex-end",
                    }}
                    title="Favorite"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      fill="currentColor"
                      className={`bi bi-star-fill ${
                        item.isFavourite ? "text-warning" : "text-secondary"
                      }`}
                      viewBox="0 0 16 16"
                    >
                      <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.282.95l-3.522 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z" />
                    </svg>
                  </div>
                  <div style={{ fontSize: "5px", display: "flex" }}>
                    {item.hscodeSearchRatingComment && (
                      <i
                        onClick={() => {
                          setOpenAlertModal(item.hscodeSearchRatingComment);
                        }}
                        style={{ fontSize: "1.1rem", cursor: "pointer" }}
                        className="fa-regular me-3 fa-message"
                        title={item.hscodeSearchRatingComment}
                      />
                    )}
                    {item.hscodeSearchRatingTypeId?.hscodeSearchRatingTypeId ==
                      1 && (
                      <i
                        style={{ fontSize: "1.2rem" }}
                        className="fa-solid fa-thumbs-up"
                        title="Correct"
                      />
                    )}
                    {item.hscodeSearchRatingTypeId?.hscodeSearchRatingTypeId ==
                      2 && (
                      <i
                        style={{ fontSize: "1.2rem" }}
                        className="fa-solid fa-thumbs-down"
                        title="Incorrect"
                      />
                    )}
                    {item.hscodeSearchRatingTypeId?.hscodeSearchRatingTypeId ==
                      3 && (
                      <i
                        style={{ fontSize: "1.2rem" }}
                        className="fa-solid fa-circle-question"
                        title={`I don't know`}
                      />
                    )}
                  </div>
                </div>
              </div>
            );
          })}
          {/* Radio button for "Provide new" HS Code */}
          <div
            style={
              dataItem?.modify || !filter?.workflowStatus
                ? {
                    pointerEvents: "none",
                    opacity: 0.7,
                    alignItems: "center",
                  }
                : {
                    alignItems: "center",
                  }
            }
            className="d-flex gap-0 mb-1 h-50px border-bottom border-none p-3 bg-light fs-6 text-gray-900 bg-grey rounded form-check form-check-sm form-check-custom form-check-solid"
          >
            {/* <div
              style={
                dataItem?.modify || !filter?.workflowStatus
                  ? {
                      pointerEvents: "none",
                      opacity: 0.7,
                    }
                  : {}
              }
              // className="form-check form-check-sm form-check-custom form-check-solid position-absolute"
            > */}
            <input
              className="form-check-input form-check form-check-sm form-check-custom form-check-solid"
              type="radio"
              value=""
              onChange={(e) => {
                if (e.target.checked) {
                  setSearchValue((prev: any) => ({
                    ...prev,
                    hscodePredictionClassificationTypeId: 2,
                    selectedHscodeSearchResultId: null,
                    providedNewHscode: null,
                  }));
                }
              }}
              checked={searchValue.hscodePredictionClassificationTypeId == 2}
            />
            <span
              className="mx-3 text-nowrap fs-6 text-black"
              style={{ fontWeight: 600 }}
            >
              Provide new
            </span>
            <AsyncSelect
              className="form-control-md w-100"
              isDisabled={
                searchValue?.hscodePredictionClassificationTypeId !== 2
              }
              value={
                defaultValue &&
                searchValue?.hscodePredictionClassificationTypeId == 2
                  ? defaultValue
                  : undefined
              }
              noOptionsMessage={() => "Search by HS Code Number or Description"}
              menuPlacement={"top"}
              onChange={(value: any) => {
                setDefaultValue(null);
                setSearchValue((prev: any) => ({
                  ...prev,
                  hscodePredictionClassificationTypeId: 2,
                  selectedHscodeSearchResultId: null,
                  providedNewHscode: value.value,
                }));
              }}
              loadOptions={promiseOptions}
              styles={customStyles}
              components={{ MenuList: CustomMenuList }}
            />
            {newCodeDetail && (
              <i
                className="ki-outline  ki-question-2 fs-1x"
                style={{
                  fontSize: "14px",
                  fontWeight: "bolder",
                  marginLeft: "1rem",
                }}
                title={`${newCodeDetail?.hsCode} : ${newCodeDetail?.hscodeDescription}\nHeading : ${newCodeDetail?.headingName}\nSection : ${newCodeDetail?.sectionName}`}
              ></i>
            )}
          </div>

          {/* </div> */}
          <div
            style={
              dataItem?.modify || !filter?.workflowStatus
                ? {
                    pointerEvents: "none",
                    opacity: 0.7,
                  }
                : {}
            }
          >
            <div className="d-flex mb-1 border-bottom border-none p-3 bg-light fs-6 text-gray-900 rounded ">
              <div className="form-check justify-content-center form-check-custom form-check-solid form-check-sm">
                <input
                  className="form-check-input"
                  type="radio"
                  value=""
                  id="flexRadioSm"
                  onChange={(e) => {
                    if (e.target.checked) {
                      setSearchValue((prev: any) => ({
                        ...prev,
                        hscodePredictionClassificationTypeId: 3,
                        selectedHscodeSearchResultId: null,
                        providedNewHscode: null,
                      }));
                    }
                  }}
                  checked={
                    searchValue.hscodePredictionClassificationTypeId == 3
                  }
                />
              </div>
              <span
                className="mx-3 fs-6 text-black"
                style={{ fontWeight: 600 }}
              >
                Provided description is not enough to correctly classify the
                goods (to be discarded).
              </span>
            </div>
            <div className="d-flex mb-1 border-bottom border-none p-3 bg-light fs-6 text-gray-900 rounded ">
              <div className="form-check justify-content-center form-check-custom form-check-solid form-check-sm">
                <input
                  className="form-check-input"
                  type="radio"
                  value=""
                  id="flexRadioSm"
                  onChange={(e) => {
                    if (e.target.checked) {
                      setSearchValue((prev: any) => ({
                        ...prev,
                        hscodePredictionClassificationTypeId: 4,
                        selectedHscodeSearchResultId: null,
                        providedNewHscode: null,
                      }));
                    }
                  }}
                  checked={
                    searchValue.hscodePredictionClassificationTypeId == 4
                  }
                />
              </div>

              <span
                className="mx-3 fs-6 text-black"
                style={{ fontWeight: 600 }}
              >
                Provided description of goods is invalid (to be discarded).
              </span>
            </div>
          </div>
        </td>
      </>
    );
  };

  const HsCodeUserDetails = (dataItem: any) => {
    // State to manage loading status for asynchronous operations
    const [loader, setLoader] = useState(false);
    // Function to handle updates for HS code classification
    const handleUpdate = async (query: any) => {
      setLoader(true);
      await updateHSCodeClassification(query);
      await getAndSetItems().then(() => {
        setLoader(false);
        setOpenModal(null);
      });
    };
    // Function to toggle the modify state of an item
    const updateModify = (isCancel: boolean) => {
      updateItem(
        dataItem.hscodeSearchId,
        {
          ...dataItem,
          modify: !dataItem?.modify,
        },
        isCancel
      );
    };
    return (
      <>
        <td className="border-top k-bg-white position-relative py-6 px-3 align-top">
          <div className="fs-6">
            <div className="mb-7">
              {/* Button to classify the item */}
              {dataItem?.classificationWorkflowTypeId
                ?.classificationWorkflowTypeId == 1 &&
                workFlow?.canClassify && (
                  <button
                    type="button"
                    onClick={() => {
                      setOpenModal({
                        message:
                          "Are you sure you want to Classify this User Search ?",
                        callBack: () =>
                          handleUpdate({
                            ...dataItem.searchValue,
                            classificationWorkflowTypeId: 1,
                          }),
                      });
                    }}
                    disabled={
                      loader ||
                      !dataItem?.searchValue
                        ?.hscodePredictionClassificationTypeId ||
                      (dataItem?.searchValue
                        ?.hscodePredictionClassificationTypeId == 2 &&
                        !dataItem?.searchValue?.providedNewHscode)
                        ? true
                        : false
                    }
                    className="btn btn-primary mb-2 w-100"
                  >
                    {loader ? (
                      <>
                        <span className="spinner-border spinner-border-sm align-middle ms-5 me-5"></span>
                      </>
                    ) : (
                      "Classify"
                    )}
                  </button>
                )}
              {/* Button to approve the classifiation */}
              {dataItem?.classificationWorkflowTypeId
                ?.classificationWorkflowTypeId == 2 &&
                workFlow?.canClassify && (
                  <>
                    <button
                      type="button"
                      disabled={
                        loader ||
                        !dataItem?.searchValue
                          ?.hscodePredictionClassificationTypeId ||
                        (dataItem?.searchValue
                          ?.hscodePredictionClassificationTypeId == 2 &&
                          !dataItem?.searchValue?.providedNewHscode)
                          ? true
                          : false
                      }
                      onClick={() => {
                        setOpenModal({
                          message:
                            "Are you sure you want to Verify this Classification ?",
                          callBack: () =>
                            handleUpdate({
                              ...dataItem.searchValue,
                              classificationWorkflowTypeId: 1,
                            }),
                        });
                      }}
                      className="btn btn-primary mb-2 w-100"
                    >
                      {loader ? (
                        <>
                          <span className="spinner-border spinner-border-sm align-middle ms-5 me-5"></span>
                        </>
                      ) : (
                        "Verify"
                      )}
                    </button>
                    <button
                      type="button"
                      disabled={loader ? true : false}
                      onClick={async () => {
                        updateModify(!dataItem?.modify);
                      }}
                      className="btn btn-outline btn-outline btn-outline-primary btn-active-light-primary w-100"
                    >
                      {dataItem?.modify ? "Modify" : "Cancel"}
                    </button>
                  </>
                )}
              {/* Buttons for rejecting or signing the classification */}
              {dataItem?.classificationWorkflowTypeId
                ?.classificationWorkflowTypeId == 3 && (
                <>
                  {workFlow?.canClassify && (
                    <button
                      type="button"
                      onClick={() => {
                        setOpenModal({
                          message:
                            "Are you sure you want to Sign this Classification ?",
                          callBack: () =>
                            handleUpdate({
                              ...dataItem.searchValue,
                              classificationWorkflowTypeId: 1,
                            }),
                        });
                      }}
                      className="btn btn-primary w-100 mb-2"
                    >
                      Sign
                    </button>
                  )}
                  {workFlow?.canReject && (
                    <button
                      onClick={() => {
                        setOpenModal({
                          message:
                            "Are you sure you want to Reject this Classification ?",
                          callBack: () =>
                            handleUpdate({
                              ...dataItem.searchValue,
                              classificationWorkflowTypeId: 2,
                            }),
                        });
                      }}
                      type="button"
                      className=" btn btn-outline btn-outline btn-outline-primary btn-active-light-primary w-100"
                    >
                      Reject
                    </button>
                  )}
                </>
              )}
            </div>
            {/* Display workflow log entries */}
            {dataItem?.hsCodeSearchWorkFlowLog.map((item: any, index: any) => {
              if (
                item?.classificationWorkflowTypeId
                  ?.classificationWorkflowTypeId === 2
              ) {
                return (
                  <div key={index}>
                    {" "}
                    <div className="mb-3 d-block">
                      <span className="fw-bolder">
                        {item?.classificationWorkflowActionsType
                          ?.classificationWorkflowActionsTypeId === 1 &&
                          "Classified By"}
                        {item?.classificationWorkflowActionsType
                          ?.classificationWorkflowActionsTypeId === 2 &&
                          "Rejected By"}
                      </span>
                      <br />
                      <span className="fw-normal text-gray-600">
                        {item?.classifiedByUserId?.username}
                      </span>
                    </div>
                    <div className="mb-5">
                      <span className="fw-bolder">
                        {item?.classificationWorkflowActionsType
                          ?.classificationWorkflowActionsTypeId === 1 &&
                          "Date Classified"}
                        {item?.classificationWorkflowActionsType
                          ?.classificationWorkflowActionsTypeId === 2 &&
                          "Date Rejected"}
                      </span>
                      <br />
                      <span className="fw-normal text-gray-600">
                        {item?.dateClassified
                          ? formatDate(new Date(item?.dateClassified))
                          : ""}
                      </span>
                    </div>
                  </div>
                );
              } else if (
                item?.classificationWorkflowTypeId
                  ?.classificationWorkflowTypeId === 3
              ) {
                return (
                  <div key={index}>
                    <div className="mb-3 d-block">
                      <span className="fw-bolder">Verified By</span>
                      <br />
                      <span className="fw-normal text-gray-600">
                        {item?.classifiedByUserId?.username}
                      </span>
                    </div>
                    <div className="mb-5">
                      <span className="fw-bolder">Date Verified</span>
                      <br />
                      <span className="fw-normal text-gray-600">
                        {item?.dateClassified
                          ? formatDate(new Date(item?.dateClassified))
                          : ""}
                      </span>
                    </div>
                  </div>
                );
              } else {
                return null;
              }
            })}
          </div>
        </td>
      </>
    );
  };
  // Define the SimilarCell component
  const SimilarCell = ({ dataItem }: any) => {
    const [similar, setSimilar] = useState("");
    // Effect to fetch similar search results when dataItem changes
    useEffect(() => {
      if (dataItem?.searchText) {
        // Call similarSearch function with searchText and update state with the result
        similarSearch(dataItem?.searchText).then((res) => setSimilar(res));
      }
    }, [dataItem]);
    return (
      <td className="border-top position-relative py-6 align-top">
        <div className="px-4">
          <TextArea
            placeholder=""
            value={similar}
            rows={6}
            readOnly
            cols={20}
            style={{
              color: "black",
              fontWeight: "500",
              borderRadius: 6,
              overflowY: "auto",
              borderColor: "1px solid #DEE2E6",
            }}
          />
        </div>
      </td>
    );
  };

  // Initialize state for minimum width and column width
  const [minWidth, setMinWidth] = useState("1200px");
  const [columnWidth, setColumnWidth] = useState(500);
  // Effect to update widths based on window size
  useEffect(() => {
    // Function to update state based on window width
    const updateMinWidth = () => {
      const width = window.innerWidth;
      // Conditional logic to set minWidth and columnWidth based on window width
      if (width <= 768) {
        setMinWidth("1000px");
        setColumnWidth(500);
      } else if (width <= 1024) {
        setMinWidth("1000px");
        setColumnWidth(500);
      } else if (width <= 1280) {
        setMinWidth("800px");
        setColumnWidth(500);
      } else if (width <= 1440) {
        setMinWidth("900px");
        setColumnWidth(500);
      } else {
        setMinWidth("100%");
        setColumnWidth(700);
      }
    };
    // Call updateMinWidth initially to set the correct values
    updateMinWidth();
    // Add event listener for window resize to update width values dynamically
    window.addEventListener("resize", updateMinWidth);
    // Cleanup event listener on component unmount
    return () => window.removeEventListener("resize", updateMinWidth);
  }, []); // Empty dependency array ensures this effect runs only on mount and unmount
  return (
    <>
      <div className="card" style={gridClass}>
        {mainLoader ? (
          <div className="text-center mt-10">
            <div
              className="spinner-border"
              style={{ width: "3rem", height: "3rem" }}
              role="status"
            >
              <span className="sr-only">Loading...</span>
            </div>
          </div>
        ) : (
          <>
            <Grid
              data={data}
              resizable={false}
              style={{
                minWidth: minWidth,
                width: "100%",
              }}
            >
              {/* Column for displaying user who searched */}
              <GridColumn
                field="searched_by_user"
                title="Searched By User"
                headerClassName="p-6 border-transparent fw-bold border-bottom fs-1 title-custom"
                className="p-3 border-bottom"
                cell={(props) => SearchByUser(props.dataItem)} // Custom cell rendering
              />
              {/* Column for displaying selected HS Code */}
              <GridColumn
                field="selected_hS_code"
                title="Selected HS Code"
                headerClassName="p-6 border-transparent fw-bold border-bottom title-custom"
                cell={(props) => HsCodeDetails(props.dataItem, props)} // Custom cell rendering
                width={columnWidth}
              />
              {/* Column for displaying similar approved searches */}
              <GridColumn
                field="user_favourite"
                title="Similar Approved Searches"
                headerClassName="p-6 border-bottom border-transparent fw-bold border-bottom title-custom "
                cell={SimilarCell} // Custom cell rendering
              />
              {/* Empty column for additional details */}
              <GridColumn
                field=""
                title=""
                headerClassName="p-6 border-bottom border-transparent fw-bold border-bottom title-custom"
                className="p-3 border-bottom"
                cell={(props) => HsCodeUserDetails(props.dataItem)} // Custom cell rendering
              />
            </Grid>
          </>
        )}
      </div>
      {/* Modal for confirmations */}
      {openModal && openModal.message && (
        <Model
          cancelButton={() => {
            setOpenModal(null);
          }}
          message={<p className="fs-4">{openModal.message}</p>}
          makeAPICall={openModal.callBack}
        />
      )}
      {/* Alert modal for notifications */}
      {openAlertModal && (
        <AlertModel
          cancelButton={() => {
            setOpenAlertModal(null);
          }}
          message={openAlertModal}
          heading="Customer Message"
        />
      )}
    </>
  );
};

export { HSCodeClassificationTraining };
