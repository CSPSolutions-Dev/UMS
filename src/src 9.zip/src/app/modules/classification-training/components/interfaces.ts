export interface FilterType {
  classifiedBy?: string | undefined;
  endDate: string;
  hscodeFilter: string | undefined;
  sectionId: string | undefined;
  startDate: string;
  workflowStatus: string | undefined;
}

export interface updateFilterType {
  hscodePredictionClassificationTypeId: number | undefined;
  hscodeSearchId: number | undefined;
  providedNewHscode: string | undefined;
  selectedHscodeSearchResultId: number | undefined;
  classificationWorkflowTypeId: number | undefined;
}

export interface ModalProps {
  cancelButton: () => void;
  message: any;
  makeAPICall: () => void;
}

export interface AlertModalProps {
  cancelButton: () => void;
  message: string;
  heading: string;
}
