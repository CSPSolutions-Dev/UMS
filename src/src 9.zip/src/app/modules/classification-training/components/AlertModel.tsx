import React from "react";
import { AlertModalProps } from "./interfaces";

// Define the AlertModel component with props
const AlertModel: React.FC<AlertModalProps> = ({
  cancelButton,
  message,
  heading,
}) => {
  return (
    <>
      <div
        className="modal show" // Bootstrap class to display the modal
        style={{
          display: "block",
          backgroundColor: "rgba(0, 0, 0, 0.5)",
        }}
      >
        <div className="modal-dialog modal-dialog-centered  modal-md">
          <div className="modal-content">
            <div className="modal-header p-5">
              <h5 className="modal-title">{heading}</h5>
            </div>
            <div className="modal-body">
              <p className="fs-4">{message}</p>
            </div>

            <div className="modal-footer p-5">
              <button
                type="button"
                className="btn btn-light"
                onClick={cancelButton}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export { AlertModel };
