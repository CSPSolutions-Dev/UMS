import React, { useState } from "react";
import { Content } from "../../../_metronic/layout/components/content";
import { HSCodeClassificationTraining } from "./components/HSCodeClassificationTraining";
import { ClassificationHeader } from "./components/ClassificationHeader";
import PagerComponent from "../../components/pagination/pagination";
import { FilterType } from "./components/interfaces";

// Main component for the Classification Training Page
const ClassificationTrainingPage: React.FC = () => {
  const [filter, setFilter] = useState<FilterType | null>(null);
  const [currentPage, setCurrentPage] = React.useState<number>(1);
  const [totalElement, setTotalElement] = React.useState<number>(0);
  // Items to display per page, set to 2 for this example
  const itemsPerPage = 2;

  // Function to reset pagination, resetting current page and total elements
  const resetPagination = () => {
    setCurrentPage(1);
    setTotalElement(0);
  };
  // State to keep track of a general count value (used for external data counting)

  const [count, setCount] = React.useState<number>(0);

  return (
    <>
      <Content>
        {/* Header section of the page, passing filter, resetPagination, and count to it */}
        <ClassificationHeader
          filter={filter}
          setFilter={setFilter}
          resetPagination={resetPagination}
          count={count}
        />

        {/* Main content section that handles classification training, passing necessary props */}
        <HSCodeClassificationTraining
          filter={filter}
          itemsPerPage={itemsPerPage}
          setTotalElement={setTotalElement}
          currentPage={currentPage}
          setCount={setCount}
        />

        {/* Pagination component to handle page changes */}
        <PagerComponent
          totalPage={totalElement}
          currentPage={currentPage}
          onPageChange={setCurrentPage}
        />
      </Content>
    </>
  );
};

export default ClassificationTrainingPage;
