import { GlobalSettingsControllerApi } from "../../../../api";
import { CustomGlobalSettings } from "../interfaces";
import { AxiosResponse, AxiosError } from "axios";
import { showToast } from "../../../components/toast/toastUtil";

// Create an instance of the API controller for global settings
const API = new GlobalSettingsControllerApi();

/**
 * Inserts a new global settings item.
 * @param item - The global settings item to insert.
 * @returns A promise that resolves to the updated list of global settings.
 */
export const insertItem = async (item: CustomGlobalSettings) => {
  try {
    // Remove globalSettingsId from the item before sending it to the API
    delete item.globalSettingsId;

    // Make API request to add the global settings item
    const response: AxiosResponse<{ responseDescription?: string }> =
      await API.addGlobalSettingsValue(item);
    const { responseDescription } = response.data;

    // Show a success toast notification
    showToast("success", responseDescription || "Success");

    // Fetch and return the updated list of global settings
    return await getItems();
  } catch (error: unknown) {
    // Handle errors and show error toast notification
    if (error instanceof AxiosError && error.response) {
      showToast(
        "error",
        error.response.data?.responseDescription || "Something went wrong!"
      );
    } else {
      showToast("error", "Something went wrong!");
    }
    return await getItems();
  }
};

/**
 * Retrieves the list of global settings items.
 * @returns A promise that resolves to the list of global settings.
 */

export const getItems = async () => {
  try {
    const response: AxiosResponse<{ responseObject?: CustomGlobalSettings[] }> =
      await API.getAllGlobalSettingssList();
    // Return the response object or an empty array if not present
    return response.data.responseObject?.[0];
  } catch (e) {
    // Return an empty array in case of error
    return [];
  }
};

/**
 * Updates an existing global settings item.
 * @param item - The global settings item to update.
 * @returns A promise that resolves to the updated list of global settings.
 */

export const updateItem = async (item: CustomGlobalSettings) => {
  try {
    if (item.globalSettingsId) {
      // Remove date fields from the item before sending it to the API
      delete item.createdDate;
      delete item.modifiedDate;

      // Make API request to update the global settings item
      const response: AxiosResponse<{ responseDescription?: string }> =
        await API.updateGlobalSettingsValue(item.globalSettingsId, item);

      const { responseDescription } = response.data;

      // Show a success toast notification
      showToast("success", responseDescription || "Success");
    }
    return await getItems();
  } catch (error: unknown) {
    // Handle errors and show error toast notification
    if (error instanceof AxiosError && error.response) {
      showToast(
        "error",
        error.response.data?.responseDescription || "Something went wrong!"
      );
    } else {
      showToast("error", "Something went wrong!");
    }
    // Fetch and return the updated list of global settings in case of error
    return await getItems();
  }
};

/**
 * Deletes a global settings item.
 * @param item - The global settings item to delete.
 * @returns A promise that resolves to the updated list of global settings.
 */

export const deleteItem = async (item: CustomGlobalSettings) => {
  try {
    if (item.globalSettingsId) {
      // Make API request to delete the global settings item
      const response: AxiosResponse<{ responseDescription?: string }> =
        await API.deleteGlobalSettingsValue(item.globalSettingsId);
      const { responseDescription } = response.data;
      // Show a success toast notification
      showToast("success", responseDescription || "Success");
    }
    // Fetch and return the updated list of global settings
    return await getItems();
  } catch (error: unknown) {
    // Handle errors and show error toast notification
    if (error instanceof AxiosError && error.response) {
      showToast(
        "error",
        error.response.data?.responseDescription || "Something went wrong!"
      );
    } else {
      showToast("error", "Something went wrong!");
    }
    // Fetch and return the updated list of global settings in case of error
    return await getItems();
  }
};
