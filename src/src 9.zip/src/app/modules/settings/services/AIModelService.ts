import { AIModel, ModelControllerApi } from "../../../../api";
import { AxiosResponse, AxiosError } from "axios";
import { showToast } from "../../../components/toast/toastUtil";

// Create an instance of the API controller for AI models
const API = new ModelControllerApi();

/**
 * Inserts a new AI model.
 * @param item - The AI model to insert.
 * @returns A promise that resolves to the updated list of AI models.
 */

export const insertItem = async (item: AIModel) => {
  try {
    // Make API request to add the AI model
    const response: AxiosResponse<{ responseDescription?: string }> =
      await API.addAIModel(item);
    const { responseDescription } = response.data;

    // Show a success toast notification
    showToast("success", responseDescription || "Success");
    return await getItems();
  } catch (error: unknown) {
    // Handle errors and show error toast notification
    if (error instanceof AxiosError && error.response) {
      showToast(
        "error",
        error.response.data?.responseDescription || "Something went wrong!"
      );
    } else {
      showToast("error", "Something went wrong!");
    }
    // Fetch and return the updated list of AI models in case of error
    return await getItems();
  }
};

/**
 * Retrieves the list of AI models.
 * @returns A promise that resolves to the list of AI models or an empty array if an error occurs.
 */

export const getItems = async () => {
  try {
    // Make API request to get all AI models
    const response: AxiosResponse<{ responseObject?: AIModel[] }> =
      await API.getAllModelsList();
    // Return the response object or an empty array if not present
    return response.data.responseObject?.[0];
  } catch (e) {
    // Return an empty array in case of error
    return [];
  }
};

/**
 * Updates an existing AI model.
 * @param item - The AI model to update.
 * @returns A promise that resolves to the updated list of AI models.
 */

export const updateItem = async (item: AIModel) => {
  try {
    // Make API request to update the AI model
    const response: AxiosResponse<{ responseDescription?: string }> =
      await API.updateAIModel(item);
    const { responseDescription } = response.data;

    // Show a success toast notification
    showToast("success", responseDescription || "Success");

    // Fetch and return the updated list of AI models
    return await getItems();
  } catch (error: unknown) {
    // Handle errors and show error toast notification
    if (error instanceof AxiosError && error.response) {
      showToast(
        "error",
        error.response.data?.responseDescription || "Something went wrong!"
      );
    } else {
      showToast("error", "Something went wrong!");
    }
    // Fetch and return the updated list of AI models in case of error
    return await getItems();
  }
};

/**
 * Deletes an AI model.
 * @param item - The AI model to delete.
 * @returns A promise that resolves to the updated list of AI models.
 */

export const deleteItem = async (item: AIModel) => {
  try {
    if (item.aiModeId) {
      // Make API request to delete the AI model by ID
      const response: AxiosResponse<{ responseDescription?: string }> =
        await API.deleteAIModelById(item.aiModeId);
      const { responseDescription } = response.data;

      // Show a success toast notification
      showToast("success", responseDescription || "Success");
    }

    // Fetch and return the updated list of AI models
    return await getItems();
  } catch (error: unknown) {
    // Handle errors and show error toast notification
    if (error instanceof AxiosError && error.response) {
      showToast(
        "error",
        error.response.data?.responseDescription || "Something went wrong!"
      );
    } else {
      showToast("error", "Something went wrong!");
    }

    // Fetch and return the updated list of AI models in case of error
    return await getItems();
  }
};
