import React from "react";
import { Link, useLocation } from "react-router-dom";

// SettingsHeader component renders the navigation header for the settings section.
const SettingsHeader: React.FC = () => {
  // useLocation hook gives access to the current location object, which includes the pathname.
  const location = useLocation();
  return (
    <>
      <div className="card mb-5 mb-xl-10">
        <div className="card-body pt-0 pb-0">
          <div className="d-flex overflow-auto h-55px">
            {/* Navigation tabs for different settings sections */}
            <ul className="nav nav-stretch nav-line-tabs nav-line-tabs-2x border-transparent fs-5 fw-bolder flex-nowrap">
              {/* Tab for AI Models settings */}
              <li className="nav-item">
                <Link
                  className={
                    // Add 'active' class if the current pathname matches the AI Models path
                    `nav-link text-active-primary me-6 ` +
                    (location.pathname === "/settings/ai-models" && "active")
                  }
                  to="/settings/ai-models"
                >
                  AI Models
                </Link>
              </li>
              <li className="nav-item">
                <Link
                  className={
                    // Add 'active' class if the current pathname matches the Global Settings path
                    `nav-link text-active-primary me-6 ` +
                    (location.pathname === "/settings/global-settings" &&
                      "active")
                  }
                  to="/settings/global-settings"
                >
                  Global Settings
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </>
  );
};

export { SettingsHeader };
