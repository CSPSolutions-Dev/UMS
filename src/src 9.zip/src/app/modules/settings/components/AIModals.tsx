import React, { useEffect, useState } from "react";
import { Grid, GridColumn, GridToolbar } from "@progress/kendo-react-grid";
import {
  deleteItem,
  getItems,
  insertItem,
  updateItem,
} from "../services/AIModelService";
import { Dialog, DialogActionsBar } from "@progress/kendo-react-dialogs";
import { Button } from "@progress/kendo-react-buttons";
import { AIModel } from "../../../../api";
import { AIModelForm } from "./AIModelForm";

// Functional component for AI Models management
const AIModels: React.FC = () => {
  const [loader, setLoader] = useState<boolean>(true);
  const [data, setData] = useState<Array<AIModel>>([]);
  const [openForm, setOpenForm] = React.useState<boolean>(false);
  const [openConfirm, setOpenConfirm] = React.useState<boolean>(false);
  const [editItem, setEditItem] = React.useState<AIModel>({});
  const [deleteItemData, setDeleteItemData] = React.useState<AIModel>({});

  // CSS style for the grid container
  const gridClass: React.CSSProperties = {
    width: "100%",
    margin: "0 auto",
    overflowX: "auto",
    minHeight: 100,
  };

  // useEffect hook to load the AI Models data on component mount
  useEffect(() => {
    getItems().then((res) => {
      if (res) {
        setData(res as Array<AIModel>);
      }

      setLoader(false);
    });
  }, []);

  // Function to handle delete action
  const remove = async () => {
    setLoader(true);
    deleteItem(deleteItemData).then((res) => {
      if (res) {
        setData(res as Array<AIModel>);
      }

      setOpenConfirm(false);
      setLoader(false);
      setDeleteItemData({});
    });
  };

  // Function to handle adding a new AI Model
  const add = (dataItem: AIModel) => {
    setLoader(true);
    insertItem(dataItem).then((res) => {
      if (res) {
        setData(res as Array<AIModel>);
      }

      setOpenForm(false);
      setLoader(false);
    });
  };

  // Function to handle updating an existing AI Model
  const update = (dataItem: AIModel) => {
    setLoader(true);
    updateItem(dataItem).then((res) => {
      if (res) {
        setData(res as Array<AIModel>);
      }

      setOpenForm(false);
      setLoader(false);
    });
  };

  // Function to toggle the delete confirmation dialog
  const toggleDialog = () => {
    setOpenConfirm(false);
    setDeleteItemData({});
  };

  return (
    <>
      <div className="card" style={gridClass}>
        {loader ? ( // Show loader if data is still being fetched
          <div className="text-center mt-10">
            <div
              className="spinner-border"
              style={{ width: "3rem", height: "3rem" }}
              role="status"
            >
              <span className="sr-only">Loading...</span>
            </div>
          </div>
        ) : (
          // Kendo Grid to display AI Model data
          <Grid data={data} style={{ minWidth: "600px", width: "100%" }}>
            {/* Toolbar with an "Add new" button */}
            <GridToolbar className="mt-1 border-bottom">
              <button
                title="Add new"
                className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-primary"
                onClick={() => {
                  setOpenForm(true);
                  setEditItem({});
                }}
              >
                Add new
              </button>
            </GridToolbar>
            <GridColumn
              className="border-bottom p-8"
              headerClassName="border-bottom p-8"
              field="modelName"
              title="AI Model Name"
            />
            <GridColumn
              className="border-bottom p-8"
              headerClassName="border-bottom p-8"
              field="description"
              title="Description"
            />
            <GridColumn
              className="border-bottom p-8"
              headerClassName="border-bottom p-8"
              field="maximumNumberOfResults"
              title="Number Results"
              editor="numeric"
            />
            <GridColumn
              className="border-bottom p-8"
              headerClassName="border-bottom p-8"
              field="isActive"
              title="Is Enable"
            />
            <GridColumn
              className="border-bottom p-8"
              field=""
              title=""
              headerClassName="border-bottom p-8"
              cell={(props) => (
                <td>
                  <div className="d-flex gap-3 justify-content-center">
                    {/* Edit button */}
                    <button
                      className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-primary"
                      onClick={() => {
                        setEditItem(props.dataItem);
                        setOpenForm(true);
                      }}
                    >
                      Edit
                    </button>
                    {/* Delete button */}
                    <button
                      className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-primary"
                      onClick={() => {
                        setOpenConfirm(true);
                        setDeleteItemData(props.dataItem);
                      }}
                    >
                      Delete
                    </button>
                  </div>
                </td>
              )}
            />
          </Grid>
        )}
      </div>

      {/* Dialog for the AIModelForm for adding/updating AI Models */}
      {openForm && !loader && (
        <AIModelForm
          dataItem={editItem} // Pass the current item (new or edit) to the form
          cancelButton={() => {
            setOpenForm(false);
            setEditItem({});
          }}
          saveButton={editItem.aiModeId ? update : add}
        />
      )}

      {/* Confirmation dialog for delete */}
      {openConfirm && !loader && (
        <Dialog title={"Delete Data"} onClose={toggleDialog} width={350}>
          <div>Are you sure you want to delete item ?</div>
          <DialogActionsBar>
            <Button onClick={remove}>Delete</Button>
            <Button onClick={toggleDialog}>Cancel</Button>
          </DialogActionsBar>
        </Dialog>
      )}
    </>
  );
};

export { AIModels };
