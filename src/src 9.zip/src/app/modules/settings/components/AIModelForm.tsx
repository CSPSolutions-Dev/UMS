import { useFormik, FormikProps } from "formik";
import * as Yup from "yup";
import { DataItem, AIModelFormProps } from "../interfaces";

// Validation schema for the form fields
const validationSchema = Yup.object().shape({
  dataRobotKey: Yup.string()
    .required("Data Robot Key is required")
    .max(500, "tag cannot exceed 500 characters"),
  description: Yup.string()
    .required("Description is required")
    .max(200, "Description cannot exceed 200 characters"),
  maximumNumberOfResults: Yup.number()
    .min(0, "Maximum Number Of Results must be at least 0")
    .min(1, "Maximum Number Of Results must be at least 1")
    .max(10, "Maximum Number Of Results cannot exceed 10")
    .required("Maximum Number Of Results is required"),
  modelApiUrl: Yup.string()
    .required("Model ApiUrl is required")
    .max(500, "tag cannot exceed 500 characters"),
  modelAuthorizationToken: Yup.string()
    .required("Model Authorization Token is required")
    .max(500, "tag cannot exceed 500 characters"),
  modelName: Yup.string()
    .required("Model Name is required")
    .max(50, "Model Name cannot exceed 50 characters"),
  tag: Yup.string()
    .required("Tag is required")
    .max(50, "tag cannot exceed 50 characters"),
});

const AIModelForm = ({
  dataItem,
  cancelButton,
  saveButton,
}: AIModelFormProps) => {
  // Initialize Formik with form configuration
  const formik: FormikProps<DataItem> = useFormik<DataItem>({
    initialValues: {
      aiModeId: dataItem.aiModeId || undefined,
      dataRobotKey: dataItem.dataRobotKey || "",
      description: dataItem.description || "",
      maximumNumberOfResults: dataItem.maximumNumberOfResults || undefined,
      modelApiUrl: dataItem.modelApiUrl || "",
      modelAuthorizationToken: dataItem.modelAuthorizationToken || "",
      modelName: dataItem.modelName || "",
      tag: dataItem.tag || "",
      isActive: dataItem.isActive != undefined ? dataItem.isActive : true,
    },
    validationSchema: validationSchema,
    validateOnBlur: true,
    validateOnChange: true,
    onSubmit: (values) => {
      saveButton(values);
    },
  });

  return (
    <>
      <div
        className="modal show"
        style={{
          display: "block",
          backgroundColor: "rgba(0, 0, 0, 0.5)",
        }}
      >
        <div className="modal-dialog modal-dialog-centered  modal-lg">
          <div className="modal-content">
            <div className="modal-header p-5">
              <h5 className="modal-title">AI Model</h5>
            </div>
            <form onSubmit={formik.handleSubmit} noValidate className="form">
              <div className="modal-body p-5 pb-0">
                <div className="row">
                  <div className="col-md-6">
                    <div className="mb-5">
                      <label
                        htmlFor="modelName"
                        className="required form-label"
                      >
                        Model Name
                      </label>
                      <input
                        type="string"
                        className="form-control form-control-solid"
                        placeholder="Model Name"
                        value={formik.values.modelName}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        id="modelName"
                        name="modelName"
                      />
                      {/* Display validation error for modelName */}
                      {formik.touched.modelName && formik.errors.modelName && (
                        <div className="fv-plugins-message-container">
                          <div className="fv-help-block">
                            {formik.errors.modelName}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="mb-5">
                      <label
                        htmlFor="maximumNumberOfResults"
                        className="required form-label"
                      >
                        Maximum Number Of Results
                      </label>
                      <input
                        type="number"
                        min={0}
                        className="form-control form-control-solid"
                        placeholder="Maximum Number Of Results"
                        value={formik.values.maximumNumberOfResults}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        id="maximumNumberOfResults"
                        name="maximumNumberOfResults"
                      />
                      {/* Display validation error for maximumNumberOfResults */}
                      {formik.touched.maximumNumberOfResults &&
                        formik.errors.maximumNumberOfResults && (
                          <div className="fv-plugins-message-container">
                            <div className="fv-help-block">
                              {formik.errors.maximumNumberOfResults}
                            </div>
                          </div>
                        )}
                    </div>
                  </div>

                  <div className="col-md-6">
                    <div className="mb-5">
                      <label
                        htmlFor="description"
                        className="required form-label"
                      >
                        Description
                      </label>
                      <textarea
                        rows={2}
                        className="form-control form-control-solid"
                        placeholder="Description"
                        value={formik.values.description}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        id="description"
                        name="description"
                      />
                      {/* Display validation error for description */}

                      {formik.touched.description &&
                        formik.errors.description && (
                          <div className="fv-plugins-message-container">
                            <div className="fv-help-block">
                              {formik.errors.description}
                            </div>
                          </div>
                        )}
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="mb-5">
                      <label htmlFor="tag" className="required form-label">
                        Tag
                      </label>
                      <input
                        type="string"
                        className="form-control form-control-solid"
                        placeholder="Tag"
                        value={formik.values.tag}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        id="tag"
                        name="tag"
                      />
                      {/* Display validation error for tag */}

                      {formik.touched.tag && formik.errors.tag && (
                        <div className="fv-plugins-message-container">
                          <div className="fv-help-block">
                            {formik.errors.tag}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                  <h5 className="modal-title mb-5 text-decoration-underline">
                    Data Robot
                  </h5>

                  <div className="col-md-12">
                    <div className="mb-5">
                      <label
                        htmlFor="modelApiUrl"
                        className="required form-label"
                      >
                        API Url
                      </label>
                      <input
                        type="string"
                        className="form-control form-control-solid"
                        placeholder="API Url"
                        value={formik.values.modelApiUrl}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        id="modelApiUrl"
                        name="modelApiUrl"
                      />
                      {/* Display validation error for modelApiUrl */}

                      {formik.touched.modelApiUrl &&
                        formik.errors.modelApiUrl && (
                          <div className="fv-plugins-message-container">
                            <div className="fv-help-block">
                              {formik.errors.modelApiUrl}
                            </div>
                          </div>
                        )}
                    </div>
                  </div>
                  <div className="col-md-12">
                    <div className="mb-5">
                      <label
                        htmlFor="modelAuthorizationToken"
                        className="required form-label"
                      >
                        Authorization Token
                      </label>
                      <input
                        type="string"
                        className="form-control form-control-solid"
                        placeholder="Authorization Token"
                        value={formik.values.modelAuthorizationToken}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        id="modelAuthorizationToken"
                        name="modelAuthorizationToken"
                      />
                      {/* Display validation error for modelAuthorizationToken */}

                      {formik.touched.modelAuthorizationToken &&
                        formik.errors.modelAuthorizationToken && (
                          <div className="fv-plugins-message-container">
                            <div className="fv-help-block">
                              {formik.errors.modelAuthorizationToken}
                            </div>
                          </div>
                        )}
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="mb-5">
                      <label
                        htmlFor="dataRobotKey"
                        className="required form-label"
                      >
                        Data Robot Key
                      </label>
                      <input
                        id="dataRobotKey"
                        name="dataRobotKey"
                        type="text"
                        className="form-control form-control-solid"
                        placeholder="Data Robot Key"
                        value={formik.values.dataRobotKey}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                      />
                      {/* Display validation error for dataRobotKey */}

                      {formik.touched.dataRobotKey &&
                        formik.errors.dataRobotKey && (
                          <div className="fv-plugins-message-container">
                            <div className="fv-help-block">
                              {formik.errors.dataRobotKey}
                            </div>
                          </div>
                        )}
                    </div>
                  </div>
                  <div className="col-md-6"></div>
                  <div className="mb-5">
                    <div className="form-check form-switch form-check-custom form-check-solid">
                      <input
                        className="form-check-input h-30px w-60px"
                        type="checkbox"
                        checked={formik.values.isActive}
                        id="isActive"
                        onChange={formik.handleChange}
                      />
                      <label
                        className="form-check-label"
                        htmlFor="flexSwitchDefault"
                      >
                        Is Active
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            </form>
            <div className="modal-footer p-5">
              <button
                type="button"
                className="btn btn-light"
                onClick={cancelButton}
              >
                Close
              </button>
              <button
                type="submit"
                className="btn btn-primary"
                onClick={() => {
                  formik.handleSubmit();
                }}
              >
                Save
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export { AIModelForm };
