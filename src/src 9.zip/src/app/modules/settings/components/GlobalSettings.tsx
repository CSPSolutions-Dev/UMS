import React, { useEffect, useState } from "react";
import {
  Grid,
  GridColumn,
  GridItemChangeEvent,
  GridToolbar,
} from "@progress/kendo-react-grid";

import { CommandCell } from "../../../components/CommandCell";
import { CustomGlobalSettings } from "../interfaces";
import {
  deleteItem,
  getItems,
  insertItem,
  updateItem,
} from "../services/GlobalService";
import { generateSecureRandomNumber } from "../../../components/CommonFunction";

// Define the field used for editing in the grid
const editField = "inEdit";

const GlobalSettingsComponent: React.FC = () => {
  const [loader, setLoader] = useState<boolean>(true);
  const [data, setData] = React.useState<Array<CustomGlobalSettings>>([]);
  const [validationErrors, setValidationErrors] = useState<{
    [key: string]: string;
  }>({});

  // Style for the grid container
  const gridClass: React.CSSProperties = {
    width: "100%",
    margin: "0 auto",
    overflowX: "auto",
    minHeight: 100,
  };

  // Fetch data from the API when the component mounts
  useEffect(() => {
    getItems().then((res) => {
      if (res) {
        setData(res as Array<CustomGlobalSettings>);
      }

      setLoader(false);
    });
  }, []);

  // Handler to remove an item from the data
  const remove = (dataItem: CustomGlobalSettings) => {
    setLoader(true);
    deleteItem(dataItem).then((res) => {
      if (res) {
        setData(res as Array<CustomGlobalSettings>);
      }
      setLoader(false);
    });
  };

  // Handler to add a new item to the data
  const add = (dataItem: CustomGlobalSettings) => {
    setLoader(true);
    dataItem.inEdit = true;
    insertItem(dataItem).then((res) => {
      if (res) {
        setData(res as Array<CustomGlobalSettings>);
      }
      setLoader(false);
    });
  };

  // Handler to update an existing item in the data
  const update = (dataItem: CustomGlobalSettings) => {
    dataItem.inEdit = false;
    setLoader(true);
    updateItem(dataItem).then((res) => {
      if (res) {
        setData(res as Array<CustomGlobalSettings>);
      }
      setLoader(false);
    });
  };

  // Handler to discard a new item
  const discard = () => {
    const newData = [...data];
    newData.splice(0, 1);
    setData(newData);
  };

  // Handler to cancel editing and revert to original data
  const cancel = async (dataItem: CustomGlobalSettings) => {
    const originalData = await getItems();
    let originalItem: CustomGlobalSettings | undefined;

    if (Array.isArray(originalData)) {
      originalItem = originalData?.find(
        (p: CustomGlobalSettings) =>
          p.globalSettingsId === dataItem.globalSettingsId
      );
    }

    if (originalItem) {
      const newData = data.map((item: CustomGlobalSettings) =>
        item.globalSettingsId === originalItem.globalSettingsId
          ? originalItem
          : item
      );
      setData(newData);
    } else {
      console.error("Original item not found");
    }
  };

  // Handler to enter edit mode for a specific item
  const enterEdit = (dataItem: CustomGlobalSettings) => {
    const editData = data.map((item) =>
      item.globalSettingsId === dataItem.globalSettingsId
        ? {
            ...item,
            inEdit: true,
          }
        : { ...item }
    );
    setData([...editData]);
  };

  const itemChange = (event: GridItemChangeEvent) => {
    // Create a copy of the current validation errors to update based on new input
    const newValidationErrors = { ...validationErrors };

    // Update the data state with the changed item
    const newData = data.map((item) => {
      // Check if the changed field is 'settingsKeyName'
      if (event.field === "settingsKeyName") {
        if (event.value.length > 100) {
          newValidationErrors[event.dataItem.globalSettingsId] =
            "Settings Name cannot exceed 100 characters.";
          event.value = event.value.slice(0, 101);
        } else {
          delete newValidationErrors[event.dataItem.globalSettingsId];
        }
      }
      // Check if the changed field is 'settingsKeyValue'
      else if (event.field === "settingsKeyValue") {
        if (event.value.length > 1000) {
          newValidationErrors[event.dataItem.globalSettingsId] =
            "Settings Value cannot exceed 1000 characters.";
          event.value = event.value.slice(0, 1001);
        } else {
          delete newValidationErrors[event.dataItem.globalSettingsId];
        }
      }
      // Update the item with the new value if it matches the changed item
      return item.globalSettingsId === event.dataItem.globalSettingsId
        ? {
            ...item,
            [event.field || ""]: event.value,
          }
        : item;
    });

    // Update the state with the new data and validation errors
    setData(newData);
    setValidationErrors(newValidationErrors);
  };
  const addNew = () => {
    // Create a new item with a unique ID and set it as editable
    const newDataItem = {
      inEdit: true,
      Discontinued: false,
      globalSettingsId: `new_${generateSecureRandomNumber()}`,
    };
    // Add the new item to the beginning of the data array
    setData([newDataItem, ...data]);
  };

  // Define an object to pass as props for command cells, including actions like edit, remove, add, etc.
  const commandCellProps = {
    edit: enterEdit,
    remove: remove,
    add: add,
    discard: discard,
    update: update,
    cancel: cancel,
    editField: editField,
  };
  return (
    <>
      <div className="card" style={gridClass}>
        {loader ? ( // Show a loading spinner if the loader state is true
          <div className="text-center mt-10">
            <div
              className="spinner-border"
              style={{ width: "3rem", height: "3rem" }}
              role="status"
            >
              <span className="sr-only">Loading...</span>
            </div>
          </div>
        ) : (
          <Grid
            data={data}
            onItemChange={itemChange}
            editField={editField}
            style={{ minWidth: "600px", width: "100%" }}
          >
            <GridToolbar className="mt-1 border-bottom">
              <button
                title="Add new"
                className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-primary"
                onClick={addNew} // Trigger the function to add a new row/item
              >
                Add new
              </button>
            </GridToolbar>
            <GridColumn
              className="border-bottom p-8"
              headerClassName="border-bottom p-8"
              field="settingsKeyName"
              title="Settings Name"
            />
            <GridColumn
              className="border-bottom p-8"
              headerClassName="border-bottom p-8"
              field="settingsKeyValue"
              title="Settings Value"
            />
            {/* Command cell column to provide edit, delete, etc., options for each row */}
            <GridColumn
              className="border-bottom p-8"
              field={""}
              title={""}
              headerClassName="border-bottom p-8"
              cell={(props) => <CommandCell {...props} {...commandCellProps} />}
              // Renders a custom CommandCell for each row with actions like edit, remove, etc., passed via commandCellProps
            />
          </Grid>
        )}
      </div>
    </>
  );
};

export { GlobalSettingsComponent };
