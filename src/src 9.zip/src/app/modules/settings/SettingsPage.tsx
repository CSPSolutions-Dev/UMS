import { Navigate, Outlet, Route, Routes } from "react-router-dom";
import { SettingsHeader } from "./SettingsHeader";
import { AIModels } from "./components/AIModals";
import { GlobalSettingsComponent } from "./components/GlobalSettings";
import { Content } from "../../../_metronic/layout/components/content";

// SettingsPage component manages the routing for the settings section of the application.
const SettingsPage = () => {
  return (
    <Routes>
      {/* This Route wraps the SettingsHeader and Outlet, providing a layout with a header and a dynamic content area. */}
      <Route
        element={
          <>
            {/* Content component provides a consistent layout wrapper for the settings page. */}
            <Content>
              {/* SettingsHeader component displays the header for the settings section. */}
              <SettingsHeader />
              {/* Outlet renders nested routes. */}
              <Outlet />
            </Content>
          </>
        }
      >
        {/* Route for AI Models settings */}
        <Route
          path="/ai-models"
          element={
            <>
              {/* AIModels component handles the AI Models settings. */}
              <AIModels />
            </>
          }
        />
        <Route
          path="/global-settings"
          element={
            <>
              {/* GlobalSettingsComponent handles the global settings configuration. */}
              <GlobalSettingsComponent />
            </>
          }
        />
        {/* Default route redirects to /ai-models if no other route matches */}
        <Route index element={<Navigate to="/settings/ai-models" />} />
      </Route>
    </Routes>
  );
};

export default SettingsPage;
