import { GlobalSettings } from "../../../api";

export interface CustomGlobalSettings extends GlobalSettings {
  inEdit?: boolean | string;
  locked?: boolean;
  globalSettingsId?: any;
}

export interface DataItem {
  aiModeId?: number;
  dataRobotKey?: string;
  description?: string;
  maximumNumberOfResults?: number;
  modelApiUrl?: string;
  modelAuthorizationToken?: string;
  modelName?: string;
  tag?: string;
  isActive?: boolean;
}

export interface AIModelFormProps {
  dataItem: DataItem;
  cancelButton: () => void;
  saveButton: (values: DataItem) => void;
}
