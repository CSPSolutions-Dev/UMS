import React, { useState } from "react";
import { Content } from "../../../_metronic/layout/components/content";
import { WorkflowClassificationType } from "./components/workflowType";
import PagerComponent from "../../components/pagination/pagination";

// Functional component for the workflow page
const workflowPage: React.FC = () => {
  // State to manage items per page in the pagination
  const [itemsPerPage, setItemsPerPage] = useState(10);

  // State to manage the current page
  const [currentPage, setCurrentPage] = React.useState<number>(1);

  // State to store the total number of elements (for pagination)
  const [totalElement, setTotalElement] = React.useState<number>(0);
  return (
    <>
      {/* Wrapper for the content area */}
      <Content>
        {/* Component to display workflow classifications with pagination info */}
        <WorkflowClassificationType
          itemsPerPage={itemsPerPage}
          setTotalElement={setTotalElement}
          currentPage={currentPage}
        />
        {/* Pager component to handle pagination controls */}
        <PagerComponent
          totalPage={totalElement}
          currentPage={currentPage}
          onPageChange={setCurrentPage}
          enablePerPage={true}
          itemsPerPage={itemsPerPage}
          setItemsPerPage={setItemsPerPage}
        />
      </Content>
    </>
  );
};

export default workflowPage;
