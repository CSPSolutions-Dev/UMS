import React, { useEffect, useState } from "react";
import {
  Grid,
  GridColumn,
  GridExpandChangeEvent,
  GridGroupChangeEvent,
  GridItemChangeEvent,
  GridSortChangeEvent,
  GridToolbar,
} from "@progress/kendo-react-grid";
import { CustomWorkflowsRequest } from "../interfaces";
import {
  deleteItem,
  getAppRole,
  getItems,
  getWorkFlowClassificationType,
  insertItem,
  updateItem,
} from "../service/workflowAPI";
import { WorkFlowCommandCell } from "../../../components/WorkFlowCommandCell";
import { DropDownList } from "@progress/kendo-react-dropdowns";
import {
  process,
  SortDescriptor,
  GroupDescriptor,
  groupBy,
  GroupResult,
} from "@progress/kendo-data-query";
import {
  setExpandedState,
  setGroupIds,
} from "@progress/kendo-react-data-tools";
import { generateSecureRandomNumber } from "../../../components/CommonFunction";

const editField = "inEdit"; // Field to track if a row is in edit mode

// Initial group descriptor to group data by appRole.roleName
const initialGroup: GroupDescriptor[] = [{ field: "appRole.roleName" }];

const WorkflowClassificationType = ({
  itemsPerPage,
  currentPage,
  setTotalElement,
}: any) => {
  // Function to process data with group descriptors
  const processWithGroups = (data: any[], group: GroupDescriptor[]) => {
    const newDataState = groupBy(data, group); // Group the data based on the given group descriptors
    setGroupIds({ data: newDataState, group: group }); // Assign group IDs to manage the expanded/collapsed state
    return newDataState;
  };

  // Define state variables
  const [loader, setLoader] = useState<boolean>(true);
  const [data, setData] = useState<Array<CustomWorkflowsRequest>>([]);
  const [sort, setSort] = useState<SortDescriptor[]>([]);
  const [group, setGroup] = React.useState(initialGroup);
  const [resultState, setResultState] = React.useState<any[] | GroupResult[]>(
    processWithGroups(data, initialGroup)
  );
  const [collapsedState, setCollapsedState] = React.useState<string[]>([]);
  const [workflowTypes, setWorkflowTypes] = useState<any[]>([]);
  const [roles, setRoles] = useState<any[]>([]);

  // Fetch and set data for roles, workflow types, and workflow items
  const getAndSetData = async () => {
    setLoader(true); // Show loader during data fetch
    getAppRole().then((res) => {
      setRoles(
        res.map((item: any) => ({
          key: item.roleId,
          value: item.roleName,
        }))
      );
    });

    getWorkFlowClassificationType().then((res) => {
      // Fetch and set workflow classification types
      setWorkflowTypes(
        res.map((item: any) => ({
          key: item.classificationWorkflowTypeId,
          value: item.status,
        }))
      );
    });

    getItems(itemsPerPage, currentPage).then((res: any) => {
      // Fetch workflow items and update data
      if (res) {
        setData([...res.content]);
        setTotalElement(res.totalPages);
      }
      setLoader(false);
    });
  };

  // Use effect to fetch data whenever currentPage or itemsPerPage changes
  useEffect(() => {
    getAndSetData();
  }, [currentPage, itemsPerPage]);

  // Handler for sorting changes
  const handleSortChange = (e: GridSortChangeEvent) => {
    setSort(e.sort);
    const processedData = process(data, { sort: e.sort });
    setData(processedData.data);
  };

  // Handler for grouping changes
  const onGroupChange = React.useCallback((event: GridGroupChangeEvent) => {
    const newGroups = event.group;
    // Ensure there are no duplicate group fields
    const areNewGroupsUnique = !newGroups.some(
      (item, index) =>
        newGroups.findIndex((group) => group.field === item.field) !== index
    );

    if (areNewGroupsUnique) {
      const newDataState = processWithGroups(data, event.group);

      setGroup(event.group);
      setResultState(newDataState);
    }
  }, []);

  // Handler for expanding/collapsing group rows
  const onExpandChange = React.useCallback(
    (event: GridExpandChangeEvent) => {
      const item = event.dataItem;
      if (item.groupId) {
        // Toggle collapsed state for group rows
        const newCollapsedIds = !event.value
          ? [...collapsedState, item.groupId]
          : collapsedState.filter((groupId) => groupId !== item.groupId);
        setCollapsedState(newCollapsedIds);
      }
    },
    [collapsedState]
  );
  // Function to add a new workflow item
  const addNew = () => {
    const newDataItem: any = {
      inEdit: true,
      canRead: false,
      canClassify: false,
      canReject: false,
      classificationWorkflowTypeId: {
        classificationWorkflowTypeId: workflowTypes[0].key,
        status: workflowTypes[0].value,
      },
      appRole: {
        roleId: roles[0].key,
        roleName: roles[0].value,
      },
      classificationWorkflowSettingId: `new_${generateSecureRandomNumber()}`,
    };
    setData([newDataItem, ...data]); // Add new item to the beginning of the data array
  };

  // Handler for item changes in the grid (e.g., edit, checkbox toggle)
  const itemChange = (event: GridItemChangeEvent) => {
    const newData = data.map((item: any) => {
      return item.classificationWorkflowSettingId ===
        event.dataItem.classificationWorkflowSettingId
        ? {
            ...item,
            [event.field || ""]: event.value, // Update the changed field
          }
        : item;
    });
    setData(newData); // Update data with the modified item
  };

  // Checkbox component for permission fields
  const CheckBoxComponent = (dataItem: any, key: any, onChange: any) => {
    return (
      <>
        {typeof dataItem[key] != "undefined" && (
          <td className="border-top fs-6 py-8 px-8">
            <div className="form-check form-check-sm form-check-custom justify-content-center">
              <input
                disabled={dataItem.inEdit ? false : true}
                className="form-check-input widget-9-check"
                type="checkbox"
                checked={dataItem[key] ? dataItem[key] : false}
                onChange={(e) => {
                  onChange({
                    dataItem: dataItem,
                    field: key,
                    value: e.target.checked, // Update value on checkbox change
                  });
                }}
              />
            </div>
          </td>
        )}
      </>
    );
  };

  // Dropdown component for editing appRole and workflow type
  const DropDownCell = (field: any, options: any[]) => (props: any) => {
    const { dataItem } = props;
    let value = options[0];

    // Conditional logic to check if the field is 'classificationWorkflowTypeId' or 'appRole'
    // and assign appropriate key-value pairs to the value.
    if (field === "classificationWorkflowTypeId" && dataItem[field]) {
      value = {
        key: dataItem[field].classificationWorkflowTypeId,
        value: dataItem[field].status,
      };
    } else if (field === "appRole" && dataItem[field]) {
      value = {
        key: dataItem[field].roleId,
        value: dataItem[field].roleName,
      };
    }

    // Handles the change event in the dropdown for both 'classificationWorkflowTypeId' and 'appRole'
    const handleChange = (e: any) => {
      if (field === "classificationWorkflowTypeId") {
        // Update the field value based on the selected workflow type
        props.onChange({
          dataItem: dataItem,
          field: field,
          value: {
            classificationWorkflowTypeId: e.value.key,
            status: e.value.value,
          },
        });
      } else if (field === "appRole") {
        // Update the field value based on the selected role
        props.onChange({
          dataItem: dataItem,
          field: field,
          value: { roleId: e.value.key, roleName: e.value.value },
        });
      }
    };

    // The return statement renders the dropdown if the item is in edit mode,
    // otherwise displays the field value.
    return (
      <>
        {dataItem[field] && (
          <td className="border-top p-8">
            {dataItem.inEdit ? (
              <DropDownList
                textField="value"
                dataItemKey="key"
                data={options}
                value={value}
                onChange={handleChange}
              />
            ) : (
              // Display the value if the item is not in edit mode
              value.value
            )}
          </td>
        )}
      </>
    );
  };

  // Remove an existing workflow permission
  // This function sends a delete request to the server to remove a selected workflow permission.
  const remove = (dataItem: CustomWorkflowsRequest) => {
    setLoader(true);
    deleteItem(dataItem).then((res: any) => {
      // After deletion, re-fetch data to update the grid and remove the deleted item
      getAndSetData();
      setLoader(false);
    });
  };

  // Add a new workflow permission
  // This function is used to insert a new workflow permission.
  const add = (dataItem: CustomWorkflowsRequest) => {
    setLoader(true);
    dataItem.inEdit = true;
    insertItem(dataItem).then((res: any) => {
      // After insertion, re-fetch the data to show the newly added item
      getAndSetData();
      setLoader(false);
    });
  };

  // Update an existing workflow permission
  // This function sends an update request to modify an existing workflow permission.
  const update = (dataItem: CustomWorkflowsRequest) => {
    dataItem.inEdit = false;
    setLoader(true);
    updateItem(dataItem).then((res: any) => {
      // After updating, re-fetch data to reflect changes in the grid
      getAndSetData();
      setLoader(false);
    });
  };

  // Function to discard the changes and reset the data
  const discard = () => {
    const newData = [...data];
    newData.splice(0, 1);
    setData(newData);
  };

  // Function to cancel editing and revert changes
  const cancel = async (dataItem: CustomWorkflowsRequest) => {
    const originalData: any = await getItems(itemsPerPage, currentPage);

    let originalItem: CustomWorkflowsRequest | undefined;
    // Check if originalData contains an array of items
    if (Array.isArray(originalData?.content)) {
      // Find the original item that matches the given dataItem
      originalItem = originalData?.content?.find(
        (p: CustomWorkflowsRequest) =>
          p.classificationWorkflowSettingId ===
          dataItem.classificationWorkflowSettingId
      );
    }

    // If the original item is found, update the data with the original item
    if (originalItem) {
      const newData = data.map((item) =>
        item.classificationWorkflowSettingId ===
        originalItem.classificationWorkflowSettingId
          ? originalItem
          : item
      );
      // Set the state with the updated data
      setData(newData);
    } else {
      console.error("Original item not found");
    }
  };

  // Function to enable editing mode for a specific item
  const enterEdit = (dataItem: CustomWorkflowsRequest) => {
    // Create a new array with the item marked as 'inEdit'
    const editData = data.map((item) =>
      item.classificationWorkflowSettingId ===
      dataItem.classificationWorkflowSettingId
        ? {
            ...item,
            inEdit: true,
          }
        : { ...item }
    );
    // Update the state with the modified data
    setData([...editData]);
  };

  // Define properties for the command cell in the grid
  const commandCellProps = {
    edit: enterEdit,
    remove: remove,
    add: add,
    discard: discard,
    update: update,
    cancel: cancel,
    editField: editField,
  };

  // CSS style for the grid container
  const gridClass: React.CSSProperties = {
    width: "100%",
    margin: "0 auto",
    overflowX: "auto",
    minHeight: 100,
  };

  return (
    <>
      {/* Container for the title */}
      <div className="col-12 col-md-3">
        <h2>Workflow Settings</h2>
      </div>

      {/* Card container for the grid */}
      <div className="card" style={gridClass}>
        {loader ? (
          // Display a loading spinner while data is loading
          <div className="text-center mt-10">
            <div
              className="spinner-border"
              style={{ width: "3rem", height: "3rem" }}
              role="status"
            >
              <span className="sr-only">Loading...</span>
            </div>
          </div>
        ) : (
          // Render the Kendo Grid with the provided data and settings
          <Grid
            data={setExpandedState({
              data: processWithGroups(data, group),
              collapsedIds: collapsedState,
            })}
            sortable={true}
            sort={sort}
            onSortChange={handleSortChange}
            onItemChange={itemChange}
            group={group}
            onGroupChange={onGroupChange}
            groupable={true}
            onExpandChange={onExpandChange}
            expandField="expanded"
            // editField={editField}
            style={{ minWidth: "800px", width: "100%" }}
          >
            <GridToolbar className="mt-1 border-bottom p-8">
              <button
                title="Add new"
                className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-primary"
                onClick={addNew}
              >
                Add Workflow Permission
              </button>
            </GridToolbar>

            {/* Grid columns definition */}
            <GridColumn
              headerClassName="p-8"
              field="classificationWorkflowTypeId.status"
              title="Workflow Classification Type"
              cell={DropDownCell("classificationWorkflowTypeId", workflowTypes)}
              width={300}
            />
            <GridColumn
              headerClassName="p-8"
              field="appRole.roleName"
              title="Associated Role"
              cell={DropDownCell("appRole", roles)}
              width={200}
            />
            <GridColumn
              headerClassName="p-8 justify-content-center"
              field="canRead"
              title="Can Read"
              cell={({ dataItem, onChange }) =>
                CheckBoxComponent(dataItem, "canRead", onChange)
              }
              sortable={false}
              groupable={false}
            />
            <GridColumn
              headerClassName=" p-8 justify-content-center"
              field="canClassify"
              title="Can Classify"
              cell={({ dataItem, onChange }) =>
                CheckBoxComponent(dataItem, "canClassify", onChange)
              }
              sortable={false}
              groupable={false}
            />

            <GridColumn
              headerClassName="p-8 justify-content-center"
              field="canReject"
              title="Can Reject"
              cell={({ dataItem, onChange }) =>
                CheckBoxComponent(dataItem, "canReject", onChange)
              }
              sortable={false}
              groupable={false}
            />

            <GridColumn
              field={""}
              title="Command"
              headerClassName=" p-8 "
              width={200}
              cell={(props) => (
                <WorkFlowCommandCell {...props} {...commandCellProps} />
              )}
              sortable={false}
              groupable={false}
            />
          </Grid>
        )}
      </div>
    </>
  );
};

export { WorkflowClassificationType };
