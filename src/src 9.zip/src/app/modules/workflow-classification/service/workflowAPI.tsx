import { WorkflowsControllerApi } from "../../../../api";
import { CustomWorkflowsRequest } from "../interfaces";
import { AxiosResponse, AxiosError } from "axios";
import { showToast } from "../../../components/toast/toastUtil";

// Create an instance of WorkflowsControllerApi to interact with API
const API = new WorkflowsControllerApi();

/**
 * Inserts a new workflow item into the system.
 * @param item - The workflow item to insert.
 * @returns An empty array on success or error.
 */
export const insertItem = async (item: any) => {
  try {
    // Remove classificationWorkflowSettingId if it exists in item
    delete item.classificationWorkflowSettingId;
    // Send POST request to create a new workflow
    const response: AxiosResponse<{
      responseCode?: number;
      responseDescription?: string;
    }> = await API.createWorkflows({
      appRoleId: item.appRole?.roleId,
      canClassify: item.canClassify,
      canRead: item.canRead,
      canReject: item.canReject,
      classificationWorkflowTypeId:
        item.classificationWorkflowTypeId.classificationWorkflowTypeId,
    });
    // Extract response data
    const { responseDescription, responseCode } = response.data;

    // Show success or error toast based on response code
    if (responseCode == 500) {
      showToast("error", responseDescription || "error");
    } else {
      showToast("success", responseDescription || "Success");
    }
    return [];
  } catch (error: unknown) {
    if (error instanceof AxiosError && error.response) {
      showToast(
        "error",
        error.response.data?.responseDescription || "Something went wrong!"
      );
    } else {
      showToast("error", "Something went wrong!");
    }
    return [];
  }
};

/**
 * Retrieves a list of workflow items.
 * @param itemPerPage - Number of items per page.
 * @param currentPage - Current page number.
 * @returns The first item from the response object or an empty array.
 */

export const getItems = async (itemPerPage: number, currentPage: number) => {
  try {
    // Send GET request to retrieve workflow items
    const response: AxiosResponse<{
      responseObject?: CustomWorkflowsRequest[];
    }> = await API.getWorkflows(currentPage - 1, itemPerPage);
    // Return the first item from the response
    return response.data.responseObject?.[0];
  } catch (e) {
    return [];
  }
};

/**
 * Updates an existing workflow item.
 * @param item - The workflow item to update.
 * @returns An empty array on success or error.
 */

export const updateItem = async (item: any) => {
  try {
    if (item.classificationWorkflowSettingId) {
      // Send PUT request to update the workflow
      const response: AxiosResponse<{
        responseDescription?: string;
        responseCode?: number;
      }> = await API.updateWorkflows(item.classificationWorkflowSettingId, {
        appRoleId: item.appRole?.roleId,
        canClassify: item.canClassify,
        canRead: item.canRead,
        canReject: item.canReject,
        classificationWorkflowTypeId:
          item.classificationWorkflowTypeId.classificationWorkflowTypeId,
      });
      const { responseDescription, responseCode } = response.data;
      if (responseCode == 404) {
        showToast("error", responseDescription || "error");
      } else {
        showToast("success", responseDescription || "Success");
      }
    }
    return [];
    // Show success or error toast based on response code
  } catch (error: unknown) {
    // Handle errors and show appropriate toast messages
    if (error instanceof AxiosError && error.response) {
      showToast(
        "error",
        error.response.data?.responseDescription || "Something went wrong!"
      );
    } else {
      showToast("error", "Something went wrong!");
    }
    return [];
  }
};

/**
 * Deletes a workflow item from the system.
 * @param item - The workflow item to delete.
 * @returns An empty array on success or error.
 */

export const deleteItem = async (item: any) => {
  try {
    if (item.classificationWorkflowSettingId) {
      // Send DELETE request to remove the workflow
      const response: AxiosResponse<{ responseDescription?: string }> =
        await API.removeWorkflows(item.classificationWorkflowSettingId);
      // Extract response data
      const { responseDescription } = response.data;
      showToast("success", responseDescription || "Success");
    }
    return [];
  } catch (error: unknown) {
    // Handle errors and show appropriate toast messages
    if (error instanceof AxiosError && error.response) {
      showToast(
        "error",
        error.response.data?.responseDescription || "Something went wrong!"
      );
    } else {
      showToast("error", "Something went wrong!");
    }
    return [];
  }
};

/**
 * Retrieves workflow classification types.
 * @returns The first item from the response object or an empty array.
 */

export const getWorkFlowClassificationType = async () => {
  try {
    // Send GET request to retrieve workflow classification types
    const { data }: any = await API.getClassificationWorkFlowTypes();
    return data?.responseObject[0];
  } catch (error: unknown) {
    return [];
  }
};

/**
 * Retrieves application roles.
 * @returns The first item from the response object or an empty array.
 */

export const getAppRole = async () => {
  try {
    // Send GET request to retrieve application roles
    const { data }: any = await API.getAppRoles();
    return data?.responseObject[0];
  } catch (error: unknown) {
    return [];
  }
};
