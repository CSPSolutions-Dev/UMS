import { WorkflowsDTO } from "../../../api";

// Interface extending WorkflowsDTO with additional properties
export interface CustomWorkflowsRequest extends WorkflowsDTO {
  /**
   * Indicates whether the workflow is currently in edit mode.
   * Can be a boolean or a string representing edit status.
   */
  inEdit?: boolean | string;

  /**
   * Indicates whether the workflow is locked.
   * A boolean value representing locked status.
   */
  locked?: boolean;

  /**
   * Identifier for the classification workflow setting.
   * This field is required.
   */
  classificationWorkflowSettingId: string;
}
