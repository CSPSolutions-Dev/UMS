import React, { useEffect, useState } from "react";

// Define interface for the component's props if any (currently no props)
interface ReportsProps {}

const Reports: React.FC<ReportsProps> = () => {
  // State to hold the token for embedding the Cognos dashboard
  const [token, setToken] = useState<string>("");
  // State to hold the URL for embedding the Cognos dashboard
  const [embedUrl, setEmbedUrl] = useState<string>("");

  useEffect(() => {
    // Function to fetch the token and construct the embed URL for the Cognos dashboard
    const fetchToken = async () => {
      try {
        // Construct the dashboard URL with the token
        const dashboardUrl = `https://your-cognos-endpoint/ibmcognos/bi/v1/disp/rds?path=/content/folder[@name="YourFolder"]/dashboard[@name="YourDashboard"]&token=${token}`;
        // Uncomment the line below to set the embed URL once the token is fetched
        // setEmbedUrl(dashboardUrl);
      } catch (error) {
        // Log any errors that occur during the fetch operation
        console.error("Error fetching token:", error);
      }
    };

    fetchToken(); // Call the fetchToken function on component mount
    // }, [token]); // Empty dependency array means this effect runs only once when the component mounts
  }, [token]); // Adding token as a dependency ensures the dashboard URL is updated when the token changes

  return (
    <div style={{ height: "800px", width: "100%" }}>
      {/* Placeholder for the dashboard title */}
      {/* <h1>Reports</h1> */}
      {embedUrl ? (
        // Render the iframe if embedUrl is available
        <iframe
          src={embedUrl}
          style={{ border: "none", width: "100%", height: "100%" }}
          title="Cognos Dashboard"
        ></iframe>
      ) : (
        // Display a loading spinner if embedUrl is not yet available
        <div className="text-center mt-10">
          {/* <div
            className="spinner-border"
            style={{ width: "3rem", height: "3rem" }}
            role="status"
          >
            <span className="sr-only">Loading...</span>
          </div> */}
        </div>
      )}
    </div>
  );
};

export { Reports };
