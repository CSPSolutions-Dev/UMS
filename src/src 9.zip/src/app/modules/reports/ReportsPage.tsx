import React from "react";
import { Content } from "../../../_metronic/layout/components/content";
import { Reports } from "./components/Reports";

// ReportsPage component that renders the Reports page
const ReportsPage: React.FC = () => {
  return (
    <>
      {/* Content component wrapping the Reports component */}
      <Content>
        {/* Column layout for the content */}
        <div className="col-xl-12">
          {/* Rendering the Reports component */}
          <Reports />
        </div>
      </Content>
    </>
  );
};

export default ReportsPage;
