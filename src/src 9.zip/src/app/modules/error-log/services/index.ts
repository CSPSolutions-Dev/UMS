import { ErrorLogsControllerApi } from "../../../../api";

// Initialize an instance of the ErrorLogsControllerApi to make API calls
const API = new ErrorLogsControllerApi();

/**
 * Fetches error logs from the API with pagination.
 *
 * @param itemPerPage - Number of error logs to retrieve per page
 * @param currentPage - The current page number to fetch logs for
 * @returns A promise that resolves to an array of error logs
 */
export const getErrorLogs = async (
  itemPerPage: number,
  currentPage: number
) => {
  try {
    // Call the API to get error logs, adjusting for zero-based page index
    const response: any = await API.getErrorLogs(currentPage - 1, itemPerPage);
    // Return the error logs from the response or an empty array if not found
    return response.data.responseObject?.[0] || [];
  } catch (e) {
    return [];
  }
};

/**
 * Removes all error logs from the API.
 *
 * @returns A promise that resolves to an empty array or an array with response data
 */

export const removeErrorLogs = async () => {
  try {
    // Call the API to remove all error logs
    const response: any = await API.removeAllErrorLogs();
    // Return the response data or an empty array if not found
    return response.data.responseObject?.[0] || [];
  } catch (e) {
    // In case of an error, return an empty array
    return [];
  }
};
