import { useEffect, useState } from "react";
import { Grid, GridColumn, GridToolbar } from "@progress/kendo-react-grid";
import { getErrorLogs, removeErrorLogs } from "../services";
import { Button } from "react-bootstrap";
import { CSVLink } from "react-csv";
import { Dialog, DialogActionsBar } from "@progress/kendo-react-dialogs";

// Define interface for component props
interface ErrorLogProps {
  itemsPerPage: number;
  currentPage: number;
  setTotalElement: (totalPages: number) => void;
}

// ErrorLog component displays a grid of error logs with export and delete functionalities
const ErrorLog = ({
  itemsPerPage,
  currentPage,
  setTotalElement,
}: ErrorLogProps) => {
  // State to manage loading spinner visibility
  const [loader, setLoader] = useState(false);

  // State to store the fetched error logs data
  const [data, setData] = useState([]);
  const [dialogVisible, setDialogVisible] = useState(false);

  // Function to handle the delete button click and show the confirmation dialog
  const handleDelete = () => {
    setDialogVisible(true);
  };

  // Function to fetch error logs and update the data state
  const getAndSetData = async () => {
    setLoader(true);
    await getErrorLogs(itemsPerPage, currentPage).then((res) => {
      setTotalElement(res.totalPages);
      setData(res.content);
    });
    setLoader(false);
  };

  // Fetch data when currentPage or itemsPerPage changes
  useEffect(() => {
    getAndSetData();
  }, [currentPage, itemsPerPage]);

  // Function to confirm and handle error log deletion
  const confirmDelete = async () => {
    setLoader(true);
    await removeErrorLogs().then(() => {
      getAndSetData();
      setDialogVisible(false);
    });
    setLoader(false);
  };

  // Inline styles for the grid container
  const gridClass: React.CSSProperties = {
    width: "100%",
    margin: "0 auto",
    overflowX: "auto",
  };

  // Headers for CSV export
  const csvHeaders = [
    { label: "Section", key: "methodName" },
    { label: "Error Message", key: "errorMessage" },
    { label: "API URL", key: "apiUrl" },
    { label: "Created AT", key: "createdDate" },
  ];

  return (
    <>
      <div className="card" style={gridClass}>
        {loader ? (
          // Display loading spinner if data is being fetched
          <div className="text-center mt-10 mb-10">
            <div
              className="spinner-border"
              style={{ width: "3rem", height: "3rem" }}
              role="status"
            >
              <span className="sr-only">Loading...</span>
            </div>
          </div>
        ) : (
          <>
            <Grid
              data={data}
              resizable={false}
              className="grid-with-border-bottom"
              style={{
                minWidth: "1200px",
                width: "100%",
              }}
            >
              <GridToolbar className="justify-content-end">
                <div style={{ marginBottom: "10px" }}>
                  <div
                    style={{
                      marginRight: "30px",
                    }}
                  >
                    <CSVLink
                      data={data}
                      headers={csvHeaders}
                      filename="error_logs.csv"
                      className="btn btn-primary"
                    >
                      Export to CSV
                    </CSVLink>
                  </div>
                  <div>
                    <Button onClick={handleDelete} className="btn btn-danger">
                      Delete
                    </Button>
                  </div>
                </div>
              </GridToolbar>
              <GridColumn
                field="methodName"
                title="Section"
                className="p-6 border-top"
                headerClassName="p-6 border-transparent fw-normal text-black"
                width={250}
              />
              <GridColumn
                field="errorMessage"
                title="Error Message"
                className="p-6 border-top"
                headerClassName="p-6 border-transparent fw-normal text-black"
              />
              <GridColumn
                field="apiUrl"
                title="API URL"
                className="p-6 border-top text-primary"
                headerClassName="p-6 border-transparent fw-normal text-black"
              />
              <GridColumn
                field="createdDate"
                title="Created AT"
                className="p-6 border-top"
                headerClassName="p-6 border-transparent fw-normal text-black"
                width={200}
              />
            </Grid>
          </>
        )}
        {/* Confirmation dialog for deletion */}
        {dialogVisible && (
          <Dialog
            title={"Delete Data"}
            onClose={() => setDialogVisible(false)}
            width={350}
          >
            <div>Are you sure you want to delete item ?</div>
            <DialogActionsBar>
              <button
                type="button"
                className="btn btn-danger btn-sm"
                onClick={confirmDelete}
              >
                Delete
              </button>
              <button
                type="button"
                className="btn btn-secondary btn-sm"
                onClick={() => setDialogVisible(false)}
              >
                Cancel
              </button>
            </DialogActionsBar>
          </Dialog>
        )}
      </div>
    </>
  );
};

export { ErrorLog };
