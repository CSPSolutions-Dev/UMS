import React, { useState } from "react";
import { Content } from "../../../_metronic/layout/components/content";
import { ErrorLog } from "./components/ErrorLog";
import PagerComponent from "../../components/pagination/pagination";

const ErrorLogPage: React.FC = () => {
  // State to manage the number of items displayed per page
  const [itemsPerPage, setItemsPerPage] = useState(10);
  // State to manage the current page number
  const [currentPage, setCurrentPage] = React.useState<number>(1);
  // State to manage the total number of elements (e.g., errors) to calculate pagination
  const [totalElement, setTotalElement] = React.useState<number>(0);
  return (
    <>
      <Content>
        <div className="col-xl-12">
          {/* ErrorLog component to display the error logs with pagination */}
          <ErrorLog
            itemsPerPage={itemsPerPage}
            setTotalElement={setTotalElement}
            currentPage={currentPage}
          />
          {/* PagerComponent for pagination controls */}
          <PagerComponent
            totalPage={totalElement}
            currentPage={currentPage}
            onPageChange={setCurrentPage}
            enablePerPage={true}
            itemsPerPage={itemsPerPage}
            setItemsPerPage={setItemsPerPage}
          />
        </div>
      </Content>
    </>
  );
};

export default ErrorLogPage;
