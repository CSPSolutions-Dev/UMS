import { Grid, GridColumn } from "@progress/kendo-react-grid";
import React, { useEffect, useState } from "react";
import { TextArea } from "@progress/kendo-react-inputs";
import {
  formatDate,
  getImageByKey,
  getItems,
  getPdfFileName,
} from "../services";
import { AlertModel } from "../../classification-training/components/AlertModel";
import {
  DataItem,
  HSCodeClassificationLogProps,
  searchValueProps,
  HSCodeSearchResult,
  HSCodeDetailProps,
  DataItemProps,
  HSCodeSearchWorkFlowLogItem,
} from "./interfaces";
import { PDFExport } from "@progress/kendo-react-pdf";
import Logo from "../../../assets/media/webLogo.png";
import Logo2 from "../../../assets/media/logo2.jpg";
import { Dialog } from "@progress/kendo-react-dialogs";
import { searchHSCode } from "../../classification-training/services";

const HSCodeClassificationLog: React.FC<HSCodeClassificationLogProps> = ({
  filter,
  itemsPerPage,
  currentPage,
  setTotalElement,
}) => {
  const [data, setData] = React.useState<any[]>([]);
  const [loader, setLoader] = useState(false);
  const [openAlertModal, setOpenAlertModal] = useState<string | null>(null);

  // Function to fetch data from API based on filter and pagination
  const getAndSetData = async () => {
    if (filter) {
      setLoader(true);
      await getItems(filter, itemsPerPage, currentPage).then((res) => {
        setTotalElement(res.totalPages);
        setData(res.content);
      });
      setLoader(false);
    }
  };
  const updateItem = (id: string, newData: any) => {
    const updatedData = data.map((item: any) =>
      item.hscodeSearchId === id ? { ...item, ...newData } : item
    );
    setData(updatedData);
  };
  // useEffect hook to fetch data when the filter or currentPage changes
  useEffect(() => {
    if (filter) {
      getAndSetData();
    }
  }, [filter, currentPage]); // Re-run effect when `filter` or `currentPage` changes

  // CSS style for grid
  const gridClass: React.CSSProperties = {
    width: "100%",
    margin: "0 auto",
    overflowX: "auto",
  };

  const SearchByUser = (dataItem: DataItem) => {
    const [image, setImage] = useState<string | null>("");
    const [isOpen, setIsOpen] = useState<boolean>(false);

    useEffect(() => {
      // Fetch the image when the component mounts or dataItem changes
      if (dataItem?.hscodeImageAnalysisId?.imageKey) {
        getImageByKey(dataItem?.hscodeImageAnalysisId?.imageKey).then((res) => {
          // Set the image source with base64 encoding
          setImage(`data:image/jpeg;base64,${res}`);
        });
      }
    }, [dataItem]);
    return (
      <td className="position-relative text-center border-top py-6 align-top">
        <div className="px-4">
          {/* Text area displaying the search text */}
          <TextArea
            value={dataItem?.searchText}
            rows={5}
            placeholder="Type here ..."
            readOnly
            style={{
              color: "black",
              fontWeight: 500,
              borderRadius: 6,
              overflowY: "auto",
              borderColor: "1px solid #DEE2E6",
            }}
          />
          {/* Conditionally render image and dialog based on whether image data exists */}
          {image && (
            <>
              <img
                src={image}
                alt="photo"
                style={{
                  cursor: "pointer",
                  width: "100%",
                  marginTop: 10,
                  maxHeight: 150,
                  maxWidth: 150,
                }}
                onClick={() => setIsOpen(true)}
              />
              {/* Dialog for displaying the full-size image */}
              {isOpen && (
                <Dialog
                  title={dataItem?.searchText}
                  onClose={() => setIsOpen(false)}
                  width="80%"
                  height="80%"
                >
                  <img
                    src={image}
                    style={{ width: "100%", maxHeight: "200%" }}
                    alt={dataItem?.searchText}
                  />
                </Dialog>
              )}
            </>
          )}
          <hr className="border-gray-300 border" />
          {/* Display user information and creation date */}
          <div className="text-start text-black fs-7">
            {dataItem?.cusCustomerUserId?.username}
          </div>
          <div className="text-start fs-6 text-gray-500">
            {dataItem?.createdDate
              ? formatDate(new Date(dataItem?.createdDate))
              : ""}
          </div>
        </div>
      </td>
    );
  };

  // Component for rendering a cell with a PDF export option
  const PdfCell = (dataItem: any) => {
    // Ref for PDFExport component to trigger PDF generation
    const pdfExportComponent = React.useRef<PDFExport>(null);

    // Function to handle PDF generation and download
    const handlePrint = async () => {
      if (pdfExportComponent.current) {
        // await (pdfExportComponent.current as any).save(); // Trigger the save method to download the PDF
        await pdfExportComponent.current.save();
        //THIS we have to do BCZ it adding unnecessary colgroup in while multiple pages of pdf.
        setTimeout(() => {
          const colgroups = document.getElementsByTagName("colgroup");
          if (colgroups.length > 2) {
            for (let i = 0; i < colgroups.length; i++) {
              if (i != 0 && i != 1) {
                colgroups[i].remove();
              }
            }
          }
        }, 1000);
      }
    };
    let fileName;
    switch (
      dataItem.hscodePredictionClassificationTypeId
        .hscodePredictionClassificationTypeId
    ) {
      case 1:
        const correctResult = dataItem?.hscodeSearchResults?.find(
          (result: HSCodeSearchResult) => result.correctHSCode
        );
        fileName = getPdfFileName(correctResult?.hsCode || null);
        break;
      case 2:
        fileName = getPdfFileName(dataItem?.providedNewHscode || null);
        break;
      default:
        fileName = getPdfFileName(null);
        break;
    }
    return (
      <td className="p-9 k-bg-white border-top align-top">
        <div>
          <svg
            style={{ cursor: "pointer" }}
            onClick={handlePrint} // Call handlePrint on click
            xmlns="http://www.w3.org/2000/svg"
            width="35"
            height="35"
            viewBox="0 0 24 24"
            fill="none"
          >
            {/* SVG paths for icon details */}
            <path
              d="M18.0749 1.55396L22.2479 5.90396V22.446H6.65918V22.5H22.3012V5.9587L18.0749 1.55396Z"
              fill="#909090"
            />
            <path
              d="M18.0232 1.5H6.60596V22.446H22.248V5.90475L18.0232 1.5Z"
              fill="#F4F4F4"
            />
            <path
              d="M6.49123 2.625H1.69873V7.74525H16.7737V2.625H6.49123Z"
              fill="#7A7B7C"
            />
            <path
              d="M16.8539 7.65818H1.79614V2.53418H16.8539V7.65818Z"
              fill="#DD2025"
            />
            <path
              d="M6.78909 3.40052H5.80884V7.00052H6.57984V5.78627L6.75009 5.79602C6.91552 5.79317 7.07939 5.76354 7.23534 5.70827C7.37207 5.66124 7.49785 5.587 7.60509 5.49002C7.71421 5.39763 7.80025 5.28103 7.85634 5.14952C7.93156 4.93089 7.95843 4.69854 7.93509 4.46852C7.9304 4.3042 7.9016 4.14146 7.84959 3.98552C7.80224 3.87295 7.73198 3.77147 7.64327 3.68754C7.55456 3.60361 7.44935 3.53906 7.33434 3.49802C7.23489 3.46202 7.13215 3.43589 7.02759 3.42002C6.94841 3.4078 6.86845 3.40128 6.78834 3.40052M6.64659 5.12102H6.57984V4.01102H6.72459C6.78847 4.00641 6.85258 4.01622 6.91216 4.03971C6.97175 4.06321 7.02529 4.0998 7.06884 4.14677C7.15908 4.26753 7.20728 4.41452 7.20609 4.56527C7.20609 4.74977 7.20609 4.91702 7.03959 5.03477C6.91964 5.10074 6.78311 5.13119 6.64659 5.12102ZM9.39984 3.39077C9.31659 3.39077 9.23559 3.39677 9.17859 3.39902L9.00009 3.40352H8.41509V7.00352H9.10359C9.36671 7.01073 9.62868 6.96613 9.87459 6.87227C10.0725 6.79376 10.2478 6.6672 10.3846 6.50402C10.5176 6.33936 10.6131 6.14764 10.6643 5.94227C10.7233 5.70967 10.752 5.47045 10.7498 5.23052C10.7644 4.94713 10.7425 4.66306 10.6846 4.38527C10.6297 4.18079 10.5268 3.99234 10.3846 3.83552C10.273 3.70889 10.1364 3.60674 9.98334 3.53552C9.85192 3.4747 9.71368 3.42988 9.57159 3.40202C9.51508 3.39268 9.45785 3.38842 9.40059 3.38927M9.26409 6.34202H9.18909V4.04402H9.19884C9.35346 4.02623 9.5099 4.05413 9.64884 4.12427C9.75058 4.20551 9.83349 4.30787 9.89184 4.42427C9.9548 4.54677 9.9911 4.68122 9.99834 4.81877C10.0051 4.98377 9.99834 5.11877 9.99834 5.23052C10.0014 5.35924 9.99311 5.48799 9.97359 5.61527C9.95047 5.74594 9.90774 5.87237 9.84684 5.99027C9.77791 6.09988 9.68477 6.19225 9.57459 6.26027C9.48205 6.32011 9.37248 6.34804 9.26259 6.33977M13.0726 3.40352H11.2501V7.00352H12.0211V5.57552H12.9961V4.90652H12.0211V4.07252H13.0711V3.40352"
              fill="#464648"
            />
            <path
              d="M16.3358 15.1911C16.3358 15.1911 18.7268 14.7576 18.7268 15.5744C18.7268 16.3911 17.2455 16.0589 16.3358 15.1911ZM14.568 15.2534C14.1881 15.3373 13.8179 15.4602 13.4633 15.6201L13.7633 14.9451C14.0633 14.2701 14.3745 13.3499 14.3745 13.3499C14.7325 13.9524 15.149 14.5181 15.618 15.0389C15.2643 15.0916 14.9138 15.1637 14.568 15.2549V15.2534ZM13.6215 10.3784C13.6215 9.66664 13.8518 9.47239 14.031 9.47239C14.2103 9.47239 14.412 9.55864 14.4188 10.1766C14.3604 10.7981 14.2302 11.4106 14.031 12.0021C13.7581 11.5055 13.6169 10.9473 13.6208 10.3806L13.6215 10.3784ZM10.1348 18.2654C9.40126 17.8266 11.673 16.4759 12.0848 16.4324C12.0825 16.4331 10.9028 18.7244 10.1348 18.2654ZM19.425 15.6711C19.4175 15.5961 19.35 14.7659 17.8725 14.8011C17.2567 14.7912 16.6411 14.8346 16.0328 14.9309C15.4435 14.3372 14.936 13.6675 14.5238 12.9396C14.7835 12.1892 14.9406 11.4071 14.991 10.6146C14.9693 9.71464 14.754 9.19864 14.064 9.20614C13.374 9.21364 13.2735 9.81739 13.3643 10.7159C13.4532 11.3197 13.6208 11.9092 13.863 12.4694C13.863 12.4694 13.5443 13.4616 13.1228 14.4486C12.7013 15.4356 12.4133 15.9531 12.4133 15.9531C11.6803 16.1917 10.9903 16.5462 10.3695 17.0031C9.75151 17.5784 9.50026 18.0201 9.82576 18.4619C10.1063 18.8429 11.088 18.9291 11.9655 17.7794C12.4318 17.1855 12.8577 16.5611 13.2405 15.9104C13.2405 15.9104 14.5785 15.5436 14.9948 15.4431C15.411 15.3426 15.9143 15.2631 15.9143 15.2631C15.9143 15.2631 17.136 16.4924 18.3143 16.4489C19.4925 16.4054 19.4355 15.7446 19.428 15.6726"
              fill="#DD2025"
            />
            <path
              d="M17.9656 1.55786V5.96261H22.1903L17.9656 1.55786Z"
              fill="#909090"
            />
            <path
              d="M18.0232 1.5V5.90475H22.2479L18.0232 1.5Z"
              fill="#F4F4F4"
            />
            <path
              d="M6.73123 3.34265H5.75098V6.94266H6.52498V5.72916L6.69598 5.7389C6.8614 5.73606 7.02528 5.70642 7.18123 5.65115C7.31794 5.60411 7.44372 5.52987 7.55098 5.43291C7.65928 5.34027 7.74453 5.22369 7.79998 5.09241C7.8752 4.87378 7.90207 4.64143 7.87873 4.41141C7.87404 4.24709 7.84523 4.08435 7.79323 3.92841C7.74588 3.81584 7.67562 3.71436 7.58691 3.63042C7.4982 3.54649 7.39299 3.48195 7.27798 3.4409C7.17808 3.40455 7.07482 3.37817 6.96973 3.36215C6.89055 3.34994 6.81059 3.34342 6.73048 3.34265M6.58873 5.06316H6.52198V3.95316H6.66748C6.73136 3.94855 6.79547 3.95836 6.85505 3.98185C6.91464 4.00535 6.96818 4.04193 7.01173 4.08891C7.10197 4.20967 7.15017 4.35666 7.14898 4.50741C7.14898 4.69191 7.14898 4.85916 6.98248 4.97691C6.86253 5.04288 6.72599 5.07258 6.58948 5.06241M9.34198 3.3329C9.25873 3.3329 9.17773 3.33891 9.12073 3.34116L8.94448 3.34566H8.35948V6.94565H9.04798C9.3111 6.95287 9.57306 6.90827 9.81898 6.81441C10.0169 6.7359 10.1922 6.60934 10.329 6.44616C10.462 6.2815 10.5575 6.08978 10.6087 5.88441C10.6676 5.65181 10.6964 5.41259 10.6942 5.17265C10.7088 4.88927 10.6868 4.6052 10.629 4.32741C10.5741 4.12293 10.4712 3.93447 10.329 3.77766C10.2174 3.65103 10.0808 3.54888 9.92773 3.47766C9.79631 3.41684 9.65807 3.37202 9.51598 3.34416C9.45947 3.33482 9.40224 3.33055 9.34498 3.33141M9.20848 6.28415H9.13348V3.98616H9.14323C9.29785 3.96836 9.45429 3.99626 9.59323 4.06641C9.69497 4.14765 9.77788 4.25 9.83623 4.36641C9.89919 4.48891 9.93549 4.62336 9.94273 4.76091C9.94948 4.92591 9.94273 5.0609 9.94273 5.17265C9.94578 5.30138 9.9375 5.43013 9.91798 5.5574C9.89486 5.68808 9.85213 5.8145 9.79123 5.9324C9.72229 6.04202 9.62916 6.13439 9.51898 6.20241C9.42644 6.26225 9.31687 6.29017 9.20698 6.28191M13.0147 3.34566H11.1922V6.94565H11.9632V5.51765H12.9382V4.84866H11.9632V4.01466H13.0132V3.34566"
              fill="white"
            />
          </svg>
          <div
            style={{
              position: "absolute",
              top: "-999999px",
              left: "-999999px",
              height: "100%",
            }}
          >
            <PDFExport
              ref={pdfExportComponent}
              paperSize="A4"
              margin="1cm"
              fileName={`${fileName}.pdf`}
              author="Dubai Customs"
            >
              <div>
                {/* Container for the header with logos */}
                <div>
                  <img
                    src={Logo2}
                    alt="logo2"
                    style={{ width: "18%", float: "left" }}
                  ></img>
                  <img
                    src={Logo}
                    alt="logo"
                    style={{ width: "12%", float: "right" }}
                  ></img>
                </div>
                {/* Component to render the details for the PDF */}
                <HsCodeDetailsPDF dataItem={dataItem} />
              </div>
            </PDFExport>
          </div>
        </div>
      </td>
    );
  };

  const HsCodeDetailsPDF = ({ dataItem }: any) => {
    // Initialize state for modification mode based on classificationWorkflowTypeId
    const [modify, setModify] = useState(
      dataItem?.classificationWorkflowTypeId?.classificationWorkflowTypeId == 1
        ? false
        : true
    );

    // Initialize state for search values, either from dataItem or default values
    const [searchValue, setSearchValue] = useState<searchValueProps>(() => {
      if (dataItem.searchValue) {
        return { ...dataItem.searchValue };
      } else {
        // Find the correct HS Code search result if not provided
        const correctResult = dataItem?.hscodeSearchResults?.find(
          (result: HSCodeSearchResult) => result.correctHSCode
        );

        return {
          classificationWorkflowTypeId:
            dataItem?.classificationWorkflowTypeId
              ?.classificationWorkflowTypeId,
          hscodePredictionClassificationTypeId:
            dataItem?.hscodePredictionClassificationTypeId
              ?.hscodePredictionClassificationTypeId,
          hscodeSearchId: dataItem?.hscodeSearchId,
          providedNewHscode: dataItem?.providedNewHscode,
          selectedHscodeSearchResultId: correctResult
            ? correctResult.hscodeSearchResultId
            : dataItem?.hscodeSearchResults[0]?.hscodeSearchResultId,
        };
      }
    });

    const [newCodeDetail, setNewCodeDetail] =
      useState<HSCodeDetailProps | null>(null);

    useEffect(() => {
      const fetchDefaultHSCode = async () => {
        if (dataItem?.providedNewHscode) {
          try {
            const defDetail = await searchHSCode(dataItem?.providedNewHscode);
            if (defDetail) {
              setNewCodeDetail(defDetail as HSCodeDetailProps);
            }
          } catch (error) {
            console.error("Error fetching default HSCode:", error);
          }
        }
      };

      fetchDefaultHSCode();
    }, [dataItem?.providedNewHscode]);

    return (
      <>
        {/* Display the search text */}

        <p
          className="d-flex"
          style={{
            paddingTop: "20px",
            width: "100%",
            fontSize: "12px",
            marginBottom: "0px",
          }}
        >
          {`Goods Classification Requested: ${dataItem?.searchText}`}
        </p>
        {/* Display the date of classification */}
        <p
          className="d-flex"
          style={{
            paddingTop: "0px",
            marginTop: "0px",
            width: "100%",
            fontSize: "12px",
          }}
        >{`Classification Approved: ${formatDate(
          new Date(
            dataItem?.hsCodeSearchWorkFlowLog[
              dataItem?.hsCodeSearchWorkFlowLog.length - 1
            ]?.modifiedDate
          )
        )}`}</p>

        {/* Container for HS Code search results */}
        <div
          className="align-top border border-secondary"
          style={{
            width: "100%",
            fontSize: "10px",
            marginTop: "5px",
          }}
        >
          {dataItem?.hscodeSearchResults?.map(
            (item: HSCodeSearchResult, index: number) => {
              return (
                <div
                  key={"HsCodeDetails" + index}
                  className="d-flex mb-1 justify-content-between border-bottom border-secondary p-2"
                  style={{ width: "100%" }}
                >
                  <div
                    style={
                      modify
                        ? {
                            pointerEvents: "none", // Disable interaction if in modify mode
                            width: "95%",
                          }
                        : {}
                    }
                    className="d-flex align-items-center"
                    key={`training-${index}`}
                  >
                    {/* Checkbox for selecting HS Code search results */}
                    <div className="form-check form-check-custom form-check-solid">
                      {searchValue.selectedHscodeSearchResultId ===
                        item.hscodeSearchResultId &&
                      searchValue.hscodePredictionClassificationTypeId == 1 ? (
                        <input
                          onChange={(e: any) => {
                            if (e.target.checked) {
                              setSearchValue((prev: any) => ({
                                ...prev,
                                hscodePredictionClassificationTypeId: 1,
                                selectedHscodeSearchResultId:
                                  item.hscodeSearchResultId,
                                providedNewHscode: null,
                              }));
                            }
                          }}
                          className="form-check-input"
                          style={{
                            width: "14px",
                            height: "14px",
                            backgroundColor: "#fff",
                            borderRadius: "2px",
                            appearance: "none",
                            outline: "none",
                            marginRight: "10px",
                          }}
                          type="checkbox"
                          id={"flexRadioChecked" + index}
                          checked={
                            searchValue.selectedHscodeSearchResultId ===
                              item.hscodeSearchResultId &&
                            searchValue.hscodePredictionClassificationTypeId ==
                              1
                              ? true
                              : false
                          }
                        />
                      ) : (
                        <div
                          style={{
                            width: "14px",
                            height: "14px",
                            backgroundColor: "#fff",
                            borderRadius: "2px",
                            appearance: "none",
                            outline: "none",
                            marginRight: "10px",
                          }}
                        ></div>
                      )}
                    </div>

                    <div>
                      <div>
                        <span className="fw-bolder ">{item?.hsCode} : </span>
                        <span className="fw-normal">
                          {item?.hscodeDescription}
                        </span>{" "}
                      </div>
                      <div className="">
                        <span className="fw-bolder">Heading :</span>{" "}
                        {item?.headingName}
                      </div>
                      <div className="">
                        <span className="fw-bolder">Section : </span>
                        {item?.sectionName}
                      </div>
                      {/* <div className="">
                      <span className="fw-bolder">Confidence : </span>
                      {item.confidenceScore
                        ? (item.confidenceScore * 100).toFixed(2)
                        : 0.0}
                      %
                    </div> */}
                    </div>
                  </div>
                </div>
              );
            }
          )}
          <div
            style={
              modify
                ? {
                    pointerEvents: "none",
                  }
                : {}
            }
          >
            {/* Checkbox for "Provide new" classification */}
            <div
              className="d-flex align-items-center mb-1 border-bottom p-2 border-secondary text-gray-900"
              style={{ fontSize: "10px" }}
            >
              <div className="form-check form-check-custom form-check-solid">
                {searchValue.hscodePredictionClassificationTypeId == 2 ? (
                  <input
                    className="form-check-input"
                    style={{
                      width: "14px",
                      height: "14px",
                      backgroundColor: "#fff",
                      borderRadius: "2px",
                      appearance: "none",
                      outline: "none",
                    }}
                    type="checkbox"
                    value=""
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSearchValue((prev: any) => ({
                          ...prev,
                          hscodePredictionClassificationTypeId: 2,
                          selectedHscodeSearchResultId: null,
                          providedNewHscode: null,
                        }));
                      }
                    }}
                    checked={
                      searchValue.hscodePredictionClassificationTypeId == 2
                    }
                  />
                ) : (
                  <div
                    style={{
                      width: "14px",
                      height: "14px",
                      backgroundColor: "#fff",
                      borderRadius: "2px",
                      appearance: "none",
                      outline: "none",
                    }}
                  ></div>
                )}
              </div>
              {searchValue.hscodePredictionClassificationTypeId == 2 &&
              dataItem.providedNewHscode ? (
                <div className="mx-3 d-flex mb-1 justify-content-between border-none min-h-80px ml-4">
                  <div className=" gap-5" key={`training`}>
                    <span
                      className="text-nowrap text-black fw-bolder"
                      style={{ fontWeight: 600 }}
                    >
                      {`Provided new HS Code`}
                    </span>
                    <div>
                      <div>
                        <span className="fw-bolder ">
                          {newCodeDetail?.hsCode} :{" "}
                        </span>
                        <span className="fw-normal text-black">
                          {newCodeDetail?.hscodeDescription}
                        </span>{" "}
                      </div>
                      <div>
                        <span className="fw-bolder">Heading :</span>{" "}
                        {newCodeDetail?.headingName}
                      </div>
                      <div>
                        <span className="fw-bolder">Section : </span>
                        {newCodeDetail?.sectionName}
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <span
                  className="mx-3 text-nowrap text-black"
                  style={{ fontWeight: 600 }}
                >
                  Provide new
                </span>
              )}
            </div>

            {/* Checkbox for "Provided description is not enough to correctly classify the goods (to be discarded)." classification */}
            <div
              className="d-flex align-items-center mb-1 border-bottom p-2 border-secondary text-gray-900"
              style={{ fontSize: "10px" }}
            >
              <div className="form-check form-check-custom form-check-solid">
                {searchValue.hscodePredictionClassificationTypeId == 3 ? (
                  <input
                    className="form-check-input"
                    style={{
                      width: "14px",
                      height: "14px",
                      backgroundColor: "#fff",
                      borderRadius: "2px",
                      appearance: "none",
                      outline: "none",
                    }}
                    type="checkbox"
                    value=""
                    id="flexRadioSm"
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSearchValue((prev: any) => ({
                          ...prev,
                          hscodePredictionClassificationTypeId: 3,
                          selectedHscodeSearchResultId: null,
                          providedNewHscode: null,
                        }));
                      }
                    }}
                    checked={
                      searchValue.hscodePredictionClassificationTypeId == 3
                    }
                  />
                ) : (
                  <div
                    style={{
                      width: "14px",
                      height: "14px",
                      backgroundColor: "#fff",
                      borderRadius: "2px",
                      appearance: "none",
                      outline: "none",
                    }}
                  ></div>
                )}
              </div>
              <span className="mx-3 text-black" style={{ fontWeight: 600 }}>
                Provided description is not enough to correctly classify the
                goods (to be discarded).
              </span>
            </div>

            {/* Checkbox for "Provided description of goods is invalid (to be discarded)." classification */}
            <div className="d-flex align-items-center mb-1 p-2 text-gray-900">
              <div className="form-check form-check-custom form-check-solid">
                {searchValue.hscodePredictionClassificationTypeId == 4 ? (
                  <input
                    style={{
                      width: "14px",
                      height: "14px",
                      backgroundColor: "#fff",
                      borderRadius: "2px",
                      appearance: "none",
                      outline: "none",
                    }}
                    className="form-check-input"
                    type="checkbox"
                    value=""
                    id="flexRadioSm"
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                      if (e.target.checked) {
                        setSearchValue((prev: any) => ({
                          ...prev,
                          hscodePredictionClassificationTypeId: 4,
                          selectedHscodeSearchResultId: null,
                          providedNewHscode: null,
                        }));
                      }
                    }}
                    checked={
                      searchValue.hscodePredictionClassificationTypeId == 4
                    }
                  />
                ) : (
                  <div
                    style={{
                      width: "14px",
                      height: "14px",
                      backgroundColor: "#fff",
                      borderRadius: "2px",
                      appearance: "none",
                      outline: "none",
                    }}
                  ></div>
                )}
              </div>

              <span
                className="mx-3 text-black"
                style={{ fontWeight: 600, fontSize: "10px" }}
              >
                Provided description of goods is invalid (to be discarded).
              </span>
            </div>
          </div>
        </div>
      </>
    );
  };

  const HsCodeDetails = (dataItem: any) => {
    // Initialize variable to hold HS Code details
    let item = null;

    // Check if the prediction classification type ID is 1
    // and find the correct HS Code from search results
    if (
      dataItem.hscodePredictionClassificationTypeId
        ?.hscodePredictionClassificationTypeId == 1
    ) {
      item = dataItem.hscodeSearchResults.find(
        (item: HSCodeSearchResult) => item.correctHSCode === true
      );
    }
    const [newCodeDetail, setNewCodeDetail] =
      useState<HSCodeDetailProps | null>(null);

    useEffect(() => {
      const fetchDefaultHSCode = async () => {
        if (dataItem?.providedNewHscode && !dataItem.providedNewHscodeDetails) {
          try {
            const defDetail = await searchHSCode(dataItem?.providedNewHscode);
            if (defDetail) {
              setNewCodeDetail(defDetail);
            }
          } catch (error) {
            console.error("Error fetching default HSCode:", error);
          }
        }
      };

      fetchDefaultHSCode();
    }, [dataItem?.providedNewHscode]);
    useEffect(() => {
      if (newCodeDetail) {
        updateItem(dataItem.hscodeSearchId, {
          ...dataItem,
          providedNewHscodeDetails: { ...newCodeDetail },
        });
      }
    }, [newCodeDetail]);

    return (
      <>
        <td className="border-top py-6 px-3 align-top">
          {/* Display details if an HS Code item is found */}
          {item && (
            <div className="d-flex mb-1 justify-content-between border-bottom border-none p-6 bg-light rounded min-h-80px ml-4">
              <div className="d-flex gap-5" key={`training`}>
                <div>
                  <div>
                    <span className="fw-bolder ">{item?.hsCode} : </span>
                    <span className="fw-normal text-gray-500">
                      {item?.hscodeDescription}
                    </span>{" "}
                  </div>
                  <div>
                    <span className="fw-bolder">Heading :</span>{" "}
                    {item?.headingName}
                  </div>
                  <div>
                    <span className="fw-bolder">Section : </span>
                    {item?.sectionName}
                  </div>
                  <div>
                    <span className="fw-bolder">Confidence : </span>
                    {item.confidenceScore
                      ? (item.confidenceScore * 100).toFixed(2)
                      : 0.0}
                    %
                  </div>
                </div>
              </div>
              <div
                className="d-inline-grid"
                style={{ alignContent: "space-between" }}
              >
                {/* Display favorite icon with conditional styling */}
                <div
                  style={{
                    display: "inline-flex",
                    justifyContent: "flex-end",
                  }}
                  title="Favorite"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    xlinkTitle="Favorite"
                    className={`bi bi-star-fill ${
                      dataItem.isFavourite ? "text-warning" : "text-secondary"
                    }`}
                    viewBox="0 0 16 16"
                  >
                    <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.282.95l-3.522 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z" />
                  </svg>
                  {/* Display rating icons based on search rating type */}
                </div>
                <div style={{ fontSize: "5px", display: "flex" }}>
                  {item.hscodeSearchRatingComment && (
                    <i
                      onClick={() => {
                        setOpenAlertModal(
                          item?.hscodeSearchRatingComment || ""
                        );
                      }}
                      style={{ fontSize: "1.1rem", cursor: "pointer" }}
                      className="fa-regular me-3 fa-message"
                      title={item.hscodeSearchRatingComment}
                    />
                  )}
                  {item.hscodeSearchRatingTypeId?.hscodeSearchRatingTypeId ==
                    1 && (
                    <i
                      style={{ fontSize: "1.2rem" }}
                      className="fa-solid fa-thumbs-up"
                      title="Correct"
                    />
                  )}
                  {item.hscodeSearchRatingTypeId?.hscodeSearchRatingTypeId ==
                    2 && (
                    <i
                      style={{ fontSize: "1.2rem" }}
                      className="fa-solid fa-thumbs-down"
                      title={"Incorrect"}
                    />
                  )}
                  {item.hscodeSearchRatingTypeId?.hscodeSearchRatingTypeId ==
                    3 && (
                    <i
                      style={{ fontSize: "1.2rem" }}
                      className="fa-solid fa-circle-question"
                      title={`I don't know`}
                    />
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Display additional information based on classification type ID */}
          {dataItem.hscodePredictionClassificationTypeId
            ?.hscodePredictionClassificationTypeId == 2 && (
            <div className="d-flex mb-1 justify-content-between border-bottom border-none p-6 bg-light rounded min-h-80px ml-4">
              <div className=" gap-5" key={`training`}>
                <span
                  className="text-nowrap fs-16 text-black fw-bolder"
                  style={{ fontWeight: 600 }}
                >
                  {`Provided new HS Code`}
                </span>
                <div>
                  <div>
                    <span className="fw-bolder ">
                      {dataItem?.providedNewHscodeDetails?.hsCode} :{" "}
                    </span>
                    <span className="fw-normal text-gray-500">
                      {dataItem?.providedNewHscodeDetails?.hscodeDescription}
                    </span>{" "}
                  </div>
                  <div>
                    <span className="fw-bolder">Heading :</span>{" "}
                    {dataItem?.providedNewHscodeDetails?.headingName}
                  </div>
                  <div>
                    <span className="fw-bolder">Section : </span>
                    {dataItem?.providedNewHscodeDetails?.sectionName}
                  </div>
                </div>
              </div>
            </div>
          )}
          {dataItem.hscodePredictionClassificationTypeId
            ?.hscodePredictionClassificationTypeId == 3 && (
            <div className="d-flex mb-1 border-bottom border-none p-3 bg-light fs-6 text-gray-900 rounded ">
              <span
                className="mx-3 fs-8 text-black"
                style={{ fontWeight: 600 }}
              >
                Marked as Provided description is not enough to correctly
                classify the goods (to be discarded).
              </span>
            </div>
          )}
          {dataItem.hscodePredictionClassificationTypeId
            ?.hscodePredictionClassificationTypeId == 4 && (
            <div className="d-flex mb-1 border-bottom border-none p-3 bg-light fs-6 text-gray-900 rounded ">
              <span
                className="mx-3 fs-8 text-black"
                style={{ fontWeight: 600 }}
              >
                Marked as Provided description of goods is invalid (to be
                discarded).
              </span>
            </div>
          )}
        </td>
      </>
    );
  };

  const hsCodeUserDetails = (dataItem: DataItemProps) => {
    return (
      <>
        <td className="border-top position-relative py-6 px-3 fs-6 align-top">
          <div className="border-none text-gray-900">
            {/* Map over the workflow log to display details based on classification type */}
            {dataItem?.hsCodeSearchWorkFlowLog.map(
              (item: HSCodeSearchWorkFlowLogItem, index: any) => {
                // Handle classification type ID 2 (Classified or Rejected)
                if (
                  item?.classificationWorkflowTypeId
                    ?.classificationWorkflowTypeId === 2
                ) {
                  return (
                    <div key={index}>
                      {" "}
                      <div className="mb-3 d-block">
                        {/* Display action type (Classified or Rejected) */}
                        <span className="fw-bolder">
                          {item?.classificationWorkflowActionsType
                            ?.classificationWorkflowActionsTypeId === 1 &&
                            "Classified By"}
                          {item?.classificationWorkflowActionsType
                            ?.classificationWorkflowActionsTypeId === 2 &&
                            "Rejected By"}
                        </span>
                        <br />
                        <span className="fw-normal text-gray-600">
                          {/* Display username of the classified/rejected user */}
                          {item?.classifiedByUserId?.username}
                        </span>
                      </div>
                      <div className="mb-5">
                        {/* Display date of classification/rejection */}
                        <span className="fw-bolder">
                          {item?.classificationWorkflowActionsType
                            ?.classificationWorkflowActionsTypeId === 1 &&
                            "Date Classified"}
                          {item?.classificationWorkflowActionsType
                            ?.classificationWorkflowActionsTypeId === 2 &&
                            "Date Rejected"}
                        </span>
                        <br />
                        <span className="fw-normal text-gray-600">
                          {/* Format and display the date */}
                          {item?.dateClassified
                            ? formatDate(new Date(item?.dateClassified))
                            : ""}
                        </span>
                      </div>
                    </div>
                  );
                  // Handle classification type ID 3 (Approved)
                } else if (
                  item?.classificationWorkflowTypeId
                    ?.classificationWorkflowTypeId === 3
                ) {
                  return (
                    <div key={index}>
                      <div className="mb-3 d-block">
                        {/* Display approval action */}
                        <span className="fw-bolder">Verified By</span>
                        <br />
                        <span className="fw-normal text-gray-600">
                          {/* Display username of the approver */}
                          {item?.classifiedByUserId?.username}
                        </span>
                      </div>
                      <div className="mb-5">
                        <span className="fw-bolder">Date Verified</span>
                        <br />
                        <span className="fw-normal text-gray-600">
                          {item?.dateClassified
                            ? formatDate(new Date(item?.dateClassified))
                            : ""}
                        </span>
                      </div>
                    </div>
                  );
                  // Handle classification type ID 4 (Signed)
                } else if (
                  item?.classificationWorkflowTypeId
                    ?.classificationWorkflowTypeId === 4
                ) {
                  return (
                    <div key={index}>
                      <div className="mb-3 d-block">
                        <span className="fw-bolder">Signed By</span>
                        <br />
                        <span className="fw-normal text-gray-600">
                          {item?.classifiedByUserId?.username}
                        </span>
                      </div>
                      <div className="mb-5">
                        <span className="fw-bolder">Date Signed</span>
                        <br />
                        <span className="fw-normal text-gray-600">
                          {item?.dateClassified
                            ? formatDate(new Date(item?.dateClassified))
                            : ""}
                        </span>
                      </div>
                    </div>
                  );
                } else {
                  return null;
                }
              }
            )}
          </div>
        </td>
      </>
    );
  };

  const [minWidth, setMinWidth] = useState("1200px");
  const [columnWidth, setColumnWidth] = useState(500);

  useEffect(() => {
    // Function to update minimum width and column width based on window size
    const updateMinWidth = () => {
      const width = window.innerWidth;
      if (width <= 576) {
        setMinWidth("1000px");
        setColumnWidth(400);
      } else if (width <= 768) {
        setMinWidth("400px");
        setColumnWidth(300);
      } else if (width <= 1024) {
        setMinWidth("400px");
        setColumnWidth(300);
      } else if (width <= 1280) {
        setMinWidth("800px");
        setColumnWidth(400);
      } else if (width <= 1440) {
        setMinWidth("900px");
        setColumnWidth(500);
      } else {
        setMinWidth("100%");
        setColumnWidth(700);
      }
    };
    updateMinWidth();
    // Add event listener for window resize to update dimensions
    window.addEventListener("resize", updateMinWidth);
    // Clean up event listener on component unmount
    return () => window.removeEventListener("resize", updateMinWidth);
  }, []); // Empty dependency array ensures effect runs once on mount

  return (
    <>
      <div className="card" style={gridClass}>
        {loader ? ( // Display loading spinner when data is being fetched
          <div className="text-center mt-10">
            <div
              className="spinner-border"
              style={{ width: "3rem", height: "3rem" }}
              role="status"
            >
              <span className="sr-only">Loading...</span>
            </div>
          </div>
        ) : (
          <>
            {/* Kendo Grid to display fetched data */}
            <Grid
              data={data}
              resizable={false}
              style={{
                minWidth: minWidth,
                width: "100%",
              }}
            >
              {/* Column displaying user who searched HS Code */}
              <GridColumn
                field="searched_by_user"
                title="Searched By User"
                headerClassName="p-6 border-transparent fw-bold border-bottom title-custom"
                className="p-3 border-bottom"
                cell={(props) => SearchByUser(props.dataItem)} // Custom cell content
                width={200}
              />
              {/* Column displaying selected HS Code */}
              <GridColumn
                field="selected_hS_code"
                title="Selected HS Code"
                headerClassName="p-6 border-transparent fw-bold border-bottom title-custom"
                cell={(props) => HsCodeDetails(props.dataItem)} // Custom cell content
                width={columnWidth}
              />
              {/* Column for downloading PDF */}
              <GridColumn
                field="downloadPdf"
                title="Download PDF"
                headerClassName="p-6  border-transparent fw-bold border-bottom title-custom"
                cell={({ dataItem }) => PdfCell(dataItem)} // Custom cell content
                width={200}
              />
              {/* Empty column for additional user details */}
              <GridColumn
                field=""
                title=""
                headerClassName="bg-white"
                className=""
                cell={(props) => hsCodeUserDetails(props.dataItem)} // Custom cell content
                width={200}
              />
            </Grid>
          </>
        )}
      </div>
      {/* Conditionally rendering Alert modal when openAlertModal is set */}
      {openAlertModal && (
        <AlertModel
          cancelButton={() => {
            setOpenAlertModal(null); // Close modal on cancel
          }}
          message={openAlertModal}
          heading="Customer Message"
        />
      )}
    </>
  );
};

export { HSCodeClassificationLog };
