import React, { useState } from "react";
import { Content } from "../../../_metronic/layout/components/content";
import { HSCodeClassificationLog } from "./components/HSCodeClassificationLog";
import { ClassificationHeader } from "./components/ClassificationHeader";
import PagerComponent from "../../components/pagination/pagination";
import { FilterType } from "./components/interfaces";

/**
 * ClassificationLogPage component is the main page that displays HSCode classification logs.
 * It includes pagination, filters, and displays log data.
 */

const ClassificationLogPage: React.FC = () => {
  const [filter, setFilter] = useState<FilterType | null>(null);
  const [itemsPerPage, setItemsPerPage] = useState(5);
  const [currentPage, setCurrentPage] = React.useState<number>(1);
  const [totalElement, setTotalElement] = React.useState<number>(0);

  // Handle changes in the number of items per page
  const handleItemsPerPageChange = (itemsPerPage: number) => {
    setItemsPerPage(itemsPerPage);
    setCurrentPage(1);
  };

  // Function to reset pagination when filter or other conditions change
  const resetPagination = () => {
    setCurrentPage(1);
    setTotalElement(0);
  };

  return (
    <>
      {/* Wrapper for the main content */}
      <Content>
        {/* Header component to manage filter state and reset pagination */}
        <ClassificationHeader
          filter={filter}
          setFilter={setFilter}
          resetPagination={resetPagination}
        />
        {/* Component to display classification logs, passing filters, items per page, and current pagination info */}
        <HSCodeClassificationLog
          filter={filter}
          itemsPerPage={itemsPerPage}
          setTotalElement={setTotalElement}
          currentPage={currentPage}
        />
        {/* Pagination component to manage page changes, items per page, and total number of elements */}
        <PagerComponent
          totalPage={totalElement}
          currentPage={currentPage}
          onPageChange={setCurrentPage}
          itemsPerPage={itemsPerPage}
          setItemsPerPage={handleItemsPerPageChange}
        />
      </Content>
    </>
  );
};

export default ClassificationLogPage;
