import { Route, Routes } from "react-router-dom";
import { Error500 } from "./components/Error500";
import { Error404 } from "./components/Error404";
import { ErrorsLayout } from "./ErrorsLayout";

// ErrorsPage component defines routes for error pages and layout
const ErrorsPage = () => (
  <Routes>
    {/* Define routes with ErrorsLayout as the wrapper for error pages */}
    <Route element={<ErrorsLayout />}>
      {/* Route for 404 Not Found error page */}
      <Route path="404" element={<Error404 />} />

      {/* Route for 500 Internal Server Error page */}
      <Route path="500" element={<Error500 />} />

      {/* Default route that also renders the 404 Not Found page */}
      <Route index element={<Error404 />} />
    </Route>
  </Routes>
);

export { ErrorsPage };
