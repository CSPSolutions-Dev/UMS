import { FC } from "react";
import { Link } from "react-router-dom";
import { toAbsoluteUrl } from "../../../../_metronic/helpers";

const Error404: FC = () => {
  return (
    <>
      {/* Main heading for the error page */}
      <h1 className="fw-bolder fs-2hx text-gray-900 mb-4">Oops!</h1>
      {/* Subheading providing a brief description of the error */}
      <div className="fw-semibold fs-6 text-gray-500 mb-7">
        We can't find that page.
      </div>

      {/* Container for error image, showing different images based on theme */}
      <div className="mb-3">
        {/* Image shown in light theme */}
        <img
          src={toAbsoluteUrl("media/auth/404-error.png")}
          className="mw-100 mh-300px theme-light-show"
          alt=""
        />
        {/* Image shown in dark theme */}
        <img
          src={toAbsoluteUrl("media/auth/404-error-dark.png")}
          className="mw-100 mh-300px theme-dark-show"
          alt=""
        />
      </div>
      {/* Link to return to the dashboard */}
      <div className="mb-0">
        <Link to="/" className="btn btn-sm btn-primary">
          Return Home
        </Link>
      </div>
    </>
  );
};

export { Error404 };
