import React, { useState } from "react";
import { Content } from "../../../_metronic/layout/components/content";
import { HSCodeSearchToggles } from "./components/HSCodeSearchToggles";
import { SearchHeader } from "./components/HSCodeSearchHeader";
import { FilterProps } from "./components/interfaces";
// import PagerComponent from "../../components/pagination/pagination";

// Interface for managing filter state

const HSCodeSearchPage: React.FC = () => {
  // State to manage filter values
  const [filter, setFilter] = useState<FilterProps>({
    searchCode: null,
    searchDescription: "",
  });
  // Uncomment and use the following if pagination is needed
  // const [currentPage, setCurrentPage] = React.useState<number>(1);
  // const [totalElement, setTotalElement] = React.useState<number>(0);
  // const itemsPerPage = 4;
  // const resetPagination = () => {
  //   setCurrentPage(1);
  //   setTotalElement(0);
  // };
  return (
    <>
      <Content>
        <div className="col-xl-12">
          {/* SearchHeader component for managing and updating search filters */}
          <SearchHeader
            setFilter={setFilter}
            filter={filter}
            // resetPagination={resetPagination}
          />

          {/* Display HSCodeSearchToggles if any filter is applied */}
          {(filter.searchCode || filter.searchDescription) && (
            <HSCodeSearchToggles
              filter={filter}
              // Uncomment and use the following for pagination handling
              // itemsPerPage={itemsPerPage}
              // setTotalElement={setTotalElement}
              // currentPage={currentPage}
            />
          )}
          {/* Uncomment the PagerComponent for pagination if needed */}
          {/* <PagerComponent
            itemsPerPage={itemsPerPage}
            totalItems={totalElement}
            currentPage={currentPage}
            onPageChange={setCurrentPage}
          /> */}
        </div>
      </Content>
    </>
  );
};

export default HSCodeSearchPage;
