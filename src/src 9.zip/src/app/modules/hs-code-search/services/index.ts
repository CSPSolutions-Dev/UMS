import { HscodeSearchControllerApi } from "../../../../api";
import { AxiosResponse } from "axios";
import { FilterProps } from "../components/interfaces";

const API = new HscodeSearchControllerApi();

/**
 * Fetches HSCode items based on the provided filters.
 * @param filter - The filter object containing search criteria.
 * @returns A promise that resolves to an array of items or an empty array.
 */

export const getItems = async (filter: FilterProps) => {
  try {
    // If a search code is provided in the filter
    if (filter.searchCode) {
      // Perform a GET request to search for commodity details by HS code
      const response: AxiosResponse = await API.searchCommodityDetailsByCode(
        filter.searchCode
      );

      // Check if the response contains data and the expected response object
      if (response.data && response.data.responseObject[0]) {
        // Map the response data to the desired format
        return response.data.responseObject[0].map((item: any) => ({
          hscodeSearchResult: {
            sectionName: item.sectionName,
            headingName: item.hsName,
            hsCode: item.hsCode,
            hscodeDescription: item.hscodeDescription,
          },
          applicable_Exemptions: item.applicableExemptions,
          countries_Free_Trade: item.countriesFreeTrade,
          customs_Duty: item.customsDuty,
          excise_Duty: item.exciseDuty,
          measurement_Unit: item.measurementUnit,
          permit_Issuing_Authorities: item.permitIssuingAuthorities,
          restricted: item.restricted,
        }));
      } else {
        // Return an empty array if no results are found
        return [];
      }
    } else if (filter.searchDescription) {
      // If a search description is provided, perform a POST request for HSCode search
      const response: AxiosResponse = await API.startHSCodeSearch([
        filter.searchDescription,
      ]);
      // Return the response data
      return response.data.responseObject;
    } else {
      // Return an empty array if no filters are applied
      return [];
    }
  } catch (e) {
    // Handle any errors and return an empty array
    return [];
  }
};

// Function to search HS Code by its code
export const searchCountries = async (code: string) => {
  try {
    const response: AxiosResponse = await API.getCountriesByHsCode(code);
    return response.data.responseObject[0];
  } catch (e) {
    return [];
  }
};

export const searchCountriesTrade = async (
  countryCode: string,
  code: string
) => {
  try {
    const response: AxiosResponse = await API.getTradeAgreement(
      countryCode,
      code
    );
    return response.data.responseObject[0];
  } catch (e) {
    return [];
  }
};
