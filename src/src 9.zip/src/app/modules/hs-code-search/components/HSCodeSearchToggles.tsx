import * as React from "react";
import {
  Grid,
  GridColumn,
  GridDetailRowProps,
  GridExpandChangeEvent,
} from "@progress/kendo-react-grid";
import { Product, FilterProps, HSCodeSearchResponse } from "./interfaces";
import { getItems, searchCountries, searchCountriesTrade } from "../services";
import { PDFExport, PDFExportProps } from "@progress/kendo-react-pdf";
import Logo from "../../../assets/media/webLogo.png";
import Logo2 from "../../../assets/media/logo2.jpg";
// import AsyncSelect from "react-select/async";
import Select from "react-select";

import { components } from "react-select";
import { position } from "@progress/kendo-popup-common";

interface FilterState {
  filter: FilterProps;
}

interface GetItemsResponse {
  data: HSCodeSearchResponse[];
}

const CustomMenuList = (props: any) => {
  // Extract children and rest of the props
  const { children, ...rest } = props;
  // Determine max height of the menu list based on the number of items
  const maxHeight = children.length > 2 ? "150px" : "auto"; // Adjust based on number of items
  // Function to handle scroll events, prevents scroll event from propagating
  const handleScroll = (e: React.WheelEvent) => {
    e.stopPropagation(); // Stops the event from bubbling up the DOM tree
  };
  return (
    <components.MenuList
      {...props}
      className="custom-scrollbar"
      onWheel={handleScroll}
      style={{ maxHeight }}
    >
      {props.children} {/* Render the children passed to this component */}
    </components.MenuList>
  );
};
/**
 * DetailComponent - Renders the detailed view for each row in the grid.
 *
 * This function is responsible for displaying additional details such as restricted status, customs duty, permit issuing authorities, excise duty,
 * measurement unit, and free trade agreement countries when a row is expanded in the grid.
 *
 * @param {GridDetailRowProps} props - Contains the data item (row) for which the details are being rendered.
 *
 * @returns JSX element representing the detailed row view with various data fields, or a loading placeholder if no data is present.
 */
// Custom styles for the react-select component
const customStyles = {
  // Customize the menu style of the select component
  menu: (provided: any) => ({
    // Spread the default provided styles to retain the base styling
    ...provided,
    // Set the z-index to ensure the menu appears above other elements
    zIndex: 9999,
    position: "static",
  }),
};

/**
 * hsCodeDetails - Renders the HS Code and related details in a table cell.
 *
 * This function is responsible for rendering the HS Code, description, and confidence score (if applicable)
 * for each row in the grid, based on the data and filter provided.
 *
 * @param {any} dataItem - The item from the data set for the current row, containing the HS Code details.
 * @param {any} filter - The filter object that contains the search parameters, used to determine if the confidence score should be displayed.
 *
 * @returns JSX element representing the HS code details inside a table cell.
 */

const hsCodeDetails = (dataItem: any, filter: FilterProps) => {
  return (
    <>
      <td className="border-top fs-6 py-6 px-3">
        <div className="k-bg-white">
          {/* Display HS Code */}
          <p className="text-primary pe-auto mb-0">
            {dataItem?.hscodeSearchResult?.hsCode}
          </p>
          {/* Display HS Code description */}
          <div>{dataItem?.hscodeSearchResult?.hscodeDescription}</div>

          {/* Conditionally display the confidence score based on the search filter */}
          {filter.searchDescription && !filter.searchCode && (
            <div>
              {/* Confidence score is displayed only when there is a search by description (not by code) */}
              Confidence:{" "}
              {dataItem?.hscodeSearchResult?.confidenceScore
                ? // Convert the confidence score to a percentage (multiplied by 100) and fix to 2 decimal places
                  (
                    Number(dataItem?.hscodeSearchResult?.confidenceScore) * 100
                  ).toFixed(2)
                : 0.0}
              %
            </div>
          )}
        </div>
      </td>
    </>
  );
};
export const getPdfFileName = (hsCode: string | null) => {
  const date = new Date();
  const year = date.getFullYear();
  const month = (date.getMonth() + 1).toString().padStart(2, "0"); // Ensures month is always two digits
  const day = date.getDate().toString().padStart(2, "0"); // Ensures day is always two digits
  const hours = date.getHours().toString().padStart(2, "0"); // Ensures hours are two digits
  const minutes = date.getMinutes().toString().padStart(2, "0"); // Ensures minutes are two digits
  const seconds = date.getSeconds().toString().padStart(2, "0"); // Ensures seconds are two digits
  return hsCode
    ? `${hsCode}_` + `${day}_${month}_${year}`
    : `${day}_${month}_${year}_${hours}${minutes}${seconds}`;
};
/**
 * PdfCell Component
 *
 * This component generates a PDF export for the provided `dataItem` using the KendoReact PDFExport component.
 * It renders a hidden PDF container and triggers the download when the user clicks on a relevant button in the table cell.
 *
 * @param {Object} dataItem - The data for the HS code search result that will be included in the PDF.
 */
const PdfCell = (dataItem: any) => {
  // Reference to the PDFExport component that handles the PDF generation and download
  const pdfExportComponent = React.useRef<PDFExport>(null);

  /**
   * handlePrint - Handles the action to print (export) the PDF when called.
   * It checks if the `pdfExportComponent` is available and calls the `save` method to generate the PDF.
   */
  const handlePrint = async () => {
    if (pdfExportComponent.current) {
      await pdfExportComponent.current.save(); // Triggers the PDF export and save process
      // await (pdfExportComponent.current as any).save(); // Triggers the PDF export and save process
    }
  };
  const [countryTrade, setCountryTrade] = React.useState([]);

  React.useEffect(() => {
    if (dataItem?.countryCode) {
      searchCountriesTrade(
        dataItem?.countryCode?.value,
        dataItem.hscodeSearchResult.hsCode
      ).then((res) => {
        setCountryTrade(res);
      });
    }
  }, [dataItem?.countryCode]);
  return (
    <td className="p-9 k-bg-white border-top">
      {/* Hidden PDF export container */}
      <svg
        style={{ cursor: "pointer" }}
        onClick={handlePrint}
        xmlns="http://www.w3.org/2000/svg"
        width="35"
        height="35"
        viewBox="0 0 24 24"
        fill="none"
      >
        <path
          d="M18.0749 1.55396L22.2479 5.90396V22.446H6.65918V22.5H22.3012V5.9587L18.0749 1.55396Z"
          fill="#909090"
        />
        <path
          d="M18.0232 1.5H6.60596V22.446H22.248V5.90475L18.0232 1.5Z"
          fill="#F4F4F4"
        />
        <path
          d="M6.49123 2.625H1.69873V7.74525H16.7737V2.625H6.49123Z"
          fill="#7A7B7C"
        />
        <path
          d="M16.8539 7.65818H1.79614V2.53418H16.8539V7.65818Z"
          fill="#DD2025"
        />
        <path
          d="M6.78909 3.40052H5.80884V7.00052H6.57984V5.78627L6.75009 5.79602C6.91552 5.79317 7.07939 5.76354 7.23534 5.70827C7.37207 5.66124 7.49785 5.587 7.60509 5.49002C7.71421 5.39763 7.80025 5.28103 7.85634 5.14952C7.93156 4.93089 7.95843 4.69854 7.93509 4.46852C7.9304 4.3042 7.9016 4.14146 7.84959 3.98552C7.80224 3.87295 7.73198 3.77147 7.64327 3.68754C7.55456 3.60361 7.44935 3.53906 7.33434 3.49802C7.23489 3.46202 7.13215 3.43589 7.02759 3.42002C6.94841 3.4078 6.86845 3.40128 6.78834 3.40052M6.64659 5.12102H6.57984V4.01102H6.72459C6.78847 4.00641 6.85258 4.01622 6.91216 4.03971C6.97175 4.06321 7.02529 4.0998 7.06884 4.14677C7.15908 4.26753 7.20728 4.41452 7.20609 4.56527C7.20609 4.74977 7.20609 4.91702 7.03959 5.03477C6.91964 5.10074 6.78311 5.13119 6.64659 5.12102ZM9.39984 3.39077C9.31659 3.39077 9.23559 3.39677 9.17859 3.39902L9.00009 3.40352H8.41509V7.00352H9.10359C9.36671 7.01073 9.62868 6.96613 9.87459 6.87227C10.0725 6.79376 10.2478 6.6672 10.3846 6.50402C10.5176 6.33936 10.6131 6.14764 10.6643 5.94227C10.7233 5.70967 10.752 5.47045 10.7498 5.23052C10.7644 4.94713 10.7425 4.66306 10.6846 4.38527C10.6297 4.18079 10.5268 3.99234 10.3846 3.83552C10.273 3.70889 10.1364 3.60674 9.98334 3.53552C9.85192 3.4747 9.71368 3.42988 9.57159 3.40202C9.51508 3.39268 9.45785 3.38842 9.40059 3.38927M9.26409 6.34202H9.18909V4.04402H9.19884C9.35346 4.02623 9.5099 4.05413 9.64884 4.12427C9.75058 4.20551 9.83349 4.30787 9.89184 4.42427C9.9548 4.54677 9.9911 4.68122 9.99834 4.81877C10.0051 4.98377 9.99834 5.11877 9.99834 5.23052C10.0014 5.35924 9.99311 5.48799 9.97359 5.61527C9.95047 5.74594 9.90774 5.87237 9.84684 5.99027C9.77791 6.09988 9.68477 6.19225 9.57459 6.26027C9.48205 6.32011 9.37248 6.34804 9.26259 6.33977M13.0726 3.40352H11.2501V7.00352H12.0211V5.57552H12.9961V4.90652H12.0211V4.07252H13.0711V3.40352"
          fill="#464648"
        />
        <path
          d="M16.3358 15.1911C16.3358 15.1911 18.7268 14.7576 18.7268 15.5744C18.7268 16.3911 17.2455 16.0589 16.3358 15.1911ZM14.568 15.2534C14.1881 15.3373 13.8179 15.4602 13.4633 15.6201L13.7633 14.9451C14.0633 14.2701 14.3745 13.3499 14.3745 13.3499C14.7325 13.9524 15.149 14.5181 15.618 15.0389C15.2643 15.0916 14.9138 15.1637 14.568 15.2549V15.2534ZM13.6215 10.3784C13.6215 9.66664 13.8518 9.47239 14.031 9.47239C14.2103 9.47239 14.412 9.55864 14.4188 10.1766C14.3604 10.7981 14.2302 11.4106 14.031 12.0021C13.7581 11.5055 13.6169 10.9473 13.6208 10.3806L13.6215 10.3784ZM10.1348 18.2654C9.40126 17.8266 11.673 16.4759 12.0848 16.4324C12.0825 16.4331 10.9028 18.7244 10.1348 18.2654ZM19.425 15.6711C19.4175 15.5961 19.35 14.7659 17.8725 14.8011C17.2567 14.7912 16.6411 14.8346 16.0328 14.9309C15.4435 14.3372 14.936 13.6675 14.5238 12.9396C14.7835 12.1892 14.9406 11.4071 14.991 10.6146C14.9693 9.71464 14.754 9.19864 14.064 9.20614C13.374 9.21364 13.2735 9.81739 13.3643 10.7159C13.4532 11.3197 13.6208 11.9092 13.863 12.4694C13.863 12.4694 13.5443 13.4616 13.1228 14.4486C12.7013 15.4356 12.4133 15.9531 12.4133 15.9531C11.6803 16.1917 10.9903 16.5462 10.3695 17.0031C9.75151 17.5784 9.50026 18.0201 9.82576 18.4619C10.1063 18.8429 11.088 18.9291 11.9655 17.7794C12.4318 17.1855 12.8577 16.5611 13.2405 15.9104C13.2405 15.9104 14.5785 15.5436 14.9948 15.4431C15.411 15.3426 15.9143 15.2631 15.9143 15.2631C15.9143 15.2631 17.136 16.4924 18.3143 16.4489C19.4925 16.4054 19.4355 15.7446 19.428 15.6726"
          fill="#DD2025"
        />
        <path
          d="M17.9656 1.55786V5.96261H22.1903L17.9656 1.55786Z"
          fill="#909090"
        />
        <path d="M18.0232 1.5V5.90475H22.2479L18.0232 1.5Z" fill="#F4F4F4" />
        <path
          d="M6.73123 3.34265H5.75098V6.94266H6.52498V5.72916L6.69598 5.7389C6.8614 5.73606 7.02528 5.70642 7.18123 5.65115C7.31794 5.60411 7.44372 5.52987 7.55098 5.43291C7.65928 5.34027 7.74453 5.22369 7.79998 5.09241C7.8752 4.87378 7.90207 4.64143 7.87873 4.41141C7.87404 4.24709 7.84523 4.08435 7.79323 3.92841C7.74588 3.81584 7.67562 3.71436 7.58691 3.63042C7.4982 3.54649 7.39299 3.48195 7.27798 3.4409C7.17808 3.40455 7.07482 3.37817 6.96973 3.36215C6.89055 3.34994 6.81059 3.34342 6.73048 3.34265M6.58873 5.06316H6.52198V3.95316H6.66748C6.73136 3.94855 6.79547 3.95836 6.85505 3.98185C6.91464 4.00535 6.96818 4.04193 7.01173 4.08891C7.10197 4.20967 7.15017 4.35666 7.14898 4.50741C7.14898 4.69191 7.14898 4.85916 6.98248 4.97691C6.86253 5.04288 6.72599 5.07258 6.58948 5.06241M9.34198 3.3329C9.25873 3.3329 9.17773 3.33891 9.12073 3.34116L8.94448 3.34566H8.35948V6.94565H9.04798C9.3111 6.95287 9.57306 6.90827 9.81898 6.81441C10.0169 6.7359 10.1922 6.60934 10.329 6.44616C10.462 6.2815 10.5575 6.08978 10.6087 5.88441C10.6676 5.65181 10.6964 5.41259 10.6942 5.17265C10.7088 4.88927 10.6868 4.6052 10.629 4.32741C10.5741 4.12293 10.4712 3.93447 10.329 3.77766C10.2174 3.65103 10.0808 3.54888 9.92773 3.47766C9.79631 3.41684 9.65807 3.37202 9.51598 3.34416C9.45947 3.33482 9.40224 3.33055 9.34498 3.33141M9.20848 6.28415H9.13348V3.98616H9.14323C9.29785 3.96836 9.45429 3.99626 9.59323 4.06641C9.69497 4.14765 9.77788 4.25 9.83623 4.36641C9.89919 4.48891 9.93549 4.62336 9.94273 4.76091C9.94948 4.92591 9.94273 5.0609 9.94273 5.17265C9.94578 5.30138 9.9375 5.43013 9.91798 5.5574C9.89486 5.68808 9.85213 5.8145 9.79123 5.9324C9.72229 6.04202 9.62916 6.13439 9.51898 6.20241C9.42644 6.26225 9.31687 6.29017 9.20698 6.28191M13.0147 3.34566H11.1922V6.94565H11.9632V5.51765H12.9382V4.84866H11.9632V4.01466H13.0132V3.34566"
          fill="white"
        />
      </svg>
      <div
        style={{
          position: "absolute",
          top: "-9999px",
          left: "-9999px",
        }}
      >
        {/* PDFExport component to handle the PDF rendering */}
        <PDFExport
          ref={pdfExportComponent}
          paperSize="A4"
          margin="1cm"
          fileName={`${getPdfFileName(
            dataItem?.hscodeSearchResult?.hsCode || null
          )}.pdf`}
          author="Dubai Customs"
        >
          {/* Content to be included in the PDF */}
          <div style={{ paddingBottom: "100px" }}>
            <div
              style={{
                paddingBottom: "60px",
              }}
            >
              <img
                src={Logo2}
                alt="logo2"
                style={{ width: "18%", float: "left" }}
              ></img>
              <img
                src={Logo}
                alt="logo"
                style={{ width: "12%", float: "right" }}
              ></img>
            </div>

            {/* Additional details table, like applicable trade agreements, duties, etc. */}
            <div
              className="p-5 mt-5"
              style={{ backgroundColor: "#1b84ff1c", borderRadius: "12px" }}
            >
              <h5>Section</h5>
              <p
                style={{
                  fontSize: "12px",
                  marginBottom: "0px",
                  textTransform: "lowercase",
                }}
              >
                {dataItem?.hscodeSearchResult?.sectionName}
              </p>
            </div>
            <div
              className="p-5 mt-5"
              style={{ backgroundColor: "#1b84ff1c", borderRadius: "12px" }}
            >
              <h5>Heading</h5>
              <p style={{ fontSize: "12px", marginBottom: "0px" }}>
                {dataItem?.hscodeSearchResult?.headingName}
              </p>
            </div>
            <div
              className="p-5 mt-5"
              style={{ backgroundColor: "#eee", borderRadius: "12px" }}
            >
              <h5 style={{ marginBottom: "6.5px" }}>
                {dataItem?.hscodeSearchResult?.hsCode}
              </h5>
              <p style={{ fontSize: "12px", marginBottom: "6.5px" }}>
                {dataItem?.hscodeSearchResult?.hscodeDescription}
              </p>
            </div>
            <div
              className="p-5 mt-5"
              style={{ backgroundColor: "#1b84ff1c", borderRadius: "12px" }}
            >
              <table style={{ width: "100%", fontSize: "12px" }}>
                <tr>
                  <td>
                    Controlled Item{" "}
                    <p style={{ marginBottom: 0 }}>{dataItem?.restricted}</p>
                  </td>
                  <td>
                    Customs Duty{" "}
                    <p style={{ marginBottom: 0 }}>{dataItem?.customs_Duty}</p>
                  </td>
                </tr>
                <tr>
                  <td>
                    Excise Duty{" "}
                    <p style={{ marginBottom: 0 }}>{dataItem?.excise_Duty}</p>
                  </td>
                  <td>
                    Measurement Unit{" "}
                    <p style={{ marginBottom: 0 }}>
                      {dataItem?.measurement_Unit}
                    </p>
                  </td>
                </tr>
                <tr>
                  <td>
                    Applicable Trade Agreements{" "}
                    {countryTrade.map((item: any) => (
                      <p>{`${item.issuingAgency}-(${item.dutyPercentage}%)`}</p>
                    ))}
                    {/* <p>{dataItem?.applicable_Exemptions}</p> */}
                  </td>
                </tr>
              </table>
            </div>
          </div>
          <p
            className="mt-5"
            style={{
              textAlign: "center",
              fontSize: "12px",
            }}
          >
            Dubai Customs is not responsible for the (Al Munasiq) search results
            of the HS Code selected by the client. In order to obtain an
            approved HS code by the Tariff Department, use Dubai Customs service
            for goods classification request.
          </p>
        </PDFExport>
      </div>
    </td>
  );
};

const HSCodeSearchToggles = ({ filter }: FilterState) => {
  // Update data with new information or reset to default
  const updateItem = (id: string, newData: Partial<any>) => {
    const updatedData = data.map((item: any) =>
      item?.hscodeSearchResult?.hsCode === id ? { ...item, ...newData } : item
    );
    setData(updatedData);
    // If cancel is true, reset to default data, otherwise set updated data
  };
  // State to manage the grid data (product list) and loading state
  const [data, setData] = React.useState<Array<Product>>([]);
  const [loader, setLoader] = React.useState<boolean>(true);
  // Styles for the grid wrapper
  const gridClass: React.CSSProperties = {
    width: "100%",
    margin: "0 auto",
    overflowX: "auto",
  };

  const DetailComponent = (props: GridDetailRowProps) => {
    const dataItem = props.dataItem;
    const [options, setOptions] = React.useState([]);
    const promiseOptions = async (inputValue: string) => {
      const value: any = await searchCountries(inputValue);
      // Map the response to format the options for the dropdown
      return value.map((item: any) => ({
        value: item.countryCode,
        label: item.countryName,
      }));
    };
    React.useEffect(() => {
      if (dataItem.hscodeSearchResult.hsCode) {
        promiseOptions(dataItem.hscodeSearchResult.hsCode).then((res) => {
          setOptions(res);
        });
      }
    }, [dataItem.hscodeSearchResult.hsCode]);
    const [countryCode, setCountryCode] = React.useState<any>(null);
    const [countryTrade, setCountryTrade] = React.useState([]);
    const handleCountryChange = (country: any) => {
      setCountryCode(country);
    };
    React.useEffect(() => {
      if (dataItem?.countryCode) {
        searchCountriesTrade(
          dataItem?.countryCode?.value,
          dataItem.hscodeSearchResult.hsCode
        ).then((res) => {
          setCountryTrade(res);
        });
      }
    }, [dataItem?.countryCode]);
    React.useEffect(() => {
      if (countryCode) {
        updateItem(dataItem?.hscodeSearchResult?.hsCode, {
          ...dataItem,
          countryCode: countryCode,
        });
      }
    }, [countryCode]);
    // If dataItem exists, render the detailed view
    if (dataItem) {
      return (
        <section className="d-flex gap-xl-6 gap-lg-4 gap-md-4 gap-4 fs-6 px-12 pl-0 py-6">
          {/* Controlled Item Status */}
          <div className=" d-flex flex-column">
            <p className="mb-0 text-secondary">Controlled Item</p>{" "}
            <span className="text-dark">{dataItem.restricted}</span>
          </div>
          {/* Customs Duty */}
          <div className=" d-flex flex-column ">
            <p className="mb-0 text-xl-nowrap text-lg-wrap">Customs Duty</p>{" "}
            <span className="text-dark">{dataItem.customs_Duty}</span>
          </div>
          {/* Permit Issuing Authorities */}
          <div className=" d-flex flex-column ">
            <p className="mb-0 text-xl-nowrap text-lg-wrap">
              Permit Issuing Authorities
            </p>{" "}
            <span className="text-dark">
              {dataItem.permit_Issuing_Authorities}
            </span>
          </div>
          {/* Excise Duty */}
          <div className=" d-flex flex-column ">
            <p className="mb-0">Excise Duty</p>{" "}
            <span className="text-dark">{dataItem.excise_Duty}</span>
          </div>
          {/* Measurement Unit */}
          <div className=" d-flex flex-column ">
            <p className="mb-0">Measurement Unit</p>{" "}
            <span className="text-dark">{dataItem.measurement_Unit}</span>
          </div>
          {/* Applicable Trade Agreements */}
          <div className=" d-flex flex-column ">
            <p className="mb-0 text-xl-nowrap text-lg-wrap">
              Applicable Trade Agreements
            </p>{" "}
            <Select
              className="form-control-md min-w-300px w-auto"
              noOptionsMessage={() => "Search by HS Code Number or Description"}
              onChange={handleCountryChange}
              options={options}
              defaultValue={dataItem.countryCode}
              styles={customStyles}
              components={{ MenuList: CustomMenuList }}
            />
          </div>
          <div className="d-flex flex-column">
            <p className="mb-0 text-xl-nowrap text-lg-wrap">
              <br />{" "}
            </p>{" "}
            {countryTrade.map((item: any) => (
              <span className="text-dark">
                {`${item.issuingAgency}-(${item.dutyPercentage}%)`}
              </span>
            ))}
          </div>
        </section>
      );
    }
    // If dataItem is not available, render a loading placeholder
    return (
      <div
        style={{
          height: "50px",
          width: "100%",
        }}
      >
        <div
          style={{
            position: "absolute",
            width: "100%",
          }}
        >
          {/* Loading indicator */}
          <div className="k-loading-image" />
        </div>
      </div>
    );
  };

  /**
   * Handles the expansion of grid rows.
   * It toggles the 'expanded' state for the corresponding row.
   *
   * @param {GridExpandChangeEvent} event - Event triggered when a row is expanded or collapsed.
   */

  const expandChange = (event: GridExpandChangeEvent) => {
    const newData = data.map((item: Product, index: number) => {
      if (index === event.dataIndex) {
        // Toggle the expanded state for the clicked row
        item.expanded = !event.dataItem.expanded;
      }
      return item;
    });
    setData(newData);
  };

  /**
   * Fetches data based on the filter and updates the grid state.
   * The loader is displayed while the data is being fetched.
   */
  const getAndSetData = async () => {
    setLoader(true);
    const res: any = await getItems(filter);
    // console.log("res", res);

    setData(res);
    setLoader(false);
  };

  // useEffect hook to fetch data whenever the filter changes
  React.useEffect(() => {
    getAndSetData();
  }, [filter]);
  return (
    <>
      <div className="card" style={gridClass}>
        {loader ? (
          // Loader is displayed while data is being fetched
          <div className="text-center mt-10 mb-10">
            <div
              className="spinner-border"
              style={{ width: "3rem", height: "3rem" }}
              role="status"
            >
              <span className="sr-only">Loading...</span>
            </div>
          </div>
        ) : (
          // KendoReact Grid to display the search results
          <Grid
            data={data}
            detail={DetailComponent}
            expandField="expanded"
            onExpandChange={expandChange}
            resizable={false}
            className="grid-with-border-bottom"
            style={{
              minWidth: "1200px",
              width: "100%",
              paddingLeft: "10px",
              paddingRight: "10px",
            }}
          >
            <GridColumn
              field="hscodeSearchResult.sectionName" // Field to display the section name
              title="Section"
              headerClassName="p-6 border-transparent fw-bold title-custom"
              className="py-6 px-16 border-top fs-6"
            />
            <GridColumn
              field="hscodeSearchResult.headingName" // Field to display the heading name
              title="Heading"
              headerClassName="p-6 border-transparent fw-bold title-custom"
              className="py-6 px-3 border-top fs-6"
            />

            <GridColumn
              field="hscodeSearchResult.hsCode" // Field to display HS code
              title="HSCode"
              headerClassName="p-6 border-transparent fw-bold title-custom"
              cell={(props) => hsCodeDetails(props.dataItem, filter)} // Custom cell for HSCode details
            />
            <GridColumn
              field="downloadPdf" // Field for downloading PDF
              title="Download PDF"
              headerClassName="p-6  border-transparent fw-bold border-bottom title-custom"
              cell={({ dataItem }) => PdfCell(dataItem)} // Custom cell for PDF download button
            />
          </Grid>
        )}
      </div>
    </>
  );
};

export { HSCodeSearchToggles };
