export interface ProductCategory {
  CategoryID?: number;
  measurementUnit?: string;
  country?: string;
}

export interface HsCode {
  code: string;
  dis: string;
  confidence: string;
}

export interface Product {
  id: number;
  heading?: string;
  section?: string;
  hscode: HsCode;
  downloadPdf?: string;
  restricted?: string;
  customsduty?: string;
  authorities?: string;
  exciseduty?: boolean;
  Category?: ProductCategory;
  expanded?: boolean;
  inEdit?: boolean | string;
  locked?: boolean;
}

export interface dataItem {
  applicable_Exemptions: string;
  countries_Free_Trade: string;
  customs_Duty: string;
  excise_Duty: string;
  expanded: boolean;
  hscodeSearchResult: {
    headingName: string;
    hsCode: string;
    sectionName: string;
  };
  measurement_Unit: string;
  permit_Issuing_Authorities: string;
  restricted: string;
}

// asdfghjknbvcxasfg

export interface FilterProps {
  searchCode: string | null;
  searchDescription: string;
}

// export interface HSCodeSearchResult {
//   sectionName: string;
//   headingName: string;
//   hsCode: string;
//   hscodeDescription: string;
// }

// // Interface for the response object returned by the API
// export interface ResponseObject {
//   hscodeSearchResult: HSCodeSearchResult;
//   applicable_Exemptions: string[];
//   countries_Free_Trade: string[];
//   customs_Duty: string;
//   excise_Duty: string;
//   measurement_Unit: string;
//   permit_Issuing_Authorities: string[];
//   restricted: boolean;
// }

export interface HSCodeSearchResult {
  chapterName: string | null;
  chapterNumber: number;
  commodityName: string | null;
  confidenceScore: number;
  correctHSCode: boolean;
  createdBy: string;
  createdDate: number; // Timestamp
  headingName: string;
  headingNumber: number;
  hsCode: string;
  hsCodeResultKey: string;
  hscodeDescription: string;
  hscodeSearchRatingComment: string | null;
  hscodeSearchRatingTypeId: string | null;
  hscodeSearchResultId: number;
  isActive: number;
  isFavourite: number;
  modifiedBy: string;
  modifiedDate: number; // Timestamp
  rank: number;
  sectionName: string;
  sectionNumber: number;
  version: number;
}

export interface HSCodeAdditionalData {
  applicable_Exemptions: string;
  countries_Free_Trade: string;
  customs_Duty: string;
  excise_Duty: string;
  measurement_Unit: string;
  permit_Issuing_Authorities: string;
  restricted: string;
}

export interface HSCodeSearchResponse {
  hscodeSearchResult: HSCodeSearchResult;
  applicable_Exemptions: string;
  countries_Free_Trade: string;
  customs_Duty: string;
  excise_Duty: string;
  measurement_Unit: string;
  permit_Issuing_Authorities: string;
  restricted: string;
}

// For the response from getItems
