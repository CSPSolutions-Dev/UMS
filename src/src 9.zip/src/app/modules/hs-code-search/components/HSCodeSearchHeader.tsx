import React, { useState } from "react";
import { FilterProps } from "./interfaces";

interface SearchHeaderProps {
  setFilter: React.Dispatch<React.SetStateAction<FilterProps>>;
  filter: FilterProps;
}

const SearchHeader: React.FC<SearchHeaderProps> = ({ setFilter, filter }) => {
  // Local state for managing filter inputs within the component
  const [filterState, setFilterState] = useState<FilterProps>({
    ...filter,
  });
  // State to handle validation error for HS Code input
  const [error, setError] = useState<string>("");

  // State to handle validation error for Search Description input
  const [errorSearch, setErrorSearch] = useState<string>("");

  // Handler for changing the HS Code input value
  const handleCodeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    if ((value.length <= 15 && /^\d*$/.test(value)) || value === "") {
      if (value.length > 0 && value.length < 4) {
        setErrorSearch("HS Code must be at least 4 digits.");
      } else {
        setErrorSearch("");
      }
      setFilterState({
        ...filterState,
        searchCode: value ? value : null,
      });
    }
  };

  // Handler for changing the Search Description input value
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    const wordCount = value.trim().split(/\s+/).length;
    const characterCount = value.length;
    if (characterCount > 1000) {
      setError("Please enter no more than 1000 characters.");
    } else if (wordCount < 0 && value != "") {
      setError("Please enter at least one word.");
    } else {
      setError("");
    }
    setFilterState({
      ...filterState,
      searchDescription: value,
    });
  };

  // Handler for applying the filter changes
  const handleFilterChange = () => {
    setFilter({ ...filterState });
  };

  // Handler for resetting the filter to its initial state
  const handleReset = () => {
    setFilterState({
      searchCode: null,
      searchDescription: "",
    });
    setFilter({
      searchCode: null,
      searchDescription: "",
    });
    setError("");
  };

  // Handler for pressing the "Enter" key to trigger the search if there are no validation errors
  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key == "Enter" && !error) {
      handleFilterChange();
    }
  };

  return (
    <>
      <div className="col-12 col-md-3 mb-5">
        <h2>HS Code Search</h2>
      </div>

      <div className="card mb-3 mb-xl-4">
        <div className="card-body pt-12 pb-18">
          <div className="row gap-2 ">
            <div className=" col-lg-4 col-md-6 col-sm-12 mt-sm-3 mt-3">
              <label className="form-label">
                HS Code Search{" "}
                <i
                  className="ki-outline  ki-question-2 fs-1x"
                  style={{ fontSize: "14px", fontWeight: "bolder" }}
                  title="Search the HS Code database to find the HS Code matching your input"
                ></i>
              </label>
              {/* Input for HS Code */}
              <input
                onKeyDown={handleKeyPress}
                value={
                  filterState.searchCode != null ? filterState.searchCode : ""
                }
                onChange={handleCodeChange}
                type="text"
                className="form-control fs-6 fw-normal"
                placeholder="Search by HS Code"
              />
              {/* Display validation error for HS Code */}
              <label className="form-label">
                {errorSearch && (
                  <p className="m-0" style={{ color: "red" }}>
                    {errorSearch}
                  </p>
                )}
              </label>
            </div>
            {/* Search by Description Input */}
            <div className=" col-lg-4 col-md-6 col-sm-12 mt-sm-3 mt-3">
              <label className="form-label">
                Search by Description{" "}
                <i
                  className="ki-outline  ki-question-2 fs-1x"
                  style={{ fontSize: "14px", fontWeight: "bolder" }}
                  title="Get top HS Code matches or predictions by communicating with the AI Model."
                ></i>
              </label>
              {/* Input for description */}
              <input
                onKeyDown={handleKeyPress}
                type="text"
                value={filterState.searchDescription}
                onChange={handleChange}
                className="form-control form-control-white"
                placeholder="Search by Description"
              />
              {/* Display validation error for description */}
              <label className="form-label">
                {error && (
                  <p className="m-0" style={{ color: "red" }}>
                    {error}
                  </p>
                )}
              </label>
            </div>
            {/* Search and Reset Buttons */}
            <div className="col-lg-2 col-md-6 col-sm-12  d-flex gap-3  mt-sm-4 mt-4 align-items-center">
              <div className="d-grid gap-2">
                <button
                  disabled={
                    error ||
                    errorSearch ||
                    (filterState.searchDescription == "" &&
                      filterState.searchCode == null)
                      ? true
                      : false
                  }
                  onClick={handleFilterChange}
                  className="btn btn-primary"
                >
                  Search
                </button>
              </div>

              <div className="d-grid gap-2">
                <button
                  onClick={handleReset}
                  className="btn btn-outline btn-outline-solid btn-outline-primary btn-active-light-primary"
                >
                  Reset
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export { SearchHeader };
