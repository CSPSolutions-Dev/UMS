import React from "react";
import { Content } from "../../../_metronic/layout/components/content";
import { HSCodeSettingsToggles } from "./components/HSCodeSettingsToggles";

// The HSCodeSettingPage component is a functional component
const HSCodeSettingPage: React.FC = () => {
  return (
    <>
      {/* Wrapper for the page content */}
      <Content>
        {/* A full-width column for the HSCodeSettingsToggles component */}
        <div className="col-xl-12">
          {/* Rendering the HSCodeSettingsToggles component */}
          <HSCodeSettingsToggles />
        </div>
      </Content>
    </>
  );
};

export default HSCodeSettingPage;
