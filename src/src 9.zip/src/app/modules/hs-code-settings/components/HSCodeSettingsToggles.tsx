import React, { useEffect, useState } from "react";
import { HscodeSettingControllerApi } from "../../../../api";
import settingsJSON from "./codeSettingData.json";
import { AxiosResponse } from "axios";

// Interface for the structure of the setting data
interface SettingData {
  hscodeSettingId?: number | undefined;
  enableChapterNumberDescription?: boolean;
  enableHeadingNumberDescription?: boolean;
  enableSubHeadingNumberDescription?: boolean;
  enableHscodeDescription?: boolean;
  enablePercentageCustomsDuty?: boolean;
  enableUnitMeasurement?: boolean;
  enablePercentageExciseDuty?: boolean;
  enableListPermitAuthorities?: boolean;
  enableListApplicableExemptions?: boolean;
  enableListCountriesFreeTrade?: boolean;
  [key: string]: boolean | number | undefined;
}

// Interface to map each setting to a key and title
interface Setting {
  key: string;
  title: string;
}

const HSCodeSettingsToggles: React.FC = () => {
  const API = new HscodeSettingControllerApi(); // Initializing the API
  const [settingData, setSettingData] = useState<SettingData | null>(null);
  const [type, setType] = useState(1);
  const [loader, setLoader] = useState<boolean>(true);
  // Function to fetch data based on the user type
  const getData = async () => {
    try {
      setLoader(true); // Show loader while data is being fetched
      const response: AxiosResponse<any> = await API.getHscodeSettingByUserType(
        type
      );
      const { data } = response;

      // Check if data exists, then set the relevant values in the settingData state
      if (data && data.responseObject?.[0][0]) {
        const {
          enableChapterNumberDescription,
          enableHeadingNumberDescription,
          enableSubHeadingNumberDescription,
          enableHscodeDescription,
          enablePercentageCustomsDuty,
          enableUnitMeasurement,
          enablePercentageExciseDuty,
          enableListPermitAuthorities,
          enableListApplicableExemptions,
          enableListCountriesFreeTrade,
          hscodeSettingId,
        } = data.responseObject[0][0]; // Destructure response object
        setSettingData({
          hscodeSettingId,
          enableChapterNumberDescription,
          enableHeadingNumberDescription,
          enableSubHeadingNumberDescription,
          enableHscodeDescription,
          enablePercentageCustomsDuty,
          enableUnitMeasurement,
          enablePercentageExciseDuty,
          enableListPermitAuthorities,
          enableListApplicableExemptions,
          enableListCountriesFreeTrade,
        });
        setLoader(false); // Hide loader after data is set
      } else {
        setSettingData(null);
        setLoader(false);
      }
    } catch (error) {
      setSettingData(null);
      setLoader(false);
    }
  };

  // useEffect to fetch data when the type (Guest/Authenticated) changes
  useEffect(() => {
    getData();
  }, [type]);

  // Handle toggle changes by updating the local state with the new value
  const handleToggleChange = async (key: string, checked: boolean) => {
    const hscodeSettingModelRequest = {
      ...settingData,
      [key]: checked, // Update the specific key (toggle) in the setting data
    };
    setSettingData({ ...hscodeSettingModelRequest });
  };

  // Function to save settings via the API
  const saveSetting = async () => {
    setLoader(true);
    try {
      if (settingData) {
        await API.updateHscodeSettingModel(type, settingData);
      }
      await getData();
    } catch (error) {
      await getData();
    }
  };
  return (
    <>
      {/* Main card container */}
      <div className="card mb-5 mb-xl-10">
        <div className="card-body p-0">
          <div className="d-flex flex-wrap flex-sm-nowrap">
            <div className="flex-grow-1">
              <div className="d-flex flex-wrap flex-stack">
                <div className="d-flex flex-column flex-grow-1">
                  {/* Header with user type selection and save button */}
                  <div className="d-flex flex-wrap flex-stack mb-6 items-center pt-6 ps-6 pe-6">
                    <span className="fs-5 fw-normal mx-1 mb-md-0 mb-sm-0 mb-3 ">
                      <b>Enable</b> the following attributes in HS Code User{" "}
                      <b>Report</b>
                    </span>

                    <div className="d-flex gap-3">
                      <select
                        className="form-select form-select-white form-select-sm"
                        data-kt-select2="true"
                        data-placeholder="Select option"
                        data-allow-clear="true"
                        defaultValue={1}
                        onChange={(event) => {
                          const value = event.target.value as unknown as number;
                          setType(value); // Set the selected user type
                        }}
                      >
                        <option value={1}>Guest User</option>
                        <option value={2}>Registered User</option>
                      </select>

                      {/* Save button only appears when settingData exists */}
                      {settingData && (
                        <button
                          title="Save"
                          className="k-button k-button-md k-rounded-md k-button-solid k-button-solid-primary w-80px"
                          onClick={() => {
                            saveSetting();
                          }}
                        >
                          Save
                        </button>
                      )}
                    </div>
                  </div>
                  {/* Loader while fetching or saving data */}
                  {loader ? (
                    <div className="text-center mt-10 mb-10">
                      <div
                        className="spinner-border"
                        style={{ width: "3rem", height: "3rem" }}
                        role="status"
                      >
                        <span className="sr-only">Loading...</span>
                      </div>
                    </div>
                  ) : (
                    // Display settings toggles when data is available
                    <div className="container-fluid">
                      <div className="row">
                        {settingData &&
                          settingsJSON.map(
                            (setting: Setting, index: number) =>
                              setting.key && (
                                <div
                                  className="col-md-6 col-12 border p-6"
                                  key={"settings" + index}
                                >
                                  {/* Toggle switch for each setting */}
                                  <div className="d-flex gap-3 justify-content-between align-items-center">
                                    <div className="fs-5">{setting.title}</div>

                                    <div className="form-check form-switch form-switch form-check-custom form-check-solid">
                                      <input
                                        className="form-check-input"
                                        type="checkbox"
                                        name={setting.key}
                                        checked={!!settingData[setting.key]} // Convert value to boolean
                                        onChange={(e) =>
                                          handleToggleChange(
                                            setting.key,
                                            e.target.checked
                                          )
                                        }
                                      />
                                    </div>
                                  </div>
                                </div>
                              )
                          )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export { HSCodeSettingsToggles };
