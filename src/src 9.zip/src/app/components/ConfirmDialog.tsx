import { Dialog, DialogActionsBar } from "@progress/kendo-react-dialogs";
import { Button } from "@progress/kendo-react-buttons";

interface ConfirmDialogProps {
  showModal: boolean;
  onConfirm: () => void;
  onClose: () => void;
  title: string;
  message: string;
  ButtonText: string;
}

/**
 * ConfirmDialog component renders a confirmation dialog box with customizable title, message, and button text.
 * It displays two buttons - one for confirming an action and another for canceling it.
 *
 * @param showModal - Whether to show or hide the modal
 * @param onConfirm - Handler for the confirm button
 * @param onClose - Handler for the close/cancel button
 * @param title - Title of the dialog
 * @param message - Message displayed inside the dialog
 * @param ButtonText - Text for the confirm button
 */

const ConfirmDialog: React.FC<ConfirmDialogProps> = ({
  showModal,
  onConfirm,
  onClose,
  title,
  message,
  ButtonText,
}) => {
  return (
    <>
      {showModal && ( // Only render the dialog when showModal is true
        <Dialog title={title} onClose={onClose} width={350}>
          <div>{message}</div>
          <DialogActionsBar>
            <Button onClick={onConfirm}>{ButtonText}</Button>
            <Button onClick={onClose}>Cancel</Button>
          </DialogActionsBar>
        </Dialog>
      )}
    </>
  );
};

export { ConfirmDialog };
