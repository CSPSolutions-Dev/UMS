import React, { useEffect, useRef, useState } from "react";
import { DateRangePicker } from "react-date-range";
import { defaultStaticRanges } from "./defaultRanges";
import { format } from "date-fns";
import "react-date-range/dist/styles.css";
import "react-date-range/dist/theme/default.css";
import PropTypes from "prop-types";
import { RangeKeyDict } from "react-date-range";
import { enUS } from "date-fns/locale";

// Interface for DateRange type
interface DateRange {
  startDate: Date;
  endDate: Date;
  key: string;
}

// Interface for DateRangeSelector component props
interface DateRangeSelectorProps {
  ranges?: typeof defaultStaticRanges;
  onChange?: (ranges: { selection: DateRange }) => void;
  onSubmit?: (selectedDateRange: DateRange) => void;
}

// DateRangeSelector component definition
const DateRangeSelector: React.FC<DateRangeSelectorProps> = ({
  ranges,
  onChange,
  onSubmit,
  ...rest
}) => {
  const [selectedDateRange, setSelectedDateRange] = useState<DateRange>({
    startDate: new Date(ranges.startDate), // Initialize with startDate from ranges
    endDate: new Date(ranges.endDate), // Initialize with endDate from ranges
    key: "selection",
  });
  // State to control the visibility of the date range picker
  const [show, setShow] = useState(false);
  // Ref to detect clicks outside the date picker to close it
  const dateRangeRef = useRef<HTMLDivElement>(null);

  // useEffect to handle click outside the date picker and close it
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        dateRangeRef.current &&
        !dateRangeRef.current.contains(event.target as Node)
      ) {
        setShow(false);
      }
    }
    // Add event listener for outside clicks
    document.addEventListener("mousedown", handleClickOutside);
    // Cleanup the event listener on component unmount
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);
  // Function to format date for display in input field
  function formatDateDisplay(date: Date, defaultText: string = ""): string {
    if (!date) return defaultText; // If date is not valid, return default text
    return format(date, "MM/dd/yyyy");
  }

  // Handler when a date range is selected
  const handleSelect = (ranges: RangeKeyDict) => {
    const selection = ranges.selection as DateRange; // Extract selected range
    setSelectedDateRange(selection); // Update state with selected range
    if (onChange) {
      onChange({ selection }); // Trigger onChange callback if provided
    }
  };
  // Handler for when the "Done" button is clicked
  const handleDone = () => {
    if (onSubmit) {
      onSubmit(selectedDateRange);
    }
    setShow(false);
  };
  // useEffect to update the selected date range when the `ranges` prop changes
  useEffect(() => {
    setSelectedDateRange({
      startDate: new Date(ranges.startDate),
      endDate: new Date(ranges.endDate),
      key: "selection",
    });
  }, [ranges]);
  return (
    <React.Fragment>
      {/* Wrapper for date range picker */}
      <div ref={dateRangeRef}>
        <div className="text-right position-relative rdr-buttons-position mr-3">
          <input
            type="text"
            className="form-control"
            readOnly
            onClick={() => setShow(true)} // Show the date range picker when clicked
            value={`${formatDateDisplay(
              ranges.startDate
            )} - ${formatDateDisplay(ranges.endDate)}`}
          />
        </div>

        {/* Date range picker component */}
        {show && (
          <div
            className="responsive-datepicker position-absolute rangeDate m-3 p-3 bg-white border"
            style={{
              zIndex: 9999999, // High z-index to make sure it's on top of other elements
            }}
          >
            <DateRangePicker
              onChange={handleSelect}
              moveRangeOnFirstSelection={false}
              months={2}
              ranges={[selectedDateRange]}
              staticRanges={defaultStaticRanges}
              direction="horizontal"
              locale={enUS}
            />
            {/* Button to confirm the selected date range */}
            <div className="text-end">
              <button
                className="btn btn-primary text-normal"
                style={{
                  padding: "5px 15px 5px 15px",
                  marginRight: "10px",
                }}
                onClick={handleDone} // Trigger handleDone on click
              >
                Done
              </button>
            </div>
          </div>
        )}
      </div>
    </React.Fragment>
  );
};

DateRangeSelector.propTypes = {
  onSubmit: PropTypes.func, // onSubmit callback should be a function
};

export default DateRangeSelector;
