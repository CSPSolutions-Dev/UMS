import {
  addDays,
  endOfDay,
  startOfDay,
  startOfMonth,
  endOfMonth,
  addMonths,
  startOfWeek,
  endOfWeek,
  isSameDay,
  startOfYear,
  endOfYear,
  addYears,
  subMonths,
} from "date-fns";

// Defined date ranges based on current date or calculations using date-fns functions.
const defineds = {
  startOfWeek: startOfWeek(new Date()),
  endOfWeek: endOfWeek(new Date()),
  startOfLastWeek: startOfWeek(addDays(new Date(), -7)),
  endOfLastWeek: endOfWeek(addDays(new Date(), -7)),
  startOfToday: startOfDay(new Date()),
  endOfToday: endOfDay(new Date()),
  startOfYesterday: startOfDay(addDays(new Date(), -1)),
  endOfYesterday: endOfDay(addDays(new Date(), -1)),
  startOfLast30Days: startOfDay(addDays(new Date(), -30)),
  endOfLast30Days: endOfDay(new Date()),
  startOfMonth: startOfMonth(new Date()),
  endOfMonth: endOfMonth(new Date()),
  startOfLastMonth: startOfMonth(addMonths(new Date(), -1)),
  endOfLastMonth: endOfMonth(addMonths(new Date(), -1)),
  startOfYear: startOfYear(new Date()),
  endOfYear: endOfYear(new Date()),
  startOfLastYear: startOfYear(addYears(new Date(), -1)),
  endOfLastYear: endOfYear(addYears(new Date(), -1)),
  startOfLast3Months: startOfMonth(subMonths(new Date(), 3)),
  endOfLast3Months: endOfMonth(subMonths(new Date(), 1)),
};

interface Range {
  startDate: number | Date;
  endDate: number | Date;
}

// Handler to determine if a range is selected (based on startDate and endDate comparison).
const staticRangeHandler = {
  range: {} as () => Range, // Default range function, to be replaced by actual ranges.
  isSelected(range: Range) {
    const definedRange = this.range();
    return (
      isSameDay(range.startDate, definedRange.startDate) &&
      isSameDay(range.endDate, definedRange.endDate)
    );
  },
};

interface StaticRange {
  label: string;
  range: () => Range;
}

// Utility function to create an array of static ranges, merging the handler with range definitions.
export function createStaticRanges(ranges: StaticRange[]) {
  return ranges.map((range) => ({ ...staticRangeHandler, ...range }));
}

// Predefined static date ranges to be used (e.g., Today, Yesterday, Last 30 Days, etc.).
export const defaultStaticRanges: any = createStaticRanges([
  {
    label: "Today",
    range: () => ({
      startDate: defineds.startOfToday,
      endDate: defineds.endOfToday,
    }),
  },
  {
    label: "Yesterday",
    range: () => ({
      startDate: defineds.startOfYesterday,
      endDate: defineds.endOfYesterday,
    }),
  },
  {
    label: "This Week",
    range: () => ({
      startDate: defineds.startOfWeek,
      endDate: defineds.endOfWeek,
    }),
  },
  {
    label: "Last 30 Days",
    range: () => ({
      startDate: defineds.startOfLast30Days,
      endDate: defineds.endOfLast30Days,
    }),
  },
  {
    label: "Last Week",
    range: () => ({
      startDate: defineds.startOfLastWeek,
      endDate: defineds.endOfLastWeek,
    }),
  },
  {
    label: "This Month",
    range: () => ({
      startDate: defineds.startOfMonth,
      endDate: defineds.endOfMonth,
    }),
  },
  {
    label: "Last Month",
    range: () => ({
      startDate: defineds.startOfLastMonth,
      endDate: defineds.endOfLastMonth,
    }),
  },
  {
    label: "Last 3 Months",
    range: () => ({
      startDate: defineds.startOfLast3Months,
      endDate: defineds.endOfLast3Months,
    }),
  },
  {
    label: "This Year",
    range: () => ({
      startDate: defineds.startOfYear,
      endDate: defineds.endOfYear,
    }),
  },
  {
    label: "Last Years",
    range: () => ({
      startDate: defineds.startOfLastYear,
      endDate: defineds.endOfLastYear,
    }),
  },
]);

interface InputRange {
  label: string;
  range: (value: string) => Range; // Function to define a range based on an input value
  getCurrentValue: (range: Range) => string | number | "-" | "∞"; // Function to get the current value based on the range
}

// Placeholder for input ranges (e.g., for custom input-based date ranges).
export const defaultInputRanges: InputRange[] = [];
