export const generateSecureRandomNumber = () => {
  const array = new Uint32Array(1);
  window.crypto.getRandomValues(array);
  return array[0] % 100; // Generates a number between 0 and 99
};

export const generateSecureRandomNumberInRange = (min: number, max: number) => {
  const range = max - min + 1;
  const array = new Uint32Array(1);
  window.crypto.getRandomValues(array);
  const secureRandomNumber = array[0] / (0xffffffff + 1); // Normalize to 0-1
  return Math.floor(secureRandomNumber * range) + min;
};
