import * as React from "react";
import { Dialog, DialogActionsBar } from "@progress/kendo-react-dialogs";
import { Button } from "@progress/kendo-react-buttons";

/**
 * WorkFlowCommandCell component represents action buttons (Edit, Add, Update, Delete, etc.)
 * within a KendoReact Grid cell. It handles item addition, updating, discarding,
 * and deletion operations with confirmation dialogs.
 *
 * @param props - Contains dataItem (row data), editField, and action handlers for the row (edit, add, update, remove, discard, cancel).
 */

export const WorkFlowCommandCell = (props: any) => {
  const { dataItem } = props; // Extracts the dataItem from props, representing the current row
  const inEdit = dataItem[props.editField]; // Determines if the row is currently in edit mode
  const isNewItem =
    typeof dataItem?.classificationWorkflowSettingId == "number" ? false : true;
  const [visible, setVisible] = React.useState(false);

  // Function to handle data deletion
  const onDeleteData = () => {
    props.remove(props.dataItem);
    setVisible(!visible);
  };
  // Function to toggle the visibility of the delete confirmation dialog
  const toggleDialog = () => {
    setVisible(!visible); // Sets dialog visibility state
  };
  return (
    <>
      {props.dataItem.classificationWorkflowTypeId && ( // Conditionally render the cell only if classificationWorkflowTypeId exists
        <td className="k-command-cell border-top">
          <Button
            themeColor={"primary"}
            disabled={
              props.dataItem.classificationWorkflowTypeId
                .classificationWorkflowTypeId && props.dataItem?.appRole?.roleId
                ? false
                : true
            } // Disables the button if certain conditions are not met
            onClick={() =>
              inEdit
                ? isNewItem
                  ? props.add(dataItem)
                  : props.update(dataItem)
                : props.edit(dataItem)
            }
          >
            {inEdit ? (isNewItem ? "Add" : "Update") : "Edit"}{" "}
            {/* Changes the button label based on edit state and whether it's a new item */}
          </Button>
          <Button
            themeColor={"primary"}
            onClick={() =>
              inEdit
                ? isNewItem
                  ? props.discard(dataItem)
                  : props.cancel(dataItem)
                : toggleDialog()
            }
          >
            {inEdit ? (isNewItem ? "Discard" : "Cancel") : "Remove"}{" "}
            {/* Changes the button label based on edit state */}
          </Button>
          {visible && ( // Conditionally renders the delete confirmation dialog if the visible state is true
            <Dialog title={"Delete Data"} onClose={toggleDialog} width={350}>
              <div>Are you sure you want to delete item ?</div>
              <DialogActionsBar>
                <Button onClick={onDeleteData}>Delete</Button>
                <Button onClick={toggleDialog}>Cancel</Button>
              </DialogActionsBar>
            </Dialog>
          )}
        </td>
      )}
    </>
  );
};
