import * as React from "react";
import { Dialog, DialogActionsBar } from "@progress/kendo-react-dialogs";
import { Button } from "@progress/kendo-react-buttons";

/**
 * CommandCell component handles the actions for a row in a Kendo Grid.
 * It provides buttons for editing, adding, updating, and removing rows.
 *
 * @param props - The properties passed to the component, including row data and command handlers.
 */
export const CommandCell = (props: any) => {
  const { dataItem } = props;
  const inEdit = dataItem[props.editField]; // Checks if the row is currently in edit mode
  const isNewItem =
    typeof dataItem?.globalSettingsId == "number" ? false : true;

  const [visible, setVisible] = React.useState(false);

  /**
   * Handles the deletion of the data item and closes the dialog.
   */
  const onDeleteData = () => {
    props.remove(props.dataItem);
    setVisible(!visible);
  };

  /**
   * Toggles the visibility of the delete confirmation dialog.
   */
  const toggleDialog = () => {
    setVisible(!visible);
  };
  return (
    <td className="k-command-cell border-bottom">
      {/* Button to handle Add, Update, or Edit operations based on the row's state */}
      <Button
        themeColor={"primary"}
        disabled={
          // Disables the button if the necessary fields (settingsKeyName and settingsKeyValue) are not filled
          props.dataItem.settingsKeyName && props.dataItem.settingsKeyValue
            ? false
            : true
        }
        onClick={() =>
          // If in edit mode, either add or update the item based on whether it's a new item or existing one
          inEdit
            ? isNewItem
              ? props.add(dataItem)
              : props.update(dataItem)
            : props.edit(dataItem)
        }
      >
        {/* Button text changes based on whether the row is in edit mode and if it's a new or existing item */}
        {inEdit ? (isNewItem ? "Add" : "Update") : "Edit"}
      </Button>

      {/* Button to handle Discard, Cancel, or Remove actions */}
      <Button
        themeColor={"primary"}
        onClick={() =>
          inEdit
            ? isNewItem
              ? props.discard(dataItem)
              : props.cancel(dataItem)
            : toggleDialog()
        }
      >
        {/* Button text changes based on whether the row is in edit mode and if it's a new or existing item */}
        {inEdit ? (isNewItem ? "Discard" : "Cancel") : "Remove"}
      </Button>

      {/* Delete confirmation dialog that appears when the Remove button is clicked */}
      {visible && (
        <Dialog title={"Delete Data"} onClose={toggleDialog} width={350}>
          {/* Confirmation message */}
          <div>Are you sure you want to delete item ?</div>{" "}
          <DialogActionsBar>
            <Button onClick={onDeleteData}>Delete</Button>
            <Button onClick={toggleDialog}>Cancel</Button>
          </DialogActionsBar>
        </Dialog>
      )}
    </td>
  );
};
