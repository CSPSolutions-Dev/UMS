import React from "react";

interface PagerProps {
  totalPage: number;
  currentPage: number;
  onPageChange: (pageNumber: number) => void;
  enablePerPage?: boolean;
  itemsPerPage?: number;
  setItemsPerPage?: (itemsPerPage: number) => void | undefined;
}

const PagerComponent: React.FC<PagerProps> = ({
  totalPage,
  currentPage,
  onPageChange,
  enablePerPage = false,
  itemsPerPage,
  setItemsPerPage,
}) => {
  // Handles page click events and triggers the onPageChange callback with the selected page number.
  const handlePageClick = (pageNumber: number) => {
    onPageChange(pageNumber);
  };

  // Handles the change event when the user selects a different number of items per page.
  const handleItemsPerPageChange = (
    event: React.ChangeEvent<HTMLSelectElement>
  ) => {
    if (setItemsPerPage) {
      setItemsPerPage(Number(event.target.value)); // Updates items per page using the callback
    }
  };

  // Generates an array of page numbers to be displayed based on the current page and total pages.
  const getPageNumbers = () => {
    const maxPages = 5;
    let startPage = Math.max(1, currentPage - Math.floor(maxPages / 2));
    const endPage = Math.min(totalPage, startPage + maxPages - 1);

    // Adjust startPage if the number of pages is less than maxPages
    if (endPage - startPage + 1 < maxPages) {
      startPage = Math.max(1, endPage - maxPages + 1);
    }

    // Return an array of page numbers from startPage to endPage
    return Array.from(
      { length: endPage - startPage + 1 },
      (_, i) => i + startPage
    );
  };

  return (
    <React.Fragment>
      <div className="d-flex flex-stack flex-wrap pt-4">
        <div className="d-flex gap-4 align-items-center">
          {/* Display the current page number and total pages */}
          <div className="fs-5 fw-light" style={{ color: "#ADA7A7" }}>
            Showing Results :{" "}
            <span className="fw-normal" style={{ color: "#000000" }}>
              {`${currentPage} out of ${totalPage}`}
            </span>
          </div>
          {/* Conditional rendering of the items-per-page selector based on the enablePerPage flag */}
          {enablePerPage && (
            <div className="items-per-page fs-5  p-1 bg-secondary border border-secondary rounded">
              <select
                className="border border-secondary rounded"
                id="itemsPerPageSelect"
                value={itemsPerPage} // The current items per page value
                onChange={handleItemsPerPageChange} // Handle when a different number of items per page is selected
              >
                <option value={10}>10</option>
                <option value={20}>20</option>
                <option value={50}>50</option>
                <option value={100}>100</option>
              </select>
            </div>
          )}
        </div>

        {/* Pagination controls */}
        <ul className="pagination">
          {/* Previous page button - disabled if on the first page */}
          <li
            className={`page-item previous ${
              currentPage === 1 ? "disabled" : "" // Disable if on the first page
            }`}
          >
            <a
              href="#"
              className="page-link"
              onClick={() => handlePageClick(currentPage - 1)} // Go to the previous page
            >
              <i className="previous"></i>
            </a>
          </li>

          {/* Generate page number links dynamically */}
          {getPageNumbers().map((pageNumber) => (
            <li
              key={pageNumber}
              className={`page-item ${
                currentPage === pageNumber ? "active" : "" // Highlight the active page
              }`}
            >
              <a
                href="#"
                className="page-link"
                onClick={() => handlePageClick(pageNumber)} // Go to the clicked page
              >
                {pageNumber}
              </a>
            </li>
          ))}
          {/* Next page button - disabled if on the last page */}
          <li
            className={`page-item next ${
              currentPage === totalPage ? "disabled" : "" // Disable if on the last page
            }`}
          >
            <a
              href="#"
              className="page-link"
              onClick={() => handlePageClick(currentPage + 1)} // Go to the next page
            >
              <i className="next"></i>
            </a>
          </li>
        </ul>
      </div>
    </React.Fragment>
  );
};

export default PagerComponent;
