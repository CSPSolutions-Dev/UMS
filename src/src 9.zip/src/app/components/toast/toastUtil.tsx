import { Bounce, toast } from "react-toastify";

/**
 * Displays a toast notification based on the type (success or error).
 *
 * @param type - The type of toast notification, either "success" or "error".
 * @param message - The message to display in the toast.
 */
export const showToast = (type: string, message: string) => {
  // If the type is "success", display a success toast
  if (type === "success") {
    toast.success(message, {
      position: "top-right", // Position the toast at the top-right corner of the screen
      autoClose: 1000, // Automatically close the toast after 1 second
      hideProgressBar: false, // Show the progress bar at the bottom of the toast
      closeOnClick: true, // Allow the user to close the toast by clicking on it
      pauseOnHover: true, // Pause auto-closing when hovering over the toast
      draggable: false, // Disable dragging the toast around the screen
      progress: undefined, // Use default progress bar behavior
      theme: "light", // Set the theme to light
      transition: Bounce, // Use the bounce animation for the toast's appearance and dismissal
    });
  } else {
    // If the type is not "success", assume "error" and display an error toast
    toast.error(message, {
      position: "top-right", // Position the toast at the top-right corner
      autoClose: 1000, // Automatically close the toast after 1 second
      hideProgressBar: false, // Show the progress bar at the bottom of the toast
      closeOnClick: true, // Allow the user to close the toast by clicking on it
      pauseOnHover: true, // Pause auto-closing when hovering over the toast
      draggable: false, // Disable dragging the toast around the screen
      progress: undefined, // Use default progress bar behavior
      theme: "light", // Set the theme to light
      transition: Bounce, // Use the bounce animation for the toast's appearance and dismissal
    });
  }
};
