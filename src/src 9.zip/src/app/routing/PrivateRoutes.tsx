import { lazy, FC, Suspense } from "react";
import { Route, Routes, Navigate } from "react-router-dom";
import { MasterLayout } from "../../_metronic/layout/MasterLayout";
import TopBarProgress from "react-topbar-progress-indicator";
import { getCSSVariableValue } from "../../_metronic/assets/ts/_utils";
import { WithChildren } from "../../_metronic/helpers";
import { useAuth } from "../modules/auth";
import { DEFAULT_ROUTES } from "../constant";
import { getRandomValues } from "crypto";

// Component to handle private routes and lazy-loaded page components
const PrivateRoutes = () => {
  // Lazy-loaded components for different pages
  const AccountPage = lazy(() => import("../modules/accounts/AccountPage"));
  const SettingsPage = lazy(() => import("../modules/settings/SettingsPage"));
  const TrainingPage = lazy(() => import("../modules/training/TrainingPage"));
  const DashboardPage = lazy(
    () => import("../modules/dashboard/DashboardPage")
  );
  const HSCodeSettingsPage = lazy(
    () => import("../modules/hs-code-settings/HSCodeSettingsPage")
  );
  const ErrorLogPage = lazy(() => import("../modules/error-log/ErrorLogPage"));
  const HSCodeSearchPage = lazy(
    () => import("../modules/hs-code-search/HSCodeSearchPage")
  );
  const ClassificationLogPage = lazy(
    () => import("../modules/classification-log/ClassificationLogPage")
  );
  const ClassificationTrainingPage = lazy(
    () =>
      import("../modules/classification-training/ClassificationTrainingPage")
  );
  const WorkflowClassificationPage = lazy(
    () => import("../modules/workflow-classification/workflowPage")
  );
  const ReportsPage = lazy(() => import("../modules/reports/ReportsPage"));
  const HelpPage = lazy(() => import("../modules/help/HelpPage"));
  const { currentUser } = useAuth();

  const preDefinedRoutes = currentUser?.routes
    ? currentUser?.routes
    : DEFAULT_ROUTES;
  // const preDefinedRoutes = DEFAULT_ROUTES;
  const getNameAndRoutes = (findRoute: string) => {
    return preDefinedRoutes.find((e: any) => e.route == findRoute);
  };
  return (
    <Routes>
      {/* MasterLayout component that wraps around all routes */}
      <Route element={<MasterLayout />}>
        {/* Redirect any 'auth/*' route to the classification training page */}

        <Route path="/auth/*" element={<Navigate to="/" />} />

        {/* Route for Dashboard Page */}
        {getNameAndRoutes("/dashboard") && (
          <Route
            path="/dashboard"
            element={
              <SuspensedView>
                <DashboardPage />
              </SuspensedView>
            }
          />
        )}

        {/* Route for Training Page */}
        {getNameAndRoutes("/training") && (
          <Route
            path="/training/*"
            element={
              <SuspensedView>
                <TrainingPage />
              </SuspensedView>
            }
          />
        )}

        {/* Route for Reports Page */}
        {getNameAndRoutes("/reports") && (
          <Route
            path="/reports"
            element={
              <SuspensedView>
                <ReportsPage />
              </SuspensedView>
            }
          />
        )}

        {/* Route for Classification Training Page */}
        {getNameAndRoutes("/classification-training") && (
          <Route
            path="/classification-training"
            element={
              <SuspensedView>
                <ClassificationTrainingPage />
              </SuspensedView>
            }
          />
        )}

        {/* Route for Classification Log Page */}
        {getNameAndRoutes("/classification-log") && (
          <Route
            path="/classification-log"
            element={
              <SuspensedView>
                <ClassificationLogPage />
              </SuspensedView>
            }
          />
        )}
        {/* Route for HS Code Search Page */}
        {getNameAndRoutes("/hs-code-search") && (
          <Route
            path="/hs-code-search"
            element={
              <SuspensedView>
                <HSCodeSearchPage />
              </SuspensedView>
            }
          />
        )}

        {/* Route for Settings Page */}
        {getNameAndRoutes("/settings") && (
          <Route
            path="/settings/*"
            element={
              <SuspensedView>
                <SettingsPage />
              </SuspensedView>
            }
          />
        )}

        {/* Route for HS Code Settings Page */}
        {getNameAndRoutes("/hs-code-settings") && (
          <Route
            path="/hs-code-settings"
            element={
              <SuspensedView>
                <HSCodeSettingsPage />
              </SuspensedView>
            }
          />
        )}

        {/* Route for Workflow Classification Page */}
        {getNameAndRoutes("/workflow-classification") && (
          <Route
            path="/workflow-classification"
            element={
              <SuspensedView>
                <WorkflowClassificationPage />
              </SuspensedView>
            }
          />
        )}

        {/* Route for Error Log Page */}
        {getNameAndRoutes("/error-log") && (
          <Route
            path="/error-log"
            element={
              <SuspensedView>
                <ErrorLogPage />
              </SuspensedView>
            }
          />
        )}

        {/* Route for Help Page */}
        <Route
          path="/help"
          element={
            <SuspensedView>
              <HelpPage />
            </SuspensedView>
          }
        />

        {/* Route for Account Page under crafted/account */}
        <Route
          path="crafted/account/*"
          element={
            <SuspensedView>
              <AccountPage />
            </SuspensedView>
          }
        />

        {/* Catch-all route to redirect to a 404 error page for unknown paths */}
        <Route path="*" element={<Navigate to="/error/404" />} />
      </Route>
    </Routes>
  );
};

// Component to handle loading state with a top bar progress indicator
const SuspensedView: FC<WithChildren> = ({ children }) => {
  // Retrieve the primary color from CSS variables
  const baseColor = getCSSVariableValue("--bs-primary");

  // Configure TopBarProgress settings
  TopBarProgress.config({
    barColors: {
      "0": baseColor,
    },
    barThickness: 1,
    shadowBlur: 5,
  });

  // Render the children components with a fallback loading indicator
  return <Suspense fallback={<TopBarProgress />}>{children}</Suspense>;
};

export { PrivateRoutes };
