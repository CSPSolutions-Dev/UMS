import { FC } from "react";
import { Routes, Route, BrowserRouter, Navigate } from "react-router-dom";
import { PrivateRoutes } from "./PrivateRoutes";
import { ErrorsPage } from "../modules/errors/ErrorsPage";
import { Logout, AuthPage, useAuth } from "../modules/auth";
import { App } from "../App";
import { DEFAULT_ROUTES } from "../constant";

/**
 * Base URL of the website.
 *
 * @see https://facebook.github.io/create-react-app/docs/using-the-public-folder
 */
const { BASE_URL } = import.meta.env;

// Define the AppRoutes component, responsible for routing logic
const AppRoutes: FC = () => {
  // Destructure the currentUser from the useAuth hook to check if the user is authenticated
  const { currentUser } = useAuth();
  const preDefinedRoutes = currentUser?.routes
    ? currentUser?.routes
    : DEFAULT_ROUTES;
  return (
    // BrowserRouter is used for client-side routing, and basename is set using the BASE_URL environment variable
    <BrowserRouter basename={BASE_URL}>
      {/* Define the routes for the application */}
      <Routes>
        {/* Main application wrapper */}
        <Route element={<App />}>
          {/* Error page route, will handle routes that start with "error" */}
          <Route path="error/*" element={<ErrorsPage />} />
          {/* Logout route, directs to the Logout component when the path is "logout" */}
          <Route path="logout" element={<Logout />} />

          {/* Conditional rendering: If the user is authenticated, render private routes */}
          {currentUser ? (
            <>
              {/* Private routes: All routes that start with "/" will be handled by PrivateRoutes */}
              <Route path="/*" element={<PrivateRoutes />} />
              {/* Default route (index), which redirects the user to the dashboard */}
              <Route
                index
                element={<Navigate to={preDefinedRoutes[0].route} />}
              />
            </>
          ) : (
            <>
              {/* If not authenticated, redirect to the AuthPage (login/register page) */}
              <Route path="auth/*" element={<AuthPage />} />
              {/* Redirect any unknown routes to the authentication page */}
              <Route path="*" element={<Navigate to="/auth" />} />
            </>
          )}
        </Route>
      </Routes>
    </BrowserRouter>
  );
};

export { AppRoutes };
