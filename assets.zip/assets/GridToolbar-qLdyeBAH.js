import{r as s}from"./index-D2nypCHp.js";import{a as o,A as a}from"./index-CxorPgAE.js";/**
 * @license
 *-------------------------------------------------------------------------------------------
 * Copyright © 2024 Progress Software Corporation. All rights reserved.
 * Licensed under commercial license. See LICENSE.md in the package root for more information
 *-------------------------------------------------------------------------------------------
 */const r=class extends s.Component{render(){return s.createElement("div",{className:o("k-toolbar k-grid-toolbar",{"k-toolbar-md":!this.props.size,[`k-toolbar-${a.sizeMap[this.props.size]||this.props.size}`]:this.props.size},this.props.className),"aria-label":this.props.ariaLabel,"aria-controls":this.props.ariaControls,role:"toolbar"},this.props.children)}};r.displayName="KendoReactGridToolbar";let l=r;export{l as a};
