import{p}from"./index-D2nypCHp.js";var i={exports:{}};/*!
	Copyright (c) 2018 Jed Watson.
	Licensed under the MIT License (MIT), see
	http://jedwatson.github.io/classnames
*/(function(e){(function(){var a={}.hasOwnProperty;function s(){for(var t="",r=0;r<arguments.length;r++){var n=arguments[r];n&&(t=o(t,f(n)))}return t}function f(t){if(typeof t=="string"||typeof t=="number")return t;if(typeof t!="object")return"";if(Array.isArray(t))return s.apply(null,t);if(t.toString!==Object.prototype.toString&&!t.toString.toString().includes("[native code]"))return t.toString();var r="";for(var n in t)a.call(t,n)&&t[n]&&(r=o(r,n));return r}function o(t,r){return r?t?t+" "+r:t+r:t}e.exports?(s.default=s,e.exports=s):window.classNames=s})()})(i);var c=i.exports;const l=p(c);export{c as a,l as c};
