import{r as i,o as T}from"./index-D2nypCHp.js";import{v as $,C as z,a as k,b as o,D as I,s as K,E as O,F as A,y as W,G as S,H as _,c as B,d as F,I as L,g as P,e as U}from"./index-CxorPgAE.js";/**
 * @license
 *-------------------------------------------------------------------------------------------
 * Copyright © 2024 Progress Software Corporation. All rights reserved.
 * Licensed under commercial license. See LICENSE.md in the package root for more information
 *-------------------------------------------------------------------------------------------
 */const M=({children:n,onCloseButtonClick:t,id:e,closeIcon:s})=>i.createElement("div",{className:"k-window-titlebar k-dialog-titlebar",id:e},i.createElement("span",{className:"k-window-title k-dialog-title"},n),s&&i.createElement("div",{className:"k-window-titlebar-actions k-dialog-titlebar-actions"},i.createElement($,{role:"button","aria-label":"Close",onClick:t,icon:"x",svgIcon:z,fillMode:"flat",className:"k-window-titlebar-action k-dialog-titlebar-action"})));/**
 * @license
 *-------------------------------------------------------------------------------------------
 * Copyright © 2024 Progress Software Corporation. All rights reserved.
 * Licensed under commercial license. See LICENSE.md in the package root for more information
 *-------------------------------------------------------------------------------------------
 */const p=n=>{const t={layout:"stretched",...n},{layout:e,children:s}=t,a=k("k-actions","k-actions-horizontal","k-window-actions k-dialog-actions",{[`k-actions-${e}`]:e});return i.createElement("div",{className:a},s)};p.propTypes={children:o.any,layout:o.oneOf(["start","center","end","stretched"])};/**
 * @license
 *-------------------------------------------------------------------------------------------
 * Copyright © 2024 Progress Software Corporation. All rights reserved.
 * Licensed under commercial license. See LICENSE.md in the package root for more information
 *-------------------------------------------------------------------------------------------
 */const w={name:"@progress/kendo-react-dialogs",productName:"KendoReact",productCodes:["KENDOUIREACT","KENDOUICOMPLETE"],publishDate:1719500337,version:"",licensingDocsUrl:"https://www.telerik.com/kendo-react-ui/components/my-license/"};/**
 * @license
 *-------------------------------------------------------------------------------------------
 * Copyright © 2024 Progress Software Corporation. All rights reserved.
 * Licensed under commercial license. See LICENSE.md in the package root for more information
 *-------------------------------------------------------------------------------------------
 */const C="data-windowid",R=10002,m=2,Z=".k-window:not(.k-dialog), .k-dialog-wrapper";/**
 * @license
 *-------------------------------------------------------------------------------------------
 * Copyright © 2024 Progress Software Corporation. All rights reserved.
 * Licensed under commercial license. See LICENSE.md in the package root for more information
 *-------------------------------------------------------------------------------------------
 */const V=(n,t,e)=>{let s=n;if(t&&t.defaultView){let a=t.querySelectorAll(Z),r=!1;return a.forEach(c=>{let d=t.defaultView.getComputedStyle(c,null);if(c.getAttribute(C)!==e&&d.zIndex!==null){let h=parseInt(d.zIndex,10);h>=s&&(s=h,r=!0)}}),r?s+m:s}return s};/**
 * @license
 *-------------------------------------------------------------------------------------------
 * Copyright © 2024 Progress Software Corporation. All rights reserved.
 * Licensed under commercial license. See LICENSE.md in the package root for more information
 *-------------------------------------------------------------------------------------------
 */const l=class extends i.Component{constructor(t){super(t),this.context=0,this.titleId=this.generateTitleId(),this.contentId=this.generateContentId(),this.showLicenseWatermark=!1,this.activeElement=null,this.onCloseDialog=e=>{e.preventDefault(),W(this.props.onClose,e,this,void 0),setTimeout(()=>{this.activeElement&&this.activeElement.focus()})},this.onKeyDown=e=>{e.keyCode===S.esc&&this.props.onClose&&(e.preventDefault(),this.onCloseDialog(e)),_(e,this.element)},this.getCurrentZIndex=()=>!this.state||this.context===void 0?this.context?this.context:R:this.state.zIndex>(this.context?this.context+m:0)?this.state.zIndex:this.context+m,this.getDocument=()=>this.props.appendTo?this.props.appendTo.ownerDocument:document,B(w),this.showLicenseWatermark=F(w),this.activeElement=document.activeElement}get _id(){return this.props.id+"-accessibility-id"}componentDidMount(){this.element&&(this.props.autoFocus?this.element.focus():L(this.element),this.setState({zIndex:V(this.getCurrentZIndex(),this.getDocument(),this._id)}))}render(){const t=this.props.id!==void 0?this.props.id:this.titleId,{title:e,width:s,height:a,children:r,minWidth:c,dir:d,style:h,contentStyle:v,modal:x=!0}=this.props,u=i.Children.toArray(r),E=this.getContent(u),b=this.getActionBar(u),f=e?{"aria-labelledby":t}:null,D=this.props.closeIcon!==void 0?this.props.closeIcon:!0,g=this.getCurrentZIndex(),y=i.createElement(I.Provider,{value:g},i.createElement("div",{[C]:this._id,className:"k-dialog-wrapper"+(this.props.className?" "+this.props.className:""),onKeyDown:this.onKeyDown,tabIndex:0,dir:d,style:{zIndex:g,...h},ref:N=>this.element=N},x&&i.createElement("div",{className:"k-overlay",style:this.props.overlayStyle}),i.createElement("div",{...f,className:k("k-window k-dialog",{[`k-window-${this.props.themeColor}`]:this.props.themeColor}),role:"dialog","aria-labelledby":t,"aria-modal":!0,"aria-describedby":this.contentId,style:{width:s,height:a,minWidth:c}},this.props.title&&i.createElement(M,{closeIcon:D,onCloseButtonClick:this.onCloseDialog,id:t},e),i.createElement("div",{className:"k-window-content k-dialog-content",style:v,id:this.contentId},E),b,this.showLicenseWatermark&&i.createElement(P,null))));return U?this.props.appendTo!==null?T.createPortal(y,this.props.appendTo||document.body):y:null}getActionBar(t){return t.filter(e=>e&&e.type===p)}getContent(t){return t.filter(e=>e&&e.type!==p)}generateTitleId(){return"dialog-title-"+this._id}generateContentId(){return"dialog-content-"+this._id}};l.displayName="Dialog",l.propTypes={title:o.any,id:o.string,dir:o.string,style:o.object,closeIcon:o.bool,width:o.oneOfType([o.number,o.string]),height:o.oneOfType([o.number,o.string]),minWidth:o.oneOfType([o.number,o.string]),autoFocus:o.bool},l.defaultProps={autoFocus:!1},l.contextType=I;let j=l;const q=K(),G=O(A(q,j));G.displayName="KendoReactDialog";export{G as X,p as i};
