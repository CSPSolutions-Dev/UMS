package com.example.jythonpoc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JythonPocApplicationTests {

    @Test
    void contextLoads() {
    }

}
