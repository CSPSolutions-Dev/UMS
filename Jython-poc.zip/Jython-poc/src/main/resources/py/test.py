import json
import pandas as pd
import numpy as np
import pickle
from datetime import datetime
import pytz
from sklearn.preprocessing import OneHotEncoder
from tqdm import tqdm
from collections import defaultdict
import argparse

parser = argparse.ArgumentParser(description="A simple script that accepts command-line arguments")


parser.add_argument('--OneHotEncoderFilePath', type=str)
parser.add_argument('--InputJsonFilePath', type=str)
parser.add_argument('--SuccessCSVFilePath', type=str)
parser.add_argument('--ErrorCSVFilePath', type=str)

args = parser.parse_args()


# Load the previously saved OneHotEncoders dictionary
with open(args.OneHotEncoderFilePath, 'rb') as f:
    OHE_DICT = pickle.load(f)

encoders = OHE_DICT["OneHotEncoders"]
col_names = OHE_DICT["Column_Names"]

def convert_date_str(d_str):
    # Convert "24/04/19" to "YYYY-MM-DD HH:MM:SS.fff"
    day, month, year = d_str.split('/')
    year = "20" + year
    date_str = "{}/{}/{}".format(day, month, year)
    dt = datetime.strptime(date_str, "%d/%m/%Y")
    return dt.strftime("%Y-%m-%d %H:%M:%S.%f")

def parse_single_declaration(dec, request_assessment_id, d_index):
    # Parse a single declaration into a flattened record

    decl_id = "{}_{}".format(request_assessment_id, d_index)
    decl_no = dec.get("DECLARATION_NO", decl_id)  # use given DECLARATION_NO if present

    OWNER_BUSINESS_CODE = dec.get("OWNER_BUSINESS_CODE", np.nan)
    DECLARATION_DATE = dec.get("DECLARATION_DATE", "01/01/20")
    CREATED_DATE = convert_date_str(DECLARATION_DATE)

    DECLARATION_TYPE_CODE = dec.get("TYPE_CODE", "IM1")
    SUBMISSION_CHANNEL_CODE = str(dec.get("CHANNEL_CODE", 1))
    REGIME_TYPE_ID = dec.get("REGIME_TYPE", 1)
    COUNTRY_UN_CODE = dec.get("COUNTRY_UN_CODE", "NA")
    ORIGINAL_LOADING_PORT_CODE = dec.get("ORIGINAL_LOADING_PORT", "NA")
    LOADING_PORT_CODE = dec.get("LOADING_PORT", "NA")
    DISCHARGE_PORT_CODE = dec.get("DISCHARGE_PORT", "NA")
    INBOUND_CARGO_CHANNEL = dec.get("INBOUND_CARGO_CHANNEL", 0)
    OUTBOUND_CARGO_CHANNEL = dec.get("OUTBOUND_CARGO_CHANNEL", 0)
    CUS_LOC_EXIT_POINT_CODE = dec.get("LOC_EXIT_POINT", "NA")
    GOODS_LOCATION_CODE = dec.get("GOODS_LOCATION", "NA")

    cargo_type_list = dec.get("CARGO_TYPE", [])
    CARGO_TYPE_ID = cargo_type_list[0] if isinstance(cargo_type_list, list) and len(cargo_type_list) > 0 else 1

    invoices = dec.get("invoices", [])

    inv_cc_set = set()
    incoterm_set = set()
    total_invoice_cif = 0.0

    items = []
    for inv in invoices:
        inv_cc = inv.get("INVOICE_CURRENCY_CODE", "NA")
        inv_cif = inv.get("INVOICE_CIF_VALUE", 0.0)
        inv_incoterm = inv.get("INCOTERM_CODE", "NA")

        total_invoice_cif += inv_cif
        inv_cc_set.add(inv_cc)
        incoterm_set.add(inv_incoterm)

        line_items = inv.get("items", [])
        for lit in line_items:
            ORIGIN_COUNTRY_UN_CODE_l = lit.get("ORIGIN_COUNTRY_UN_CODE", "NA")
            COMMODITY_CODE_l = str(lit.get("COMMODITY_CODE", "NA"))
            WEIGHT_UNIT_ID_l = str(lit.get("WEIGHT_UNIT", "NA"))
            WEIGHT_l = lit.get("WEIGHT", 0.0)
            SUPPLEMENTARY_QUANTITY_l = lit.get("SUPPLEMENTARY_QUANTITY", 0.0)
            SUPPLEMENTARY_QUANTITY_UNIT_ID_l = str(lit.get("SUPPLEMENTARY_QUANTITY_UNIT", "NA"))
            STATISTICAL_QUANTITY_l = lit.get("STATISTICAL_QUANTITY", 0.0)
            STATISTICAL_QUANTITY_UNIT_ID_l = str(lit.get("STATISTICAL_QUANTITY_UNIT", "NA"))

            IS_VEHICLE_val = str(lit.get("IS_VEHICLE", "N"))
            IS_VEHICLE_l = 1 if IS_VEHICLE_val.upper().startswith('Y') else 0
            IS_NEW_val = str(lit.get("IS_NEW", "N"))
            IS_NEW_l = 1 if IS_NEW_val.upper().startswith('Y') else 0
            EXEMPTION_TYPE_CODE_l = str(lit.get("EXEMPTION_TYPE_CODE", "0"))

            permits = lit.get("permits", [])
            IS_PERMIT_REQUIRED_l = 1 if any(str(p.get("PERMIT INDICATOR", "N")).upper().startswith('Y') for p in permits) else 0

            items.append({
                "ORIGIN_COUNTRY_UN_CODE": ORIGIN_COUNTRY_UN_CODE_l,
                "COMMODITY_CODE": COMMODITY_CODE_l,
                "WEIGHT_UNIT_ID": WEIGHT_UNIT_ID_l,
                "WEIGHT": WEIGHT_l,
                "SUPPLEMENTARY_QUANTITY_UNIT_ID": SUPPLEMENTARY_QUANTITY_UNIT_ID_l,
                "SUPPLEMENTARY_QUANTITY": SUPPLEMENTARY_QUANTITY_l,
                "STATISTICAL_QUANTITY_UNIT_ID": STATISTICAL_QUANTITY_UNIT_ID_l,
                "STATISTICAL_QUANTITY": STATISTICAL_QUANTITY_l,
                "IS_VEHICLE": IS_VEHICLE_l,
                "IS_NEW": IS_NEW_l,
                "EXEMPTION_TYPE_CODE": EXEMPTION_TYPE_CODE_l,
                "IS_PERMIT_REQUIRED": IS_PERMIT_REQUIRED_l
            })

    # Aggregate item-level fields
    all_ocunc = [it['ORIGIN_COUNTRY_UN_CODE'] for it in items]
    all_cc = [it['COMMODITY_CODE'] for it in items]
    all_wu = [it['WEIGHT_UNIT_ID'] for it in items]
    all_supu = [it['SUPPLEMENTARY_QUANTITY_UNIT_ID'] for it in items]
    all_stu = [it['STATISTICAL_QUANTITY_UNIT_ID'] for it in items]
    all_et = [it['EXEMPTION_TYPE_CODE'] for it in items]

    isv_0 = sum(1 for it in items if it['IS_VEHICLE'] == 0)
    isv_1 = sum(1 for it in items if it['IS_VEHICLE'] == 1)
    isn_0 = sum(1 for it in items if it['IS_NEW'] == 0)
    isn_1 = sum(1 for it in items if it['IS_NEW'] == 1)
    ispr_0 = sum(1 for it in items if it['IS_PERMIT_REQUIRED'] == 0)
    ispr_1 = sum(1 for it in items if it['IS_PERMIT_REQUIRED'] == 1)

    weight_sum = defaultdict(float)
    supq_sum = defaultdict(float)
    stq_sum = defaultdict(float)

    for it in items:
        weight_sum[it['WEIGHT_UNIT_ID']] += it['WEIGHT']
        supq_sum[it['SUPPLEMENTARY_QUANTITY_UNIT_ID']] += it['SUPPLEMENTARY_QUANTITY']
        stq_sum[it['STATISTICAL_QUANTITY_UNIT_ID']] += it['STATISTICAL_QUANTITY']

    flattened_record = {
        "DECLARATION_ID": decl_id,
        "DECLARATION_NO": decl_no,
        "DECLARATION_TYPE_CODE": DECLARATION_TYPE_CODE,
        "SUBMISSION_CHANNEL_CODE": SUBMISSION_CHANNEL_CODE,
        "REGIME_TYPE_ID": REGIME_TYPE_ID,
        "OWNER_BUSINESS_CODE": OWNER_BUSINESS_CODE,
        "COUNTRY_UN_CODE": COUNTRY_UN_CODE,
        "ORIGINAL_LOADING_PORT_CODE": ORIGINAL_LOADING_PORT_CODE,
        "LOADING_PORT_CODE": LOADING_PORT_CODE,
        "DISCHARGE_PORT_CODE": DISCHARGE_PORT_CODE,
        "INBOUND_CARGO_CHANNEL": INBOUND_CARGO_CHANNEL,
        "OUTBOUND_CARGO_CHANNEL": OUTBOUND_CARGO_CHANNEL,
        "CUS_LOC_EXIT_POINT_CODE": CUS_LOC_EXIT_POINT_CODE,
        "GOODS_LOCATION_CODE": GOODS_LOCATION_CODE,
        "CARGO_TYPE_ID": CARGO_TYPE_ID,
        "CREATED_DATE": CREATED_DATE,
        "DATA_SOURCE": "JSON_INPUT",
        "INVOICE_CURRENCY_CODES": list(inv_cc_set),
        "INCOTERM_CODES": list(incoterm_set),
        "TOTAL_INVOICE_CIF_VALUE": total_invoice_cif,
        "ORIGIN_COUNTRY_UN_CODES": all_ocunc,
        "COMMODITY_CODES": all_cc,
        "WEIGHT_UNITS": all_wu,
        "SUP_QTY_UNITS": all_supu,
        "STAT_QTY_UNITS": all_stu,
        "EXEMPTION_TYPES": all_et,
        "WEIGHT_SUMS": dict(weight_sum),
        "SUP_QTY_SUMS": dict(supq_sum),
        "STAT_QTY_SUMS": dict(stq_sum),
        "IS_VEHICLE_0": isv_0,
        "IS_VEHICLE_1": isv_1,
        "IS_NEW_0": isn_0,
        "IS_NEW_1": isn_1,
        "IS_PERMIT_REQUIRED_0": ispr_0,
        "IS_PERMIT_REQUIRED_1": ispr_1
    }

    return flattened_record

def safe_transform(encoder, val):
    # If val not in encoder categories, raise ValueError
    if val not in encoder.categories_[0]:
        values= "Category {} not found in {}.".format(val,encoder)
        raise ValueError(values)
    return encoder.transform([[val]])[0]

def encode_presence(encoder, values):
    arr = np.zeros(len(encoder.categories_[0]))
    for val in values:
        if val not in encoder.categories_[0]:
            values= "Category {} not found in {}.".format(val,encoder)
            raise ValueError(values)
        vec = encoder.transform([[val]])[0]
        arr = np.where((arr+vec)>0,1,0)
    return arr

def encode_single_record(row, encoders, col_names, class_label="NO RISK"):
    data_row = []
    column_names = []

    def single_encode(enc, val, cn):
        vec = safe_transform(enc, val)
        data_row.extend(vec)
        column_names.extend(cn)

    # Single-value encodings
    single_encode(encoders['DECLARATION_TYPE_CODE'], row['DECLARATION_TYPE_CODE'], col_names['DECLARATION_TYPE_CODE_CN'])
    single_encode(encoders['SUBMISSION_CHANNEL_CODE'], row['SUBMISSION_CHANNEL_CODE'], col_names['SUBMISSION_CHANNEL_CODE_CN'])
    single_encode(encoders['REGIME_TYPE_ID'], row['REGIME_TYPE_ID'], col_names['REGIME_TYPE_ID_CN'])
    single_encode(encoders['COUNTRY_UN_CODE'], row['COUNTRY_UN_CODE'], col_names['COUNTRY_UN_CODE_CN'])
    single_encode(encoders['ORIGINAL_LOADING_PORT_CODE'], row['ORIGINAL_LOADING_PORT_CODE'], col_names['ORIGINAL_LOADING_PORT_CODE_CN'])
    single_encode(encoders['LOADING_PORT_CODE'], row['LOADING_PORT_CODE'], col_names['LOADING_PORT_CODE_CN'])
    single_encode(encoders['DISCHARGE_PORT_CODE'], row['DISCHARGE_PORT_CODE'], col_names['DISCHARGE_PORT_CODE_CN'])
    single_encode(encoders['INBOUND_CARGO_CHANNEL'], row['INBOUND_CARGO_CHANNEL'], col_names['INBOUND_CARGO_CHANNEL_CN'])
    single_encode(encoders['OUTBOUND_CARGO_CHANNEL'], row['OUTBOUND_CARGO_CHANNEL'], col_names['OUTBOUND_CARGO_CHANNEL_CN'])
    single_encode(encoders['CUS_LOC_EXIT_POINT_CODE'], row['CUS_LOC_EXIT_POINT_CODE'], col_names['CUS_LOC_EXIT_POINT_CODE_CN'])
    single_encode(encoders['GOODS_LOCATION_CODE'], row['GOODS_LOCATION_CODE'], col_names['GOODS_LOCATION_CODE_CN'])
    single_encode(encoders['CARGO_TYPE_ID'], row['CARGO_TYPE_ID'], col_names['CARGO_TYPE_ID_CN'])

    # Multi-value encodings
    inv_cc_vec = encode_presence(encoders['INVOICE_CURRENCY_CODE'], row['INVOICE_CURRENCY_CODES'])
    data_row.extend(inv_cc_vec)
    column_names.extend(col_names['INVOICE_CURRENCY_CODE_CN'])

    data_row.append(row['TOTAL_INVOICE_CIF_VALUE'])
    column_names.append('TOTAL_INVOICE_CIF_VALUE')

    incoterm_vec = encode_presence(encoders['INCOTERM_CODE'], row['INCOTERM_CODES'])
    data_row.extend(incoterm_vec)
    column_names.extend(col_names['INCOTERM_CODE_CN'])

    ocunc_vec = encode_presence(encoders['ORIGIN_COUNTRY_UN_CODE'], row['ORIGIN_COUNTRY_UN_CODES'])
    data_row.extend(ocunc_vec)
    column_names.extend(col_names['ORIGIN_COUNTRY_UN_CODE_CN'])

    cc_vec = encode_presence(encoders['COMMODITY_CODE'], row['COMMODITY_CODES'])
    data_row.extend(cc_vec)
    column_names.extend(col_names['COMMODITY_CODE_CN'])

    wu_vec = encode_presence(encoders['WEIGHT_UNIT_ID'], row['WEIGHT_UNITS'])
    data_row.extend(wu_vec)
    column_names.extend(col_names['WEIGHT_UNIT_ID_CN'])

    # Weight sums
    wu_cats = encoders['WEIGHT_UNIT_ID'].categories_[0]
    w_sums = [row['WEIGHT_SUMS'].get(cat, 0.0) for cat in wu_cats]
    data_row.extend(w_sums)
    column_names.extend([c + '_SUM' for c in col_names['WEIGHT_UNIT_ID_CN']])

    supu_vec = encode_presence(encoders['SUPPLEMENTARY_QUANTITY_UNIT_ID'], row['SUP_QTY_UNITS'])
    data_row.extend(supu_vec)
    column_names.extend(col_names['SUPPLEMENTARY_QUANTITY_UNIT_ID_CN'])

    supu_cats = encoders['SUPPLEMENTARY_QUANTITY_UNIT_ID'].categories_[0]
    sup_sums = [row['SUP_QTY_SUMS'].get(cat, 0.0) for cat in supu_cats]
    data_row.extend(sup_sums)
    column_names.extend([c + '_SUM' for c in col_names['SUPPLEMENTARY_QUANTITY_UNIT_ID_CN']])

    stu_vec = encode_presence(encoders['STATISTICAL_QUANTITY_UNIT_ID'], row['STAT_QTY_UNITS'])
    data_row.extend(stu_vec)
    column_names.extend(col_names['STATISTICAL_QUANTITY_UNIT_ID_CN'])

    stu_cats = encoders['STATISTICAL_QUANTITY_UNIT_ID'].categories_[0]
    st_sums = [row['STAT_QTY_SUMS'].get(cat, 0.0) for cat in stu_cats]
    data_row.extend(st_sums)
    column_names.extend([c + '_SUM' for c in col_names['STATISTICAL_QUANTITY_UNIT_ID_CN']])

    et_vec = encode_presence(encoders['EXEMPTION_TYPE_CODE'], row['EXEMPTION_TYPES'])
    data_row.extend(et_vec)
    column_names.extend(col_names['EXEMPTION_TYPE_CODE_CN'])

    data_row.extend([row['IS_VEHICLE_0'], row['IS_VEHICLE_1'],
                     row['IS_NEW_0'], row['IS_NEW_1'],
                     row['IS_PERMIT_REQUIRED_0'], row['IS_PERMIT_REQUIRED_1']])
    column_names.extend(['IS_VEHICLE_0', 'IS_VEHICLE_1', 'IS_NEW_0', 'IS_NEW_1',
                         'IS_PERMIT_REQUIRED_0', 'IS_PERMIT_REQUIRED_1'])

    # No historical data from code snippet, set defaults:
    no_of_dec = 1
    recency = 0
    total_cif_hist = row['TOTAL_INVOICE_CIF_VALUE']
    no_of_risky_insp = 0
    no_of_risky_chr = 0
    no_of_risky_cdm = 0

    data_row.extend([no_of_dec, recency, total_cif_hist,
                     no_of_risky_insp, no_of_risky_chr, no_of_risky_cdm])
    column_names.extend(['NO_OF_DECLARATIONS','RECENCY','TOTAL_CIF_VALUE',
                         'NO_OF_RISKY_INSPECTION_AOR','NO_OF_CHARGES_ON_DECLARATION','NO_OF_RISKY_CDM_AOR'])

    data_row.append(class_label)
    column_names.append('CLASS')

    df_encoded = pd.DataFrame([data_row], columns=column_names)
    return df_encoded

if __name__ == "__main__":
    # Load the given JSON input
    with open(args.InputJsonFilePath, 'r') as f:
        data = json.load(f)

    request_assessment_id = data.get("request_header", {}).get("request_assessment_id", "UNKNOWN")
    declarations = data.get("declaration", [])

    encoded_all = []
    errors = []

    for d_index, dec in enumerate(declarations):
        unknown_index = "UNKNOWN_{}".format(d_index)
        decl_no = dec.get("DECLARATION_NO", unknown_index)
        try:
            # Parse single declaration to flattened form
            flattened_record = parse_single_declaration(dec, request_assessment_id, d_index)
            # Encode it
            df_encoded = encode_single_record(flattened_record, encoders, col_names, class_label="NO RISK")
            # Append to final list
            encoded_all.append(df_encoded)
        except ValueError as e:
            # Capture error for this declaration_no
            errors.append((decl_no, str(e)))
        except Exception as e:
            # Capture any other unexpected error
            errors.append((decl_no, str(e)))

    # Concatenate all successful encodings
    if len(encoded_all) > 0:
        final_df = pd.concat(encoded_all, ignore_index=True)
        final_df.to_csv(args.SuccessCSVFilePath, index=False)
        print("Successfully processed declarations. Output saved to 'output_preprocessed.csv'.")
    else:
        print("No declarations processed successfully.")

    # Save errors if any
    if len(errors) > 0:
        df_errors = pd.DataFrame(errors, columns=["DECLARATION_NO", "ERROR_MESSAGE"])
        df_errors.to_csv(args.ErrorCSVFilePath, index=False)
        print("Some declarations encountered errors. Check 'errors.csv' for details.")
    else:
        print("No errors encountered.")
