package com.example.jythonpoc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

@Service
public class JythonServiceImpl implements JythonService {

    @Autowired
    private RestTemplate restTemplate;

    @Override
    public String executePythonScript(int a, int b) {
        StringBuilder output = new StringBuilder();
        try {
            // Build the command to run the Python script
            String command = "python"; // or "python" depending on your setup
            String scriptPath = "C:\\Users\\MTPC-482\\Downloads\\Jython-poc\\Jython-poc\\src\\main\\resources\\py\\test.py"; // Modify the script path

            ProcessBuilder processBuilder = new ProcessBuilder(command, scriptPath,
                    "--OneHotEncoderFilePath", "C:\\Users\\MTPC-482\\Downloads\\Jython-poc\\Jython-poc\\src\\main\\resources\\py\\OHE_DICT.pkl",
                    "--InputJsonFilePath", "C:\\Users\\MTPC-482\\Downloads\\Jython-poc\\Jython-poc\\src\\main\\resources\\py\\input.json",
                    "--SuccessCSVFilePath", "C:\\Users\\MTPC-482\\Downloads\\Jython-poc\\Jython-poc\\src\\main\\resources\\py\\success.csv",
                    "--ErrorCSVFilePath", "C:\\Users\\MTPC-482\\Downloads\\Jython-poc\\Jython-poc\\src\\main\\resources\\py\\error.csv"
            );
            processBuilder.redirectErrorStream(true); // Merge error stream with output stream

            Process process = processBuilder.start(); // Start the process

            // Read the output of the script
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    output.append(line).append("\n");
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            // Wait for the process to exit
            process.waitFor();
            if (isFileExists("C:\\Users\\MTPC-482\\Downloads\\Jython-poc\\Jython-poc\\src\\main\\resources\\py\\success.csv")) {
                postFileToApi("C:\\Users\\MTPC-482\\Downloads\\Jython-poc\\Jython-poc\\src\\main\\resources\\py\\success.csv");
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
            output.append("Error executing Python script: ").append(e.getMessage());
        }
        return output.toString();
    }

    public String postFileToApi(String filePath) throws IOException {
        // API endpoint URL
        String url = "https://datarobot.apps.tstocpclstr.dubaicustoms.ae/predApi/v1.0/deployments/675ae0666ecfed32732c89d1/predictions";

        // Create headers
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer NjY0NmYxOWYwNDJlNGI4ZTU4YWFjYTVlOlpwZE5IR2dMNDZjTlBUTmVKNGZRZVF2QW43bzN5a1NCbDBDQnozNlZkbWM9");
        headers.set("Content-Type", "text/csv; charset=UTF-8");
        headers.set("Accept", "text/csv");

        // Create body with the file to be uploaded
        File file = new File(filePath);
        FileSystemResource fileResource = new FileSystemResource(file);

        // Create MultiValueMap to represent the form data
        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("file", fileResource);

        // Wrap the body and headers in an HttpEntity
        HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, headers);

        // Send POST request
        ResponseEntity<String> responseEntity = restTemplate.exchange(url, HttpMethod.POST, requestEntity, String.class);

        // Return the response body (for demonstration)
        return responseEntity.getBody();
    }

    public boolean isFileExists(String filePath) {
        // Create a File object for the given path
        File file = new File(filePath);

        // Check if the file exists and is a file (not a directory)
        return file.exists() && file.isFile();
    }
}
