package com.example.jythonpoc.service;

public interface JythonService {

    String executePythonScript(int a, int b);
}
