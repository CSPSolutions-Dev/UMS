package com.example.jythonpoc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JythonPocApplication {

    public static void main(String[] args) {
        SpringApplication.run(JythonPocApplication.class, args);
    }

}
