package com.example.jythonpoc.controller;

import com.example.jythonpoc.service.JythonService;
import org.python.core.PyObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PythonInterpretController {

    private final JythonService jythonService;

    public PythonInterpretController(JythonService jythonService) {
        this.jythonService = jythonService;
    }

    @GetMapping("/add")
    public ResponseEntity<Object> sum(@RequestParam Integer num1, @RequestParam Integer num2) {
        try {
            String value = jythonService.executePythonScript(num1, num2);
            return new ResponseEntity<>(value, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
}
